﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;

namespace SP21_Final_Project
{
    class HtmlReports
    {//This class is what is going to read in the data from the progream to determine what is necessary for help, and what is necessary for reports
        //**************************REPORT FILES

        public static  StringBuilder GenerateSchedule(SqlCommand command)
        {
            int dayCount = 0;
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();
            SqlDataReader reader;
            string info;

            command.ExecuteNonQuery();

            reader = command.ExecuteReader();

            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"Your Schedule"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"Monday - Sunday"}</h1>");

            html.Append("<table>");
            html.Append("<tr><td colspan=7></td></tr>");

            html.Append("<tr>");
            html.Append("<td>Username</td>");
            html.Append("<td>Position</td>");
            html.Append("<td>Start Shift</td>");
            html.Append("<td>Lunch Start</td>");
            html.Append("<td>Lunch End</td>");
            html.Append("<td>End Shift</td>");
            html.Append("<td>Weekday</td>");
            html.Append("</tr>");

            html.Append("<tr>");
            while (reader.Read())
            {
                dayCount++;

                info = reader.GetString(0) + "\t\t" + reader.GetString(1) + "\t\t" + reader.GetTimeSpan(2) + "\t\t" + reader.GetTimeSpan(3) + "\t\t" + reader.GetTimeSpan(4) + "\t\t" + reader.GetTimeSpan(5);
                html.Append($"<td>{reader.GetString(0)}</t+d>");
                html.Append($"<td>{reader.GetString(1)}</td>");
                html.Append($"<td>{reader.GetTimeSpan(2)}</td>");
                html.Append($"<td>{reader.GetTimeSpan(3)}</td>");
                html.Append($"<td>{reader.GetTimeSpan(4)}</td>");
                html.Append($"<td>{reader.GetTimeSpan(5)}</td>");

                if (dayCount == 1)
                    html.Append("<td>Monday</td>");
                if (dayCount == 2)
                    html.Append("<td>Tuesday</td>");
                if (dayCount == 3)
                    html.Append("<td>Wednesday</td>");
                if (dayCount == 4)
                    html.Append("<td>Thursday</td>");
                if (dayCount == 5)
                    html.Append("<td>Friday</td>");
                if (dayCount == 6)
                    html.Append("<td>Saturday</td>");
                if (dayCount == 7)
                    html.Append("<td>Sunday</td>");

                html.Append("</tr>");
            }


            html.Append("<tr><td colspan=8></td></tr>");
            html.Append("</table>");
            html.Append("</body></html>");

            reader.Close();
            return html;
        }

        public static void PrintSchedule(StringBuilder html)
        {
            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/Schedule.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/Schedule.html");


                DateTime today = DateTime.Now;

                using (StreamWriter wr = new StreamWriter($"{filePath}/{today.ToString("yyyy-MM-dd-HHmmss")} - Report.html"))
                {
                    wr.WriteLine(html);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder GenerateAllSchedules(SqlCommand command)
        { 

            int dayCount = 0;
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();

            SqlDataReader reader;
            string info;

            command.ExecuteNonQuery();

            reader = command.ExecuteReader();

            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"All Schedules"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"Monday - Sunday"}</h1>");

            html.Append("<table>");
            html.Append("<tr><td colspan=7></td></tr>");

            html.Append("<tr>");
            html.Append("<td>Username</td>");
            html.Append("<td>Position</td>");
            html.Append("<td>Start Shift</td>");
            html.Append("<td>Lunch Start</td>");
            html.Append("<td>Lunch End</td>");
            html.Append("<td>End Shift</td>");
            html.Append("<td>Weekday</td>");
            html.Append("</tr>");

            html.Append("<tr>");
            while (reader.Read())
            {
                dayCount++;
                if (dayCount > 7)
                {
                    dayCount = 1;
                }

                info = reader.GetString(0) + "\t\t" + reader.GetString(1) + "\t\t" + reader.GetTimeSpan(2) + "\t\t" + reader.GetTimeSpan(3) + "\t\t" + reader.GetTimeSpan(4) + "\t\t" + reader.GetTimeSpan(5);
                html.Append($"<td>{reader.GetString(0)}</td>");
                html.Append($"<td>{reader.GetString(1)}</td>");
                html.Append($"<td>{reader.GetTimeSpan(2)}</td>");
                html.Append($"<td>{reader.GetTimeSpan(3)}</td>");
                html.Append($"<td>{reader.GetTimeSpan(4)}</td>");
                html.Append($"<td>{reader.GetTimeSpan(5)}</td>");

                if (dayCount == 1)
                    html.Append("<td>Monday</td>");
                if (dayCount == 2)
                    html.Append("<td>Tuesday</td>");
                if (dayCount == 3)
                    html.Append("<td>Wednesday</td>");
                if (dayCount == 4)
                    html.Append("<td>Thursday</td>");
                if (dayCount == 5)
                    html.Append("<td>Friday</td>");
                if (dayCount == 6)
                    html.Append("<td>Saturday</td>");
                if (dayCount == 7)
                    html.Append("<td>Sunday</td>");

                html.Append("</tr>");
            }


            html.Append("<tr><td colspan=8></td></tr>");
            html.Append("</table>");
            html.Append("</body></html>");

            reader.Close();
            return html;
        }
        public static void PrintSchedules(StringBuilder html)
        {
            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/AllSchedules.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/AllSchedules.html");
           
            DateTime today = DateTime.Now;
            using (StreamWriter wr = new StreamWriter($"{filePath}/{today.ToString("yyyy-MM-dd-HHmmss")} - Report.html"))
            {
                wr.WriteLine(html);
            } }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder GenerateOrder(SqlCommand command)
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();

            SqlDataReader reader;
            string info = "";

            command.ExecuteNonQuery();

            reader = command.ExecuteReader();

            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"Your Orders"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"Your Orders"}</h1>");

            html.Append("<table>");
            html.Append("<tr><td colspan=7></td></tr>");

            html.Append("<tr>");
            html.Append("<td>OrderID</td>");
            html.Append("<td>Customer Username</td>");
            html.Append("<td>Order Date</td>");
            html.Append("<td>Card Name</td>");
            html.Append("<td>Card Price</td>");
            html.Append("<td>Quantity</td>");
            html.Append("<td>OrderTotal</td>");
            html.Append("</tr>");

            html.Append("<tr>");
            while (reader.Read())
            {
                info = reader.GetString(7);
                html.Append($"<td>{reader.GetInt32(0)}</td>");
                html.Append($"<td>{reader.GetString(1)}</td>");
                html.Append($"<td>{Convert.ToDateTime(reader.GetDateTime(2)).ToString("dd/MM/yyyy")}</td>");
                html.Append($"<td>{reader.GetString(3)}</td>");
                html.Append($"<td>{reader.GetString(4)}</td>");
                html.Append($"<td>{reader.GetInt32(5)}</td>");
                html.Append($"<td>{reader.GetString(6)}</td>");


                html.Append("</tr>");
            }


            html.Append("<tr><td colspan=8></td></tr>");
            html.Append("</table>");

            if (info != "")
            {
                html.Append("<p><strong>Total for All Orders</strong></p>");
                html.Append($"<p>{info}</p>");
            }
            html.Append("</body></html>");

            reader.Close();
            return html;
        }

        public static void PrintOrder(StringBuilder html)
        {
                string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {

                using (StreamWriter wr = new StreamWriter($"{filePath}/Order.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/Order.html");
           
            DateTime today = DateTime.Now;
            using (StreamWriter wr = new StreamWriter($"{filePath}/{today.ToString("yyyy-MM-dd-HHmmss")} - OrderReport.html"))
            {
                wr.WriteLine(html);
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder GenerateInventory(SqlCommand command)
        { 
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();

            SqlDataReader reader;

            command.ExecuteNonQuery();

            reader = command.ExecuteReader();

            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"Current Inventory"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"Current Inventory"}</h1>");

            html.Append("<table>");
            html.Append("<tr><td colspan=3></td></tr>");

            html.Append("<tr>");
            html.Append("<td>Card Name</td>");
            html.Append("<td>Quantity Stored</td>");
            html.Append("<td>Price per Unit</td>");
            html.Append("</tr>");

            html.Append("<tr>");
            while (reader.Read())
            {
                html.Append($"<td>{reader.GetString(0)}</td>");
                html.Append($"<td>{reader.GetInt32(1)}</td>");
                html.Append($"<td>{reader.GetString(2)}</td>");


                html.Append("</tr>");
            }


            html.Append("<tr><td colspan=4></td></tr>");
            html.Append("</table>");
            html.Append("</body></html>");

            reader.Close();

            return html;
        }

        public static void PrintInventory(StringBuilder html)
        {
            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/Inventory.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/Inventory.html");
           
            DateTime today = DateTime.Now;
            using (StreamWriter wr = new StreamWriter($"{filePath}/{today.ToString("yyyy-MM-dd-HHmmss")} - InventoryReport.html"))
            {
                wr.WriteLine(html);
            } 
            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder GenerateDailySales(SqlCommand command)
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();
            string info = "";
            SqlDataReader reader;

            command.ExecuteNonQuery();

            reader = command.ExecuteReader();

            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"Daily Sales"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"Daily Sales"}</h1>");

            html.Append("<table>");
            html.Append("<tr><td colspan=6></td></tr>");

            html.Append("<tr>");
            html.Append("<td>OrderID</td>");
            html.Append("<td>Order Date</td>");
            html.Append("<td>Customer Username</td>");
            html.Append("<td>Card Name</td>");
            html.Append("<td>Quantity</td>");
            html.Append("<td>Price of Order</td>");
            html.Append("</tr>");

            html.Append("<tr>");
            while (reader.Read())
            {
                info = reader.GetString(6);
                html.Append($"<td>{reader.GetInt32(0)}</td>");
                html.Append($"<td>{Convert.ToDateTime(reader.GetDateTime(1)).ToString("MM/dd/yyyy")}</td>");
                html.Append($"<td>{reader.GetString(2)}</td>");
                html.Append($"<td>{reader.GetString(3)}</td>");
                html.Append($"<td>{reader.GetInt32(4)}</td>");
                html.Append($"<td>{reader.GetString(5)}</td>");


                html.Append("</tr>");
            }


            html.Append("<tr><td colspan=7></td></tr>");
            html.Append("</table>");

            if (info != "")
            {
                html.Append("<p>Total Daily Sales</p>");
                html.Append($"<p>{info}</p>");
            }

            html.Append("</body></html>");

            reader.Close();
            return html;
        }

        public static void PrintDailySales(StringBuilder html)
        {

            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            DateTime today = DateTime.Now;
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/{today.ToString("yyyy-MM-dd-HHmmss")}DailySales.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/{today.ToString("yyyy-MM-dd-HHmmss")}DailySales.html");
           
            using (StreamWriter wr = new StreamWriter($"{filePath}/{today.ToString("yyyy-MM-dd-HHmmss")} - DailySales.html"))
            {
                wr.WriteLine(html);
            } }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder GenerateWeeklySales(SqlCommand command)
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();
            string info = "";
            SqlDataReader reader;

            command.ExecuteNonQuery();

            reader = command.ExecuteReader();

            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"Weekly Sales"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"Weekly Sales"}</h1>");

            html.Append("<table>");
            html.Append("<tr><td colspan=6></td></tr>");

            html.Append("<tr>");
            html.Append("<td>OrderID</td>");
            html.Append("<td>Order Date</td>");
            html.Append("<td>Customer Username</td>");
            html.Append("<td>Card Name</td>");
            html.Append("<td>Quantity</td>");
            html.Append("<td>Price of Order</td>");
            html.Append("</tr>");

            html.Append("<tr>");
            while (reader.Read())
            {
                info =  reader.GetString(6);
                html.Append($"<td>{reader.GetInt32(0)}</td>");
                html.Append($"<td>{Convert.ToDateTime(reader.GetDateTime(1)).ToString("dd/MM/yyyy")}</td>");
                html.Append($"<td>{reader.GetString(2)}</td>");
                html.Append($"<td>{reader.GetString(3)}</td>");
                html.Append($"<td>{reader.GetInt32(4)}</td>");
                html.Append($"<td>{reader.GetString(5)}</td>");


                html.Append("</tr>");
            }


            html.Append("<tr><td colspan=7></td></tr>");
            html.Append("</table>");

            if (info != "")
            {
                html.Append("<p>Total Weekly Sales</p>");
                html.Append($"<p>{info}</p>");
            }

            html.Append("</body></html>");

            reader.Close();
            return html;
        }

        public static void PrintWeeklySales(StringBuilder html)
        {

            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            DateTime today = DateTime.Now;
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/{today.ToString("yyyy-MM-dd-HHmmss")}WeeklySales.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/{today.ToString("yyyy-MM-dd-HHmmss")}WeeklySales.html");
            
            using (StreamWriter wr = new StreamWriter($"{filePath}/{today.ToString("yyyy-MM-dd-HHmmss")} - WeeklySales.html"))
            {
                wr.WriteLine(html);
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder GenerateMonthlySales(SqlCommand command)
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();
            string info = "";
            SqlDataReader reader;

            command.ExecuteNonQuery();

            reader = command.ExecuteReader();

            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"Monthly Sales"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"Monthly Sales"}</h1>");

            html.Append("<table>");
            html.Append("<tr><td colspan=6></td></tr>");

            html.Append("<tr>");
            html.Append("<td>OrderID</td>");
            html.Append("<td>Order Date</td>");
            html.Append("<td>Customer Username</td>");
            html.Append("<td>Card Name</td>");
            html.Append("<td>Quantity</td>");
            html.Append("<td>Price of Order</td>");
            html.Append("</tr>");

            html.Append("<tr>");
            while (reader.Read())
            {
                info = reader.GetString(6);
                html.Append($"<td>{reader.GetInt32(0)}</td>");
                html.Append($"<td>{Convert.ToDateTime(reader.GetDateTime(1)).ToString("dd/MM/yyyy")}</td>");
                html.Append($"<td>{reader.GetString(2)}</td>");
                html.Append($"<td>{reader.GetString(3)}</td>");
                html.Append($"<td>{reader.GetInt32(4)}</td>");
                html.Append($"<td>{reader.GetString(5)}</td>");


                html.Append("</tr>");
            }


            html.Append("<tr><td colspan=7></td></tr>");
            html.Append("</table>");
            if (info != "")
            {
                html.Append("<p>Total Monthly Sales</p>");
                html.Append($"<p>{info}</p>");
            }

            html.Append("</body></html>");

            reader.Close();
            return html;
        }

        public static void PrintMonthlySales(StringBuilder html)
        {

            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            DateTime today = DateTime.Now;
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/{today.ToString("yyyy-MM-dd-HHmmss")}MonthlySales.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/{today.ToString("yyyy-MM-dd-HHmmss")}MonthlySales.html");
            
            using (StreamWriter wr = new StreamWriter($"{filePath}/{today.ToString("yyyy-MM-dd-HHmmss")} - MonthlySales.html"))
            {
                wr.WriteLine(html);
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder GenerateReceipt(List<string> strListItems,List<int> intQuantity, List<double> dblCardPrice, double dblPriceOfPurchase, double dblPriceOfPurchaseTax)
        {
            
                StringBuilder html = new StringBuilder();
                StringBuilder css = new StringBuilder();


                css.Append("<style>");
                css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
                css.Append("</style>");

                html.Append("<html>");
                html.Append($"<head>{css}<title>{"Order Receipt"}</title></head>");
                html.Append($"<body>");
                html.Append($"<h1>{"Your Order has been processed"}</h1>");


                html.Append($"<ul>");

                for (int i = 0; i < strListItems.Count; i++)
                {
                    html.Append($"<li>{intQuantity[i].ToString()} copies of {strListItems[i]}----{dblCardPrice[i].ToString("C2")}</li>");
                }
                html.Append("</ul>");
                html.Append($"<p>Subtotal: {dblPriceOfPurchase.ToString("C2")}</p>");
                html.Append($"<p>Tax: {(dblPriceOfPurchaseTax - dblPriceOfPurchase).ToString("C2")}</p>");
                html.Append($"<p>Total After Taxes: {dblPriceOfPurchaseTax.ToString("C2")}");

                html.Append("</body></html>");
            return html;
            
            
        }

        public static void PrintReceiept(StringBuilder html)
        {
                string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                try
                {
                    using (StreamWriter wr = new StreamWriter($"{filePath}/Receipt.html"))
                    {
                        wr.WriteLine(html);
                    }
                    System.Diagnostics.Process.Start($@"{filePath}/Receipt.html");

                    using (StreamWriter wr = new StreamWriter($"{filePath}/Receipt.html"))
                    {
                        wr.WriteLine(html);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            
        }

        public static StringBuilder GenerateInventoryReceipt(double dblPriceOfPurchase, string strCardName, int intQuantity)
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();


            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"Inventory Order Receipt"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"Your Order Placement Has Been Processed"}</h1>");

            html.Append($"{intQuantity} copies of the product {strCardName} have been purchased.");
            html.Append($"<p>Tax: {((dblPriceOfPurchase * 0.825) - dblPriceOfPurchase).ToString("C2")}</p>");
            html.Append($"<p>Subtotal: {dblPriceOfPurchase.ToString("C2")}</p>");
            html.Append($"<p>Total After Taxes: {(dblPriceOfPurchase + (dblPriceOfPurchase * 0.0825)).ToString("C2")}");

            html.Append("</body></html>");

            return html;
        }

        public static void PrintInventoryReceipt(StringBuilder html, string strCardName)
        {
            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string strName = strCardName;
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/{strName}-InventoryReceipt.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/{strName}-InventoryReceipt.html");
            
            using (StreamWriter wr = new StreamWriter($"{filePath}{strName}-InventoryReceipt.html"))
            {
                wr.WriteLine(html);
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }


        //********************HELP FILES
        public static StringBuilder AccessDetailHelp()
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();


            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"How to Open Card Details"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"How do I access a card's details?"}</h1>");

            html.Append($"<p>{"To access all the details relating to a card specifically, all you have to do is double click on the card's name!"}</p>");

            html.Append("</body></html>");

            return html;
        }

        public static void PrintAccessDetailHelp(StringBuilder html)
        {
            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/DetailHelp.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/DetailHelp.html");
           
            using (StreamWriter wr = new StreamWriter($"{filePath}/DetailHelp.html"))
            {
                wr.WriteLine(html);
            } 
            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder AddCartHelp()
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();


            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"How to Add an Item to my Cart"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"How do I add a card to my cart?"}</h1>");

            html.Append($"<p>{"Double click on the cards name and a form will pull up where you can click 'Add to Cart' and begin your shopping expereince!"}</p>");

            html.Append("</body></html>");

            return html;
        }

        public static void PrintAddCartHelp(StringBuilder html)
        {
            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/AddCart.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/AddCart.html");
            
            using (StreamWriter wr = new StreamWriter($"{filePath}/AddCart.html"))
            {
                wr.WriteLine(html);
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder ShowDetailHelp(Label lblEffect, Label lblType)
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();


            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"How to Read Card Details"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"What does {?} mean?"}</h1>");

            if (lblEffect.Text.Contains("{G}"))
            html.Append($"<p>{"The text {G} means that a green/forest mana is required to use an ability of the card."}</p>");

            if (lblEffect.Text.Contains("{W}"))
                html.Append($"<p>{"The text {W} means that a white/plains mana is required to use an ability of the card."}</p>");

            if (lblEffect.Text.Contains("{B}"))
                html.Append($"<p>{"The text {G} means that a black/swamp mana is required to use an ability of the card."}</p>");

            if (lblEffect.Text.Contains("{U}"))
                html.Append($"<p>{"The text {G} means that a island/blue t mana is required to use an ability of the card."}</p>");

            if (lblEffect.Text.Contains("{R}"))
                html.Append($"<p>{"The text {R} means that a red/mountain mana is required to use an ability of the card."}</p>");

            if (lblEffect.Text.Contains("{T}"))
                html.Append($"<p>{"The text {T} means that the card must be tapped in order to use an ability of the card."}</p>");

            if (lblType.Text.Contains("Creature"))
                html.Append($"<p>{"The text at the end of the description means that the card has X attack power and X health, where the power is the first number before the slash and their health is the number after.\n There are also cards that have X in these positions! The values for those cards are dependent on the effects of the card-be sure to read carefully!"}</p>");

            html.Append("</body></html>");

            return html;
        }

        public static void PrintShowDetailHelp(StringBuilder html)
        {

            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/DetailHelp.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/DetailHelp.html");
            
            using (StreamWriter wr = new StreamWriter($"{filePath}/DetailHelp.html"))
            {
                wr.WriteLine(html);
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder CardCostHelp()
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();


            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"Card Cost vs Card Price"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"What is card cost?"}</h1>");

            html.Append($"<p>{"Card Cost refers to the mana cost required to use a card in game. \nThese costs are based around mana specifically with G as Green/Forest mana, R as Red/Mountain mana, W as White/Plains mana, B as Black/Swamp mana, U as Blue/Island mana, and C as colorless!"}</p>");

            html.Append("</body></html>");

            return html;
        }

        public static void PrintCardCostHelp(StringBuilder html)
        {
            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/CostHelp.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/CostHelp.html");
            
            using (StreamWriter wr = new StreamWriter($"{filePath}/CostHelp.html"))
            {
                wr.WriteLine(html);
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder FilterHelp()
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();


            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"How does the filter work?"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"How does the filter work?"}</h1>");

            html.Append($"<p>The filter works by taking into account the type of card and the colors in the cost to help narrow products for purchase!" +
                "\n This proccess can also be used to limit things exclusively(products that has one or the other) or inclusive(cards that require both or all selected check boxes)\nSimply check the boxes you want and your product list will shrink until you find what you're looking for!</p>");

            html.Append("</body></html>");

            return html;
        }

        public static void PrintFilterHelp(StringBuilder html)
        {
            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/FilterHelp.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/FilterHelp.html");
           
            using (StreamWriter wr = new StreamWriter($"{filePath}/FilterHelp.html"))
            {
                wr.WriteLine(html);
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder HireEmployeeHelp()
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();


            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"How to Hire"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"How do I add a new member to staff?"}</h1>");

            html.Append($"<p>{"Input all the information, make sure not to miss a textbox, then click the save button! Security levels must be 2 or 3 with 2 for standard employees and 3 for other managers!"}</p>");

            html.Append("</body></html>");

            return html;
        }

        public static void PrintHireEmployeeHelp(StringBuilder html)
        {
            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/HireEmployeeHelp.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/HireEmployeeHelp.html");
           
            using (StreamWriter wr = new StreamWriter($"{filePath}/HireEmployeeHelp.html"))
            {
                wr.WriteLine(html);
            }

            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder FireEmployeeHelp()
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();


            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"How to Fire"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"How do I remove a member to staff?"}</h1>");

            html.Append($"<p>{"Select their username in the provided table then click the Remove button and that employee will be cleared from our employee table-This will not affect the tournament table."}</p>");

            html.Append("</body></html>");

            return html;
        }

        public static void PrintFireEmployeeHelp(StringBuilder html)
        {

            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/FireEmployeeHelp.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/FireEmployeeHelp.html");
           
            using (StreamWriter wr = new StreamWriter($"{filePath}/FireEmployeeHelp.html"))
            {
                wr.WriteLine(html);
            } }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder ScheduleTypeHelp()
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();


            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"Schedule Types"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"What are Schedule Types?"}</h1>");

            html.Append($"<p>{"Schedule Types are our format of a work week.\nOur Employees work static schedules until a manager changes them.\n0 means off\n1 is a morning shift (7-4)\n2 is a mid shift(10-7)\n3 is a closing shift(2-11)"}</p>");

            html.Append("</body></html>");

            return html;
        }

        public static void PrintScheduleTypeHelp(StringBuilder html)
        {
            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/ScheduleTypeHelp.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/ScheduleTypeHelp.html");
            
            using (StreamWriter wr = new StreamWriter($"{filePath}/ScheduleTypeHelp.html"))
            {
                wr.WriteLine(html);
            }}
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder SalesHelp()
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();


            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"What is a sale?"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"What does 'OnSale' Mean?"}</h1>");

            html.Append($"<p>{"All items on sale are half off! Most times these are due to overstock or due to a fresh copy of the card beginning to be printed! Or the abundance of a rival color in the meta!"}</p>");

            html.Append("</body></html>");

            return html;
        }

        public static void PrintSalesHelp(StringBuilder html)
        {
            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/SalesHelp.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/SalesHelp.html");
           
            using (StreamWriter wr = new StreamWriter($"{filePath}/SalesHelp.html"))
            {
                wr.WriteLine(html);
            } }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        public static StringBuilder SaveNewCardHelp()
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();


            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"How Do I Save a New Card?"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"How Do I Save a New Card?"}</h1>");

            html.Append($"<p>{"First you have to click 'Add New Card Image' and select an image in .png or .jpg format."}</p>");

            html.Append($"<p>{"After your image is uploaded it will fill in a picture box on the left of the screen"}</p>");

            html.Append($"<p>{"Enter the rest of the information for the card on the right and hit 'Save New Card' and if your information is valid your new card will be ready for purchase."}</p>");

            html.Append("</body></html>");

            return html;
        }

        public static void PrintSaveNewCardHelp(StringBuilder html)
        {
            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/SaveNew.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/SaveNew.html");
           
            using (StreamWriter wr = new StreamWriter($"{filePath}/SaveNew.html"))
            {
                wr.WriteLine(html);
            } }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }


        public static StringBuilder DevotionSaleHelp()
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();


            css.Append("<style>");
            css.Append("td {padding:5px;text-align:center;font-weight:bold;text-align:center}");
            css.Append("</style>");

            html.Append("<html>");
            html.Append($"<head>{css}<title>{"What is a Devotion Sale?"}</title></head>");
            html.Append($"<body>");
            html.Append($"<h1>{"What is a Devotion Sale?"}</h1>");

            html.Append($"<p>{"Devotion Sales are how we at Jester's Menagerie give back to our community"}</p>");

            html.Append($"<p>{"Managers have the capability to select a color of card (Black, blUe, Green, Red, White) and put it on sale for a previously agreed upon percentage."}</p>");

            html.Append($"<p>{"For entering the sale percentage all you have to do is type a number under 99."}</p>");

            html.Append($"<p>{"If there is a sale for 30% all you enter is '30', for 27% you enter '27' and so on."}</p>");

            html.Append("</body></html>");

            return html;
        }

        public static void PrintDevotionSaleHelp(StringBuilder html)
        {
            string filePath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            try
            {
                using (StreamWriter wr = new StreamWriter($"{filePath}/DevotionSale.html"))
                {
                    wr.WriteLine(html);
                }
                System.Diagnostics.Process.Start($@"{filePath}/DevotionSale.html");
            
            using (StreamWriter wr = new StreamWriter($"{filePath}/DevotionSale.html"))
            {
                wr.WriteLine(html);
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
    }
}
