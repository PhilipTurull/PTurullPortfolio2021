﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;
using System.Drawing;

namespace SP21_Final_Project
{
    class ProgOps
    {
        //connection string
        private const string CONNECT_STRING = @"Server=cstnt.tstc.edu;Database=inew2332sp21;User Id = TurullPsp212332; password=1722872";
        //build a connection to database
        private static SqlConnection _cntDatabase = new SqlConnection(CONNECT_STRING);

        public static void CloseDatabaseDispose()
        {
            //close connection
            _cntDatabase.Close();
            //dispose of the connection object and command, adapter and table objects
            _cntDatabase.Dispose();
        }

             
       //**********************EMPLOYEES
        //add the command object
        public static SqlCommand _sqlEmployeesCommand;
        //add the data adapter
        public static SqlDataAdapter _daEmployees = new SqlDataAdapter();
        //add the data table
        public static DataTable _dtEmployeesTable = new DataTable();

        //**********************MANAGE EMPLOYEES
        //add the command object
        public static SqlCommand _sqlManageEmployeesCommand;
        //add the data adapter
        public static SqlDataAdapter _daManageEmployees = new SqlDataAdapter();
        //add the data table
        public static DataTable _dtManageEmployeesTable = new DataTable();

        //**********************EMPLOYEE---SCHEDULES
        //add the command object
        public static SqlCommand _sqlEmployeeScheduleCommand;
        //add the data adapter
        public static SqlDataAdapter _daEmployeeSchedule = new SqlDataAdapter();
        //add the data table
        public static DataTable _dtEmployeeScheduleTable = new DataTable();

        //**********************CARDS
        //objects for the Cards table
        public static SqlCommand _sqlCardsCommand;
        //add the data adapter
        public static SqlDataAdapter _daCards = new SqlDataAdapter();
        //add the data table
        public static DataTable _dtCardsTable = new DataTable();

        //**********************CARD
        //objects for the Card Form
        public static SqlCommand _sqlCardCommand;
        //add the data adapter
        public static SqlDataAdapter _daCard = new SqlDataAdapter();
        //add the data table
        public static DataTable _dtCardTable = new DataTable();

        //**********************ORDERS
        //objects for the Orders table
        public static SqlCommand _sqlOrdersCommand;
        //add the data adapter
        public static SqlDataAdapter _daOrders = new SqlDataAdapter();
        //add the data table
        public static DataTable _dtOrdersTable = new DataTable();

        //**********************INVENTORY
        //objects for the Orders table
        public static SqlCommand _sqlInventoryCommand;
        //add the data adapter
        public static SqlDataAdapter _daInventory = new SqlDataAdapter();
        //add the data table
        public static DataTable _dtInventoryTable = new DataTable();

        //**********************TOURNEYS
        //objects for the Tourney table
        public static SqlCommand _sqlTourneyCommand;
        //add the data adapter
        public static SqlDataAdapter _daTourney = new SqlDataAdapter();
        //add the data table
        public static DataTable _dtTourneyTable = new DataTable();

        //**********************LOGGIN
        //objects for Login
        public static SqlCommand _sqlLoginCommand;
        //add the data adapter
        public static SqlDataAdapter _daLogin = new SqlDataAdapter();
        //add the data table
        public static DataTable _dtLoginTable = new DataTable();

        //**********************DAYSALES
        public static SqlCommand _sqlDailySales;
        //add the data adapter
        public static SqlDataAdapter _daDailySales = new SqlDataAdapter();
        //add the data table
        public static DataTable _dtDailySales = new DataTable();

        //*********************WEEKSALES
        public static SqlCommand _sqlWeeklySales;
        //add the data adapter
        public static SqlDataAdapter _daWeeklySales = new SqlDataAdapter();
        //add the data table
        public static DataTable _dtWeeklySales = new DataTable();

        //********************MONTHLYSALES
        public static SqlCommand _sqlMonthlySales;
        //add the data adapter
        public static SqlDataAdapter _daMonthlySales = new SqlDataAdapter();
        //add the data table
        public static DataTable _dtMonthlySales = new DataTable();


        public static List<Images> lstImageHolder = new List<Images>();

        public static string strQuery = "";

        public class Images
        {
            public int ImageID { get; set; }
            public byte[] Image { get; set; }
            public Images()
            {
                //empty constructor so I can call for the reader
            }
        }

        public static void OpenDatabase()
        {
            try
            {
                _cntDatabase.Open();

            }catch(Exception)
            {
                _cntDatabase.Close();
                OpenDatabase();
            }
        }
        

        public static void DatabaseCommandEmp(DataGridView dgvData)
        {//Fills employee table for managing hires
            try
            {
                //string to build the query
                strQuery = "select EmployeeID, name from TurullPsp212332.Employees Order by EmployeeID;";
                //establish command object
                _sqlManageEmployeesCommand = new SqlCommand(strQuery, _cntDatabase);
                //establish data adapter
                _daManageEmployees = new SqlDataAdapter();
                _daManageEmployees.SelectCommand = _sqlManageEmployeesCommand;
                //fill data table
                _dtManageEmployeesTable = new DataTable();
                _daManageEmployees.Fill(_dtManageEmployeesTable);

                dgvData.DataSource = _dtManageEmployeesTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in establishing Employees Table. Error 301.", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }


        public  static void DatabasesCommandUpdateEmp(TextBox tbxUsername, TextBox tbxPassword, TextBox tbxQuestion, TextBox tbxResponse, frmMain main)
        {//This loads in the employees own information
            try
            {
                //string to build the query
                string query = $"SELECT Username, Password, SecurityQuestion, SecurityResponse FROM TurullPsp212332.Employees where username = '{main.strUsername}';";

                //establish command object
                _sqlEmployeesCommand = new SqlCommand(query, _cntDatabase);

                //establish data adapter
                _daEmployees = new SqlDataAdapter();
                _daEmployees.SelectCommand = _sqlEmployeesCommand;

                //fill data table
                _dtEmployeesTable = new DataTable();
                _daEmployees.Fill(_dtEmployeesTable);

                //bind controls to the textboxes
                tbxUsername.DataBindings.Add("Text", _dtEmployeesTable, "username");
                tbxPassword.DataBindings.Add("Text", _dtEmployeesTable, "password");
                tbxQuestion.DataBindings.Add("Text", _dtEmployeesTable, "SecurityQuestion");
                tbxResponse.DataBindings.Add("Text", _dtEmployeesTable, "SecurityResponse");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in establishing Employee Information. Error 301.", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }

        }

        public static void DatabaseCommandCommitUpdate(string strUsername, string strPassword, string strQuestion, string strResponse, frmMain main)
        {//this commits the updates to the database

            string CommitQuery = $"update turullpsp212332.Employees set username = '{strUsername}', password = '{strPassword}', SecurityQuestion = '{strQuestion}', SecurityResponse = '{strResponse}' where username = '{main.strUsername}';";
            try
            {

                SqlCommand myCommand = new SqlCommand(CommitQuery, _cntDatabase);

                myCommand.ExecuteNonQuery();

                main.strUsername = strUsername;
                main.strPassword = strPassword;

            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in commiting Employee Information. Error 301.", MessageBoxButtons.OK,
                   MessageBoxIcon.Error);
            }

        }

        //************************************************************************************SCHEDULES
        public static void DatabaseCommandSch(string strCriteria, DataGridView dgvData)
        {//Loads in the employees weekly schedule
            try
            {
                //string to build the query
                strQuery = "select username as 'Employee Username', Position as 'Position', ClockIn as 'Clock In Time', LunchStart as 'Lunch Start', LunchEnd as 'Expected Return', ClockOut as 'Shift End'," +
                        " ScheduleTypeMon as 'ScheduleType'"+
                        $" from TurullPsp212332.Employees, TurullPsp212332.Schedules where ScheduleTypeMon = TurullPsp212332.Schedules.ScheduleType {strCriteria} group by EmployeeID, username, Position, Clockin, BreakOne, LunchStart, LunchEnd, BreakTwo, ClockOut, ScheduleTypeMon" +
                        " union all "+
                        " select username as 'Employee Username', Position as 'Position', ClockIn as 'Clock In Time', LunchStart as 'Lunch Start', LunchEnd as 'Expected Return', ClockOut as 'Shift End'," +
                        " ScheduleTypeTues as 'ScheduleType'" +
                        $" from TurullPsp212332.Employees, TurullPsp212332.Schedules where ScheduleTypeTues = TurullPsp212332.Schedules.ScheduleType {strCriteria} group by EmployeeID, username, Position, Clockin, BreakOne, LunchStart, LunchEnd, BreakTwo, ClockOut, ScheduleTypeTues" +
                        " union all "+
                        " select username as 'Employee Username', Position as 'Position', ClockIn as 'Clock In Time', LunchStart as 'Lunch Start', LunchEnd as 'Expected Return', ClockOut as 'Shift End'," +
                        " ScheduleTypeWed as 'ScheduleType'" +
                        $" from TurullPsp212332.Employees, TurullPsp212332.Schedules where ScheduleTypeWed = TurullPsp212332.Schedules.ScheduleType {strCriteria} group by EmployeeID, username, Position,Clockin, BreakOne, LunchStart, LunchEnd, BreakTwo, ClockOut, ScheduleTypeWed" +
                        " union all"+
                        " select username as 'Employee Username', Position as 'Position', ClockIn as 'Clock In Time', LunchStart as 'Lunch Start', LunchEnd as 'Expected Return', ClockOut as 'Shift End'," +
                        " ScheduleTypeThur as 'ScheduleType'" +
                        $" from TurullPsp212332.Employees, TurullPsp212332.Schedules where ScheduleTypeThur = TurullPsp212332.Schedules.ScheduleType {strCriteria} group by EmployeeID, username, Position, Clockin, BreakOne, LunchStart, LunchEnd, BreakTwo, ClockOut, ScheduleTypeThur" +
                        " union all"+
                        " select username as 'Employee Username', Position as 'Position', ClockIn as 'Clock In Time', LunchStart as 'Lunch Start', LunchEnd as 'Expected Return', ClockOut as 'Shift End'," +
                        " ScheduleTypeFri as 'ScheduleType'" +
                        $" from TurullPsp212332.Employees, TurullPsp212332.Schedules where ScheduleTypeFri = TurullPsp212332.Schedules.ScheduleType {strCriteria} group by EmployeeID, username, Position, Clockin, BreakOne, LunchStart, LunchEnd, BreakTwo, ClockOut, ScheduleTypeFri" +
                        " union all"+
                        " select username as 'Employee Username', Position as 'Position', ClockIn as 'Clock In Time', LunchStart as 'Lunch Start', LunchEnd as 'Expected Return', ClockOut as 'Shift End'," +
                        " ScheduleTypeSat as 'ScheduleType'" +
                        $" from TurullPsp212332.Employees, TurullPsp212332.Schedules where ScheduleTypeSat = TurullPsp212332.Schedules.ScheduleType {strCriteria} group by EmployeeID, username,Position, Clockin, BreakOne, LunchStart, LunchEnd, BreakTwo, ClockOut, ScheduleTypeSat" +
                        " union all"+
                        " select username as 'Employee Username', Position as 'Position', ClockIn as 'Clock In Time', LunchStart as 'Lunch Start', LunchEnd as 'Expected Return', ClockOut as 'Shift End'," +
                        " ScheduleTypeSun as 'ScheduleType'" +
                        $" from TurullPsp212332.Employees, TurullPsp212332.Schedules where ScheduleTypeSun = TurullPsp212332.Schedules.ScheduleType {strCriteria} group by EmployeeID, username, Position, Clockin, BreakOne, LunchStart, LunchEnd, BreakTwo, ClockOut, ScheduleTypeSun order by username";
                //establish command object
                _sqlEmployeeScheduleCommand = new SqlCommand(strQuery, _cntDatabase);
                //establish data adapter
                _daEmployeeSchedule = new SqlDataAdapter();
                _daEmployeeSchedule.SelectCommand = _sqlEmployeeScheduleCommand;
                //fill data table
                _dtEmployeeScheduleTable = new DataTable();
                _daEmployeeSchedule.Fill(_dtEmployeeScheduleTable);

                dgvData.DataSource = _dtEmployeeScheduleTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in establishing Employee Schedule Table. Error 301.", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        public static  void DatabaseCommandScheduleSwapPrev(string strDay, string strUsername, TextBox PreviousShift)
        {//This gets the previous value stored in the selected day's scheduletype
            //These get stored as "ScheduleType'Mon'", "ScheduleType'Tues'", "ScheduleType'Wed'" and so on
            string strDayCommand = "";
            if(strDay == "Monday")
            {
                strDayCommand = "Mon"; 
            }
            if (strDay == "Tuesday")
            {
                strDayCommand = "Tues";
            }
            if (strDay == "Wednesday")
            {
                strDayCommand = "Wed";
            }
            if (strDay == "Thursday")
            {
                strDayCommand = "Thur";
            }
            if (strDay == "Friday")
            {
                strDayCommand = "Fri";
            }
            if (strDay == "Saturday")
            {
                strDayCommand = "Sat";
            }
            if (strDay == "Sunday")
            {
                strDayCommand = "Sun";
            }

            try
            {
                //string to build the query
                string query = $"SELECT ScheduleType{strDayCommand} FROM TurullPsp212332.Employees  where Username = '{strUsername}'";

                SqlCommand cmdSchedule = new SqlCommand();

                cmdSchedule = new SqlCommand(query, _cntDatabase);
                SqlDataReader sqlReader = cmdSchedule.ExecuteReader();


                int PreviousShiftType = 0;
                if (sqlReader.Read())
                {
                    var varShiftType = sqlReader[$"ScheduleType{strDayCommand}"];

                    int.TryParse(varShiftType.ToString(), out PreviousShiftType);
                }

                PreviousShift.Text = PreviousShiftType.ToString();

                sqlReader.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in collecting previous employee shift type. Error 301.", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
        public static void DatabaseCommandInsertShiftSwap(string strUserName, string tbxReasonText, TextBox tbxPreviousType, TextBox tbxNewType, string strDay)
        {//this inserts the value from the Reason and Desired type textboxes to the asked day


            string strDayCommand = "";
            if (strDay == "Monday")
            {
                strDayCommand = "Mon";
            }
            if (strDay == "Tuesday")
            {
                strDayCommand = "Tues";
            }
            if (strDay == "Wednesday")
            {
                strDayCommand = "Wed";
            }
            if (strDay == "Thursday")
            {
                strDayCommand = "Thur";
            }
            if (strDay == "Friday")
            {
                strDayCommand = "Fri";
            }
            if (strDay == "Saturday")
            {
                strDayCommand = "Sat";
            }
            if (strDay == "Sunday")
            {
                strDayCommand = "Sun";
            }

            //doubles up apostrophes for the escape sequence
            if(tbxReasonText.Contains("'"))
            {
                tbxReasonText.Replace("'", "''");
            }

            string swapQuery = $"INSERT INTO Turullpsp212332.ShiftSwap (EmployeeUsername, CurrentShiftType, WantedShiftType, ReasonForShift, DayRequested) VALUES ('{strUserName}', {tbxPreviousType.Text}, {tbxNewType.Text}, '{tbxReasonText}', '{strDayCommand}')";

            SqlCommand myCommand = new SqlCommand(swapQuery, _cntDatabase);


            myCommand.ExecuteNonQuery();
        }



        public static void DatabaseCommandProd(DataGridView dgvData, string strCommand)
        {//Loads in the dgv
            try
            {
                //string to build query 
                strQuery = strCommand + " order by CardName";

                //establish cmb obj
                _sqlCardsCommand = new SqlCommand(strQuery, _cntDatabase);

                _daCards = new SqlDataAdapter();
                _daCards.SelectCommand = _sqlCardsCommand;
                //fill data table
                _dtCardsTable = new DataTable();
                _daCards.Fill(_dtCardsTable);

                dgvData.DataSource = _dtCardsTable;
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in establishing Cards Table. Error 302.", MessageBoxButtons.OK,
                  MessageBoxIcon.Error);
            }
        }


        //************************************************************************************LOAD SPECIFIC CARD INFO
        public static void DatabaseCommandCardView(Label lblCardName, Label lblCardCost, Label lblCardType, Label lblCardEffect, PictureBox pbCardImage, string strCardName, Label lblCardPrice, Label lblOnSale, Label lblPercentOff, Label lblQuantity)
        {

            try
            {
                //string to build the query
                string query = $"SELECT CardName, CardCost, CardType, CardEffect, CardImage, CardPrice, OnSale, PercentOff, Quantity FROM TurullPsp212332.ProductPictures, TurullPsp212332.ProductInfo  where CardName = '{strCardName}' and  TurullPsp212332.ProductPictures.CardImageIndex = TurullPsp212332.ProductInfo.cardImageIndex;";
                //establish command object
                _sqlCardCommand = new SqlCommand(query, _cntDatabase);
                //establish data adapter
                _daCard = new SqlDataAdapter();
                _daCard.SelectCommand = _sqlCardCommand;
                //fill data table
                //_dtCardTable = new DataTable();
                //_daCard.Fill(_dtCardTable);
                ////bind controls to the textboxes
                //lblCardName.DataBindings.Add("Text", _dtCardTable, "CardName");
                //lblCardCost.DataBindings.Add("Text", _dtCardTable, "CardCost");
                //lblCardType.DataBindings.Add("Text", _dtCardTable, "CardType");
                //lblCardEffect.DataBindings.Add("Text", _dtCardTable, "CardEffect");
                //lblCardPrice.DataBindings.Add("Text", _dtCardTable, "CardPrice");
                //lblOnSale.DataBindings.Add("Text", _dtCardTable, "OnSale");
                //lblPercentOff.DataBindings.Add("Text", _dtCardTable, "format(PercentOff,'#,##0%')");

                SqlDataReader sqlReader = _sqlCardCommand.ExecuteReader();


                if (sqlReader.Read())
                {
                    var varCardName = sqlReader["CardName"];
                    var varCardCost = sqlReader["CardCost"];
                    var varCardType = sqlReader["CardType"];
                    var varCardEffect = sqlReader["CardEffect"];
                    var varCardPrice = sqlReader["CardPrice"];
                    var varOnSale = sqlReader["OnSale"];
                    var varPercentOff = sqlReader["PercentOff"];
                    var varQuantity = sqlReader["Quantity"];

                    lblCardName.Text = varCardName.ToString();
                    lblCardCost.Text = varCardCost.ToString();
                    lblCardEffect.Text = varCardEffect.ToString();
                    lblCardType.Text = varCardType.ToString();
                    lblCardPrice.Text = varCardPrice.ToString();
                    lblOnSale.Text = varOnSale.ToString();
                    lblPercentOff.Text = varPercentOff.ToString() + "%";
                    lblQuantity.Text = varQuantity.ToString();

                }
                sqlReader.Close();
                //load in the card's image
                ReloadImage(pbCardImage, strCardName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in establishing Card Form. Error 301.", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }



        //********************************************************LOAD ORDERS
        public static void DatabaseCommandOrd(string strCriteria, DataGridView dgvData)
        {//This pulls in all orders and their relative information
            //Criteria determines wether to take the entire dataset or a dataset relative to the user
            try
            {
                //string to build query 
                strQuery = $"declare @TotalSaleOfOrder money;"
                + "\nset @TotalSaleOfOrder = (select top 1 sum(o.totalPrice) as 'Total Sales' from TurullPsp212332.Orders o)"
                + $"\nselect O.OrderID as 'Order ID', o.CustomerUsername as 'Customer',  O.OrderDate as 'Order Date', D.CardName as 'Card Name', Format(p.CardPrice, 'C') as 'Card Price', D.Quantity, format(o.TotalPrice, 'C') as 'Price of Order', format(@TotalSaleOfOrder, 'C') as 'Total of all Sales' from TurullPsp212332.Orders o, TurullPsp212332.OrderDetails d, TurullPsp212332.ProductInfo as P where O.OrderID = D.OrderID and d.CardName = p.CardName {strCriteria} Order by o.orderID;";


                //establish cmb obj
                _sqlOrdersCommand = new SqlCommand(strQuery, _cntDatabase);

                _daOrders = new SqlDataAdapter();
                _daOrders.SelectCommand = _sqlOrdersCommand;
                //fill data table
                _dtOrdersTable = new DataTable();
                _daOrders.Fill(_dtOrdersTable);

                dgvData.DataSource = _dtOrdersTable;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in establishing Orders Table. Error 302.", MessageBoxButtons.OK,
                  MessageBoxIcon.Error);
            }
        }


       //******************************************LOAD TOURNEY INFORMATION
        public static void DatabaseCommandTourney(DataGridView dgvData)
        {
            try
            {
                //string to build query 
                strQuery = "select TourneyName as 'Tournament Name', Ruleset, StartTime, EndTime, SetDate, Referee  from TurullPsp212332.TourneyInfo; ";

                //establish cmb obj
                _sqlTourneyCommand = new SqlCommand(strQuery, _cntDatabase);

                _daTourney = new SqlDataAdapter();
                _daTourney.SelectCommand = _sqlTourneyCommand;
                //fill data table
                _dtTourneyTable = new DataTable();
                _daTourney.Fill(_dtTourneyTable);

                dgvData.DataSource = _dtTourneyTable;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in establishing Tourney Table. Error 302.", MessageBoxButtons.OK,
                  MessageBoxIcon.Error);
            }
        }

        public static void DatabaseCommandUpdateSales(string strSelectedDevotion, double SalesPercentage)
        {
            double dblSalesPercent = SalesPercentage/100;

            string strQuery = "Update turullpsp212332.ProductInfo set OnSale = 'No', PercentOff = 0";
            SqlCommand strCommand = new SqlCommand(strQuery, _cntDatabase);
            strCommand.ExecuteNonQuery();

            string strNewQuery = $"Update Turullpsp212332.ProductInfo set OnSale = 'Yes', PercentOff = {dblSalesPercent} where CardCost like '%{strSelectedDevotion}%'";
            SqlCommand strNewCommand = new SqlCommand(strNewQuery, _cntDatabase);
            strNewCommand.ExecuteNonQuery();


        }

        //************************************************************************************LOAD IMAGES
        public static void ReloadImage(PictureBox pbxBox, string strCardName)
        { 
            string strCommand = $"SELECT CardIndex, CardImage FROM TurullPsp212332.ProductPictures, TurullPsp212332.ProductInfo  where CardName = '{strCardName}' and  TurullPsp212332.ProductPictures.CardImageIndex = TurullPsp212332.ProductInfo.cardImageIndex;";

            SqlCommand SelectCommand = new SqlCommand(strCommand, _cntDatabase);
            SqlDataReader sqlReader;

                sqlReader = SelectCommand.ExecuteReader();

                while (sqlReader.Read())
                {
                    Images image = new Images();
                    image.ImageID = sqlReader.GetInt32(0);
                    image.Image = (byte[])sqlReader[1];
                    lstImageHolder.Add(image); // Add image object to the holder before being cleared
                }
                sqlReader.Close();
            if (lstImageHolder.Count > 0)
            {
                using (MemoryStream ms = new MemoryStream(lstImageHolder[0].Image))
                {
                    Image image = Image.FromStream(ms);
                    pbxBox.Image = image;
                }
            }
            
        }


        //************************************************************************************LOGIN 
        //Checks the login information in the textboxes against the customers database
        public static void DatabaseCommandLogginCustomers(TextBox tbxUser, TextBox tbxPass, frmMain Main, frmLogin LoginScreen)
        {
            string sql = "Select * from TurullPsp212332.Customers where Username like'" + tbxUser.Text.Replace("'", "''") + "'and password like'" + tbxPass.Text.Replace("'", "''") + "'";
            try
            {
                SqlCommand cmdLogin = new SqlCommand();

                cmdLogin = new SqlCommand(sql, _cntDatabase);
                SqlDataReader sqlReader = cmdLogin.ExecuteReader();

                string UserName = "", Password = "";
                int SecurityLevel = 0;


                if (sqlReader.Read())
                {
                    var varUsername = sqlReader["username"];
                    var varPassword = sqlReader["password"];
                    var varSecurityLevel = sqlReader["SecurityLevel"].ToString();


                    UserName = varUsername.ToString();
                    Password = varPassword.ToString();
                    int.TryParse(varSecurityLevel, out SecurityLevel);
                }

                //sets values for the main form for use later
                Main.strUsername = UserName;
                Main.strPassword = Password;
                Main.intSecurityLevel = SecurityLevel;

                Main.grantRemoveAccess();

                if (SecurityLevel != 0)
                {
                    LoginScreen.blnLoginSuccessful = true;
                }

                if (Main.intSecurityLevel > 0)
                {
                    LoginScreen.Close();
                }
                //if there is nothing to read from the database and the information in the textboxes are invalid for the customers table then check the employees
                if (!sqlReader.Read() && (Password == "" || UserName == ""))
                {
                    sqlReader.Close();
                    DatabaseCommandLogginEmployees(tbxUser, tbxPass, Main, LoginScreen);
                }

                sqlReader.Close();
            }catch(Exception)
            {
                MessageBox.Show("Sorry there was an error attempting Login, please try again.", "Error Logging in", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //checks the employee table with the login credentials passed from the customers database command
        public static void DatabaseCommandLogginEmployees(TextBox tbxUser, TextBox tbxPass, frmMain Main, frmLogin LoginScreen)
        {
            string sql = "Select * from TurullPsp212332.Employees where Username like'" + tbxUser.Text.Replace("'", "''") + "'and password like'" + tbxPass.Text.Replace("'", "''") + "'";

            SqlCommand cmdLogin = new SqlCommand();

            cmdLogin = new SqlCommand(sql, _cntDatabase);
            SqlDataReader sqlReader = cmdLogin.ExecuteReader();

            string UserName = "", Password = "";
            int SecurityLevel = 0;

            DialogResult dlgResult;
            try
            {
                if (sqlReader.Read())
                {
                    var varUsername = sqlReader["username"];
                    var varPassword = sqlReader["password"];
                    var varSecurityLevel = sqlReader["SecurityLevel"].ToString();


                    UserName = varUsername.ToString();
                    Password = varPassword.ToString();
                    int.TryParse(varSecurityLevel, out SecurityLevel);

                }
                //sets values for the main form for use later
                Main.strUsername = UserName;
                Main.strPassword = Password;
                Main.intSecurityLevel = SecurityLevel;

                Main.grantRemoveAccess();

                if (Main.intSecurityLevel > 0)
                {
                    LoginScreen.Close();
                }
                //if there is nothing to read from the database and the information in the textboxes are invalid then ask if they wish to sign up
                if (!sqlReader.Read() && (Password == "" || UserName == ""))
                {
                    dlgResult = MessageBox.Show("Sorry, this username and/or password are not in our system, would you like to sign up?", "Invalid Login Credentials", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (dlgResult == System.Windows.Forms.DialogResult.Yes)
                    {
                        LoginScreen.blnSignUp = true;
                    }
                }


                sqlReader.Close();
            }catch(Exception)
            {
                MessageBox.Show("Sorry there was an error attempting Login, please try again.", "Error Logging in", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }


        //************************************************************************************RECOVER
        public static string DatabaseCommandRecoverCustUser(TextBox tbxUser, frmMain main)
        {
            string sql = "Select * from TurullPsp212332.Customers where Username like'" + tbxUser.Text + "';";

            SqlCommand cmdLogin = new SqlCommand();

            cmdLogin = new SqlCommand(sql, _cntDatabase);
            SqlDataReader sqlReader = cmdLogin.ExecuteReader();

            string UserName = "";

            if (sqlReader.Read())
            {
                var varUsername = sqlReader["username"];

                UserName = varUsername.ToString();
            }

            sqlReader.Close();
            //sets values for the main form for use later
            return UserName;

        }

        public static string DatabaseCommandRecoverEmployees(TextBox tbxUser, frmMain main)
        {
            string sql = "Select * from TurullPsp212332.Employees where Username like'" + tbxUser.Text + "';";

            SqlCommand cmdLogin = new SqlCommand();

            cmdLogin = new SqlCommand(sql, _cntDatabase);
            SqlDataReader sqlReader = cmdLogin.ExecuteReader();

            string strUserName = "";

            if (sqlReader.Read())
            {
                var varUsername = sqlReader["username"];
                var varBlnFirstLogin = sqlReader["FirstLogin"].ToString();

                strUserName = varUsername.ToString();
            }
            sqlReader.Close();
            //sets values for the main form for use later
            return strUserName;

        }


        //*****************************************LOAD RECOVERY QUESTIONS
        public static string LoadRecoveryQuestions(string strCustEmp, string strUser)
        {
            string sql = $"Select * from TurullPsp212332.{strCustEmp} where Username like '{strUser}' ;";

            SqlCommand cmdLogin = new SqlCommand();

            cmdLogin = new SqlCommand(sql, _cntDatabase);
            SqlDataReader sqlReader = cmdLogin.ExecuteReader();

            string strSecQuestion = "";

            if (sqlReader.Read())
            {
                var varSecQuestion = sqlReader["SecurityQuestion"];

                strSecQuestion = varSecQuestion.ToString();
            }

            sqlReader.Close();
            //sets values for the main form for use later
            return strSecQuestion;
        }


        //**********************************RECOVERY VALIDATION
       public static bool ValidateRecovery(string strInsertedTable, string strUsername, TextBox tbxResponse)
       {
            string sql = $"Select * from TurullPsp212332.{strInsertedTable} where Username like '{strUsername.Replace("'", "''")}' ;";

            SqlCommand cmdLogin = new SqlCommand();

            cmdLogin = new SqlCommand(sql, _cntDatabase);
            SqlDataReader sqlReader = cmdLogin.ExecuteReader();

            string strSecResponse = "";
            string strRecoveredPassword = "";
            try
            {
                if (sqlReader.Read())
                {
                    var varSecResponse = sqlReader["SecurityResponse"];
                    var varPassword = sqlReader["Password"];

                    strSecResponse = varSecResponse.ToString();
                    strRecoveredPassword = varPassword.ToString();
                }
                sqlReader.Close();
                if (strSecResponse == tbxResponse.Text)
                {
                    return true;
                }
                else
                {
                    MessageBox.Show("Your response is incorrect, please check for any spelling errors", "Incorrect Security Answer", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
            }catch(Exception)
            {
                MessageBox.Show("There has been an error obtaining your response, Please try again.", "Error Validating Response", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
       }


        //*******************************************SAVE NEW PASSWORD
        public static void DatabaseCommandSavePassword(string strInsertedTable, string strUsername, TextBox tbxPassword)
        {
            string sql = $"Update TurullPsp212332.{strInsertedTable} set Password = '{tbxPassword.Text.Replace("'","''")}' where Username like '{strUsername.Replace("'", "''")}';";

            SqlCommand cmdSavePassword = new SqlCommand();

            cmdSavePassword = new SqlCommand(sql, _cntDatabase);
            try
            {
                cmdSavePassword.ExecuteNonQuery();

            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Updating Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //********************************GENERATE ORDERS
        public static bool DatabaseCommandMakeOrder(List<string> lstrOrderedCards, List<int> lintQuantity, double dblTotal, string strUsername)
        {
            bool blnWorked = false;

            string OrderQuery = $"INSERT INTO Turullpsp212332.Orders (CustomerUsername, OrderDate, TotalPrice) VALUES ('{strUsername}', GetDate(), {dblTotal});";
                OrderQuery += "\ndeclare @OrderID as int = (select top 1 orderID from TurullPsp212332.Orders order by orderID desc);";
                OrderQuery += "\nset @OrderID = (select top 1 orderID from TurullPsp212332.Orders order by orderID desc);";

            for(int i = 0; i < lstrOrderedCards.Count(); i++)
            {
                OrderQuery += $"\nInsert into TurullPsp212332.orderDetails(OrderID, CardName, Quantity) values(@OrderID,'{lstrOrderedCards[i].Replace("'", "''")}', {lintQuantity[i]});";
            }


            for (int i = 0; i < lstrOrderedCards.Count(); i++)
            {
                OrderQuery += $"\nUpdate TurullPsp212332.ProductInfo set Quantity = Quantity - {lintQuantity[i]} where CardName = '{lstrOrderedCards[i].Replace("'", "''")}';";

            }
            try
            {
                SqlCommand myCommand = new SqlCommand(OrderQuery, _cntDatabase);

                myCommand.ExecuteNonQuery();

                blnWorked = true;

            }catch (Exception ex)
            {
                blnWorked = false;
                MessageBox.Show("Sorry! There was an error in placing your order, please talk to an associate for help!", "Couldn't place order", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return blnWorked;
        }



        //*********************************************SCHEDULE SWAP
        public static void DatabaseCommandFillSwap(DataGridView dgvData)
        {
            try
            {
                //string to build the query
                strQuery = "select EmployeeUsername, DayRequested as 'Day Requested', CurrentShiftType as 'Current Shift', WantedShiftType as 'Desired Shift', ReasonForShift as 'Reason for Schedule Change'  from TurullPsp212332.ShiftSwap order by EmployeeUsername;";
                //establish command object
                _sqlEmployeesCommand = new SqlCommand(strQuery, _cntDatabase);
                //establish data adapter
                _daEmployees = new SqlDataAdapter();
                _daEmployees.SelectCommand = _sqlEmployeesCommand;
                //fill data table
                _dtEmployeesTable = new DataTable();
                _daEmployees.Fill(_dtEmployeesTable);
                //bind controls to the textboxes
                dgvData.DataSource = _dtEmployeesTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in establishing Employees Table. Error 301.", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        //****************************COMMIT SWAP
        public static void DatabaseCommandCommitSwap(string strDaySelected, string strNewShiftType, string strEmpUsername)
        {
            string query = $"Update TurullPsp212332.Employees set ScheduleType{strDaySelected} = {strNewShiftType} where username = '{strEmpUsername}';";
            try
            {
                SqlCommand myCommand = new SqlCommand(query, _cntDatabase);

                myCommand.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                MessageBox.Show("There as been an error in remotely placing your schedule swap request, please see your manager", "Error placing request", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            DatabaseCommandRemoveSwap(strEmpUsername, strDaySelected);  
        }


        public static void DatabaseCommandRemoveSwap(string strEmpUsername, string strDaySelected)
        {//This function is used to remove accepted schedule swaps from the database

            string query = $"delete from TurullPsp212332.ShiftSwap where Employeeusername = '{strEmpUsername}' and dayRequested = '{strDaySelected}';";

            SqlCommand myCommand = new SqlCommand(query, _cntDatabase);
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                MessageBox.Show("There as been an error in remotely placing your schedule swap request, please see your manager", "Error placing request", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        //**************************ADD NEW CUSTOMERS
        public static void DatabaseCommandCommitInsert(string strName, string strUsername, string strPassword, string strQuestion, string strResponse, frmMain main)
        {
            string query = $"insert into TurullPsp212332.Customers (SecurityLevel, Name, Username, Password, SecurityQuestion, SecurityResponse) values (1, '{strName}', '{strUsername}', '{strPassword}', '{strQuestion}', '{strResponse}');";

            SqlCommand myCommand = new SqlCommand(query, _cntDatabase);
            try
            {
                myCommand.ExecuteNonQuery();
            }catch(Exception ex)
            {
                MessageBox.Show("There has been an error signing up, please see an employee!", "Error signing up", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        //*********************FILL INVENTORY TABLE
        public static void DatabaseCommandFillInv(DataGridView dgvData)
        {
            try
            {
                //string to build the query
                strQuery = "select cardname, quantity, Format(CardPrice, 'C') As 'Price'  from TurullPsp212332.ProductInfo;";
                //establish command object
                _sqlInventoryCommand = new SqlCommand(strQuery, _cntDatabase);
                //establish data adapter
                _daInventory = new SqlDataAdapter();
                _daInventory.SelectCommand = _sqlInventoryCommand;
                //fill data table
                _dtInventoryTable = new DataTable();
                _daInventory.Fill(_dtInventoryTable);
                //bind controls to the textboxes
                dgvData.DataSource = _dtInventoryTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in establishing Inventory Table. Error 301.", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        //****************************REMOVE INVENTORY
        public static void DatabaseCommandRemoveInv(string strCardName)
        {//Remove Card from the database
            string strQuery = "declare @cardindex as int;";
            strQuery += $"\nset @cardindex = (select top 1 CardImageIndex from TurullPsp212332.ProductInfo where Cardname like '%{strCardName}%' order by CardName);";
            strQuery += $"\ndelete from TurullPsp212332.ProductInfo where cardname = '{strCardName}';";
            strQuery += "\ndelete from Turullpsp212232.ProductPictures where cardimageindex = @cardindex;";

            SqlCommand myCommand = new SqlCommand(strQuery, _cntDatabase);
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                MessageBox.Show("There has been an issue deleting the selected item from the product table", $"Error deleting item {strCardName}", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //********************************CHANGE INVENTORY NUMBERS
        public static void DatabaseCommandReduceORIncreaseInv(int intQuantity, string strCardname)
        {//increase the ammount of copies stored of the selected card

            string query = $"Update TurullPsp212332.ProductInfo set Quantity = {intQuantity} where cardname = '{strCardname}';";

            SqlCommand myCommand = new SqlCommand(query, _cntDatabase);

            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("There has been an issue altering the selected item from the product table", $"Error deleting item {strCardname}", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //********************************UPLOADS IMAGE
        public static void DatabaseCommandUploadCard(byte[] image)
        {
            try
            {
                string strUploadImage = $"Insert into Turullpsp212332.ProductPictures (CardImage) values(@ByteArray)";
                SqlCommand cmdUploadImage = new SqlCommand(strUploadImage, _cntDatabase);
                SqlParameter sqlParameter = cmdUploadImage.Parameters.AddWithValue("@ByteArray", image);
                sqlParameter.DbType = System.Data.DbType.Binary;

                cmdUploadImage.ExecuteNonQuery();

                MessageBox.Show("Image was successfully added to the database! Add the Card info to put it on our shelves!", "Upload Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Saving New Item", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //*********************INSERT NEW CARD INFORMATION
        public static void DatabaseCommandInsertCardInformation(string strCardName, string strCardCost, string strCardType, string strCardDesc, double dblPrice, string strQuantity)
        {
            try { 
            string InsertCard = "declare @cardindex as int;";
            InsertCard += $"\n set @cardindex = (select top 1 CardImageIndex from TurullPsp212332.ProductPictures order by CardImageIndex desc);";
            InsertCard += $"\n Insert into TurullPSP212332.ProductInfo(CardName, CardCost, CardType, CardEffect, Quantity, CardPrice, CardImageIndex) values ('{strCardName}', '{strCardCost}', '{strCardType}', '{strCardDesc}', {strQuantity}, {dblPrice}, @cardIndex)";
            SqlCommand cmdInsertCard = new SqlCommand(InsertCard, _cntDatabase);
            cmdInsertCard.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Inserting New Item", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        //***********************LOADS NEW IMAGE INTO INVENTORY PBX
        public static void LoadInventoryImage(byte[] image, PictureBox pbxImage)
        {
            using (MemoryStream ms = new MemoryStream(image))
            {
                Image loadImage = Image.FromStream(ms);
                pbxImage.Image = loadImage;
            }
        }

        //************************ADDS EMPLOYEE INFORMATION
        public static void DatabaseCommandCommitEmployee(string strName, string strUsername, string strPassword, string strQuestion, string strResponse, int intSecurityLevel, int intMonType,int intTuesType,int intWedType,int intThurType,int intFriType,int intSatType,int intSunType)
        {
            string query = $"insert into TurullPsp212332.Employees (SecurityLevel, Name, Username, Password, SecurityQuestion, SecurityResponse, ScheduleTypeMon, ScheduleTypeTues, ScheduleTypeWed, ScheduleTypeThur, ScheduleTypeFri, ScheduleTypeSat, ScheduleTypeSun) values ({intSecurityLevel}, '{strName}', '{strUsername}', '{strPassword}', '{strQuestion}', '{strResponse}', {intMonType}, {intTuesType}, {intWedType}, {intThurType}, {intFriType}, {intSatType}, {intSunType});";

            SqlCommand myCommand = new SqlCommand(query, _cntDatabase);

            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("There has been an issue adding the new employee to the Employee table", $"Error adding Employee {strName}", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //******************REMOVE EMPLOYEE INFORMATION
        public static void DatabaseCommandFireEmployee (string strName)
        {
            string strQuery = $"delete from TurullPsp212332.Employees where name like '{strName}';";

            SqlCommand myCommand = new SqlCommand(strQuery, _cntDatabase);

            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("There has been an issue deleting the selected employee from the Employee table", $"Error removing Employee {strName}", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //*********************LOAD EMPLOYEE INFORMATION
        public static void DatabaseCommandLoadEmployees(string strEmpID, TextBox tbxName, TextBox tbxUserName, TextBox tbxPosition, TextBox tbxPassword, TextBox tbxSecQuestion, TextBox tbxSecResponse,
           TextBox tbxSecLevel, TextBox tbxMonday, TextBox tbxTuesday, TextBox tbxWednesday, TextBox tbxThursday, TextBox tbxFriday, TextBox tbxSaturday, TextBox tbxSunday)
        {
            try
            {
                //string to build the query
                string query = $"SELECT Name, Username, Password, SecurityQuestion, SecurityResponse, Position, SecurityLevel, " +
                    $"ScheduleTypeMon, ScheduleTypeTues, ScheduleTypeWed, ScheduleTypeThur, ScheduleTypeFri, ScheduleTypeSat, " +
                    $"ScheduleTypeSun FROM TurullPsp212332.Employees where EmployeeID = {strEmpID};";

                //establish command object
                SqlCommand cmdFillEmployeeData = new SqlCommand(query, _cntDatabase);


                SqlDataReader sqlReader = cmdFillEmployeeData.ExecuteReader();


                if (sqlReader.Read())
                {
                    tbxName.Text = sqlReader["Name"].ToString();
                    tbxUserName.Text = sqlReader["Username"].ToString();
                    tbxPassword.Text = sqlReader["password"].ToString();
                    tbxPosition.Text = sqlReader["Position"].ToString();
                    tbxSecLevel.Text = sqlReader["SecurityLevel"].ToString();
                    tbxSecQuestion.Text = sqlReader["SecurityQuestion"].ToString();
                    tbxSecResponse.Text = sqlReader["SecurityResponse"].ToString();
                    tbxMonday.Text = sqlReader["ScheduleTypeMon"].ToString();
                    tbxTuesday.Text = sqlReader["ScheduleTypeTues"].ToString();
                    tbxWednesday.Text = sqlReader["ScheduleTypeWed"].ToString();
                    tbxThursday.Text = sqlReader["ScheduleTypeThur"].ToString();
                    tbxFriday.Text = sqlReader["ScheduleTypeFri"].ToString();
                    tbxSaturday.Text = sqlReader["ScheduleTypeSat"].ToString();
                    tbxSunday.Text = sqlReader["ScheduleTypeSun"].ToString();
                }
                sqlReader.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in establishing Employee Information. Error 301.", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }

        }
        
        //*****************************SAVE NEW INFORMATION
            public static void DatabaseCommandUpdateEmployees(string strEmpID, string strName, string strUserName, string strPosition, string strPassword, string strSecQuestion, string strSecResponse,
            string strSecLevel, string strMonday, string strTuesday, string strWednesday, string strThursday, string strFriday, string strSaturday, string strSunday)
        {
            try
            {
                string strQuery = $"Update TurullPsp212332.Employees set name = '{strName}', username = '{strUserName}', position = '{strPosition}' , SecurityQuestion = '{strSecQuestion}'," +
                    $" SecurityResponse = '{strSecResponse}', SecurityLevel = {strSecLevel}, ScheduleTypeMon = {strMonday}, ScheduleTypeTues = {strTuesday}, ScheduleTypeWed = {strWednesday}, ScheduleTypeThur = {strThursday}," +
                    $" ScheduleTypeFri = {strFriday}, ScheduleTypeSat = {strSaturday}, ScheduleTypeSun = {strSunday} where EmployeeID = {strEmpID}";

                SqlCommand command = new SqlCommand(strQuery, _cntDatabase);

                command.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Cannot complete update of employee information", "Error Saving Changes", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //*******************************DAILY ORDER REPORTS
        public static void DatabaseCommandLoadDailySales()
        {
            try
            {
                string strQuery;
                //string to build query 
                strQuery = $"declare @TotalSaleOfOrder money"
                +"\nset @TotalSaleOfOrder = (select top 1 sum(o.totalPrice) as 'Total Daily Sales' from TurullPsp212332.Orders o, TurullPsp212332.OrderDetails d where DATEPART(DAY, OrderDate) = DATEPART(DAY, GETDATE()) AND DATEPART(MONTH, OrderDate) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, OrderDate) = DATEPART(YEAR, GETDATE()) and o.OrderID = d.OrderID)"
                + "\nselect o.OrderID as 'Order ID', o.OrderDate as 'Order Date',o.CustomerUsername as 'Customer Username', d.CardName as 'Card Name', d.Quantity, format(o.TotalPrice, 'C') as 'Price of Order', format(@TotalSaleOfOrder, 'C') as 'Total Daily Sales' from TurullPsp212332.Orders o, TurullPsp212332.OrderDetails d where DATEPART(DAY, OrderDate) = DATEPART(DAY, GETDATE()) AND DATEPART(MONTH, OrderDate) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, OrderDate) = DATEPART(YEAR, GETDATE()) and o.OrderID = d.OrderID;";
                //establish cmb obj
                _sqlDailySales = new SqlCommand(strQuery, _cntDatabase);

                _daDailySales = new SqlDataAdapter();
                _daDailySales.SelectCommand = _sqlDailySales;
                //fill data table
                _dtDailySales = new DataTable();
                _daDailySales.Fill(_dtDailySales);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in establishing Daily Sales Table. Error 302.", MessageBoxButtons.OK,
                  MessageBoxIcon.Error);
            }
        }

        public static void DatabaseCommandLoadWeeklySales()
        {
            try
            {
                string strQuery;
                //string to build query 
                strQuery = $"declare @TotalSaleOfOrder money"
                + "\nset @TotalSaleOfOrder = (select top 1 sum(o.totalPrice) as 'Total Daily Sales' from TurullPsp212332.orders o, TurullPsp212332.OrderDetails d where DATEPART(week, OrderDate) = DATEPART(week, GETDATE()) and o.OrderID = d.OrderID)"
                + "\nselect o.OrderID as 'Order ID', o.OrderDate as 'Order Date',o.CustomerUsername as 'Customer Username', d.CardName as 'Card Name', d.Quantity, format(o.TotalPrice, 'C') as 'Price of Order', format(@TotalSaleOfOrder, 'C') as 'Total Weekly Sales' from TurullPsp212332.orders o, TurullPsp212332.OrderDetails d where DATEPART(week, OrderDate) = DATEPART(week, GETDATE()) and o.OrderID = d.OrderID;";
                //establish cmb obj
                _sqlWeeklySales = new SqlCommand(strQuery, _cntDatabase);

                _daWeeklySales = new SqlDataAdapter();
                _daWeeklySales.SelectCommand = _sqlWeeklySales;
                //fill data table
                _dtWeeklySales = new DataTable();
                _daWeeklySales.Fill(_dtWeeklySales);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in establishing Weekly Sales Table. Error 302.", MessageBoxButtons.OK,
                  MessageBoxIcon.Error);
            }
        }

        public static void DatabaseCommandLoadMonthlySales()
        {
            try
            {
                string strQuery;
                //string to build query 
                strQuery = $"declare @TotalSaleOfOrder money"
                + "\nset @TotalSaleOfOrder = (select top 1 sum(o.totalPrice) as 'Total Daily Sales' from TurullPsp212332.Orders o, TurullPsp212332.OrderDetails d where DATEPART(MONTH, OrderDate) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, OrderDate) = DATEPART(YEAR, GETDATE())and o.OrderID = d.OrderID)"
                + "\nselect o.OrderID as 'Order ID', o.OrderDate as 'Order Date',o.CustomerUsername as 'Customer Username', d.CardName as 'Card Name', d.Quantity, format(o.TotalPrice, 'C') as 'Price of Order', format(@TotalSaleOfOrder, 'C') as 'Total Monthly Sales' from TurullPsp212332.Orders o, TurullPsp212332.OrderDetails d where DATEPART(MONTH, OrderDate) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, OrderDate) = DATEPART(YEAR, GETDATE())and o.OrderID = d.OrderID;";
                //establish cmb obj
                _sqlMonthlySales = new SqlCommand(strQuery, _cntDatabase);

                _daMonthlySales = new SqlDataAdapter();
                _daMonthlySales.SelectCommand = _sqlMonthlySales;
                //fill data table
                _dtMonthlySales = new DataTable();
                _daMonthlySales.Fill(_dtMonthlySales);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in establishing Monthly Sales Table. Error 302.", MessageBoxButtons.OK,
                  MessageBoxIcon.Error);
            }
        }

    }
}
