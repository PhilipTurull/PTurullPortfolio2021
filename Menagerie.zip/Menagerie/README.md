Review site this before modifing you Readme.md file:

https://medium.com/swlh/how-to-make-the-perfect-readme-md-on-github-92ed5771c061


Your Project Logo/Icon: 

![alt text](https://github.com/JamesFlippin/Final-Project-21SP_StudentTemplate/blob/main/OctoCat_SM.png "My Logo")

## Jester's Menagerie
Card Repository and Tournament Planning

## Detailed Description

This program exists to allow card shops that primarily work with Magic The Gathering cards to generate and fascilitate sales while also acting as a scheduling system for tourneys. Another use for this program is to manage schedules of employees to ensure a smooth workday with easy to access and distibute information and merchandise.

### Project Introduction

- Catalogues cards and puts them up for purchase
- Gives managers and employees easy to acess (and in the managers case manipulate) schedules
- List its most useful/innovative/noteworthy features.
- This project is to help ease smaller companies that sell cards keep track of their stock and manage their wares efficiently
- Link to any supplementary blog posts or project main pages.
- Planning
- If possible, include screenshots and demo videos.

### Development Environment

Type | Description
-----|-------------
Language | C#
Development Environment | Visual Studio 2019 Community Edition
SQL Server Type | MS SQL 
Target Environment | Windows 10 Desktop
Target Audience | Whatever your target audience is
Help System | HTML Help
Report Methods | HTML Reports

### Core Technical Concepts/Inspiration

- I wanted to make a project that helps an industry I enjoy, as such this is the first idea that came to mind.
- Frame your project for the potential user. 
- Highlight the technical concepts that your project demonstrates or supports. Keep it very brief.

### Getting Started/Requirements/Prerequisites/Dependencies
Include any essential instructions for:
- Getting your program
- Installing your program
- Configuring your program
- Running your program

### More Specific Topics
- Versioning: Services, APIs, Systems
- Common Error Messages/related details
- Testing, validation, etc.

### Videos
- URL for your Video Resume
- https://drive.google.com/file/d/14NlqLWmWIu9Kgsnq7gOYVZYxvoG93kC6/view?usp=sharing
- URL for any other specific videos for this product

### Contributing
- Contributor Guidelines
- Code Requirements
- Format for commit messages
- Thank you (name contributors)

### TODO
- ERD
- UI Design
- Database population
- General programming and coding 
- Features planned
- Known bugs (shortlist)

### Contact

Contact | Information
--------|------
Name | Philip Turull
Email | philip.turull@gmail.com

### License
GNU General Public License v3.0

Permissions of this strong copyleft license are conditioned on making available complete source code of licensed works and modifications, which include larger works using a licensed work, under the same license. Copyright and license notices must be preserved. Contributors provide an express grant of patent rights.
