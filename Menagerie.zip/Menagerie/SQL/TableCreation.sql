--create items
--name
--cost
--color
--effect
--type
--quantity

--orders
--orderdate
--orderid

--orderdetails
--orderid
--cardname (using composite keys)

--tourneys
--name
--starttime
--endtime
--referee

--employees
--name
--username
--password
--loginquestion
--loginanswer
--securitylevel
--positionid
--scheduletype

--schedules
--starttime
--breakone
--lunch start
--lunchend
--breaktwo
--endtime

create table ProductInfo(
CardIndex int identity primary key,
Cardname varchar(40) not null,
CardCost varchar(10) not null,
CardColor varchar(25),
CardEffect varchar(max),
CardType varchar(40)not null,
Quantity int,
CardImage varBinary(max)
);

create table schedules(
ScheduleType int primary key,
ClockIn time,
BreakOne time,
LunchStart time,
LunchEnd time,
BreakTwo time,
ClockOut time
);

create table Employees(
EmployeeID int identity(600,9) primary key,
SecurityLevel int,
Name varchar(30),
ScheduleType int foreign key references Schedules, 
position varchar(20),
username varchar(30),
password varchar(40)
);

create table Customers(
CustomerID int identity(3000,3) primary key,
Name varchar(30),
SecurityLevel int,
username varchar(30),
password varchar(40)
);

create table TourneyInfo(
TournamentID int identity(50, 7) primary key,
TourneyName varchar(30),
Ruleset varchar(15),
RefereeID int foreign key references Employees,
Referee varchar(30)
);

create table Orders(
OrderID int identity(30, 4) primary key,
CustomerID int foreign key references Customers,
OrderDate date
);

create table OrderDetails(
OrderID int foreign key references Orders,
CardIndex int foreign key references ProductInfo,
Cardname varchar(40) not null,
CardCost varchar(10) not null,
CardColor varchar(25),
CardEffect varchar(max),
CardType varchar(40)not null,
Quantity int,
);
