﻿
namespace SP21_Final_Project
{
    partial class frmAskSwap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAsk = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.tbxReason = new System.Windows.Forms.TextBox();
            this.rbnMonday = new System.Windows.Forms.RadioButton();
            this.rbnTuesday = new System.Windows.Forms.RadioButton();
            this.rbnWednesday = new System.Windows.Forms.RadioButton();
            this.rbnThursday = new System.Windows.Forms.RadioButton();
            this.rbnFriday = new System.Windows.Forms.RadioButton();
            this.rbnSaturday = new System.Windows.Forms.RadioButton();
            this.rbnSunday = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbxNewType = new System.Windows.Forms.TextBox();
            this.tbxPreviousType = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAsk
            // 
            this.btnAsk.Location = new System.Drawing.Point(291, 191);
            this.btnAsk.Name = "btnAsk";
            this.btnAsk.Size = new System.Drawing.Size(106, 23);
            this.btnAsk.TabIndex = 0;
            this.btnAsk.Text = "&Ask for swap";
            this.btnAsk.UseVisualStyleBackColor = true;
            this.btnAsk.Click += new System.EventHandler(this.btnAsk_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(291, 220);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(106, 23);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // tbxReason
            // 
            this.tbxReason.Location = new System.Drawing.Point(12, 83);
            this.tbxReason.Multiline = true;
            this.tbxReason.Name = "tbxReason";
            this.tbxReason.Size = new System.Drawing.Size(254, 164);
            this.tbxReason.TabIndex = 2;
            // 
            // rbnMonday
            // 
            this.rbnMonday.AutoSize = true;
            this.rbnMonday.Location = new System.Drawing.Point(291, 34);
            this.rbnMonday.Name = "rbnMonday";
            this.rbnMonday.Size = new System.Drawing.Size(63, 17);
            this.rbnMonday.TabIndex = 3;
            this.rbnMonday.TabStop = true;
            this.rbnMonday.Text = "Monday";
            this.rbnMonday.UseVisualStyleBackColor = true;
            this.rbnMonday.CheckedChanged += new System.EventHandler(this.rbnMonday_CheckedChanged);
            // 
            // rbnTuesday
            // 
            this.rbnTuesday.AutoSize = true;
            this.rbnTuesday.Location = new System.Drawing.Point(291, 57);
            this.rbnTuesday.Name = "rbnTuesday";
            this.rbnTuesday.Size = new System.Drawing.Size(66, 17);
            this.rbnTuesday.TabIndex = 4;
            this.rbnTuesday.TabStop = true;
            this.rbnTuesday.Text = "Tuesday";
            this.rbnTuesday.UseVisualStyleBackColor = true;
            this.rbnTuesday.CheckedChanged += new System.EventHandler(this.rbnTuesday_CheckedChanged);
            // 
            // rbnWednesday
            // 
            this.rbnWednesday.AutoSize = true;
            this.rbnWednesday.Location = new System.Drawing.Point(291, 80);
            this.rbnWednesday.Name = "rbnWednesday";
            this.rbnWednesday.Size = new System.Drawing.Size(82, 17);
            this.rbnWednesday.TabIndex = 5;
            this.rbnWednesday.TabStop = true;
            this.rbnWednesday.Text = "Wednesday";
            this.rbnWednesday.UseVisualStyleBackColor = true;
            this.rbnWednesday.CheckedChanged += new System.EventHandler(this.rbnWednesday_CheckedChanged);
            // 
            // rbnThursday
            // 
            this.rbnThursday.AutoSize = true;
            this.rbnThursday.Location = new System.Drawing.Point(291, 103);
            this.rbnThursday.Name = "rbnThursday";
            this.rbnThursday.Size = new System.Drawing.Size(69, 17);
            this.rbnThursday.TabIndex = 6;
            this.rbnThursday.TabStop = true;
            this.rbnThursday.Text = "Thursday";
            this.rbnThursday.UseVisualStyleBackColor = true;
            this.rbnThursday.CheckedChanged += new System.EventHandler(this.rbnThursday_CheckedChanged);
            // 
            // rbnFriday
            // 
            this.rbnFriday.AutoSize = true;
            this.rbnFriday.Location = new System.Drawing.Point(291, 126);
            this.rbnFriday.Name = "rbnFriday";
            this.rbnFriday.Size = new System.Drawing.Size(53, 17);
            this.rbnFriday.TabIndex = 7;
            this.rbnFriday.TabStop = true;
            this.rbnFriday.Text = "Friday";
            this.rbnFriday.UseVisualStyleBackColor = true;
            this.rbnFriday.CheckedChanged += new System.EventHandler(this.rbnFriday_CheckedChanged);
            // 
            // rbnSaturday
            // 
            this.rbnSaturday.AutoSize = true;
            this.rbnSaturday.Location = new System.Drawing.Point(291, 149);
            this.rbnSaturday.Name = "rbnSaturday";
            this.rbnSaturday.Size = new System.Drawing.Size(67, 17);
            this.rbnSaturday.TabIndex = 8;
            this.rbnSaturday.TabStop = true;
            this.rbnSaturday.Text = "Saturday";
            this.rbnSaturday.UseVisualStyleBackColor = true;
            this.rbnSaturday.CheckedChanged += new System.EventHandler(this.rbnSaturday_CheckedChanged);
            // 
            // rbnSunday
            // 
            this.rbnSunday.AutoSize = true;
            this.rbnSunday.Location = new System.Drawing.Point(291, 168);
            this.rbnSunday.Name = "rbnSunday";
            this.rbnSunday.Size = new System.Drawing.Size(61, 17);
            this.rbnSunday.TabIndex = 9;
            this.rbnSunday.TabStop = true;
            this.rbnSunday.Text = "Sunday";
            this.rbnSunday.UseVisualStyleBackColor = true;
            this.rbnSunday.CheckedChanged += new System.EventHandler(this.rbnSunday_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(288, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Day of the week to swap";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Reason";
            // 
            // tbxNewType
            // 
            this.tbxNewType.Location = new System.Drawing.Point(220, 25);
            this.tbxNewType.Name = "tbxNewType";
            this.tbxNewType.Size = new System.Drawing.Size(36, 20);
            this.tbxNewType.TabIndex = 12;
            this.tbxNewType.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxNewType_KeyPress);
            // 
            // tbxPreviousType
            // 
            this.tbxPreviousType.Location = new System.Drawing.Point(12, 25);
            this.tbxPreviousType.Name = "tbxPreviousType";
            this.tbxPreviousType.ReadOnly = true;
            this.tbxPreviousType.Size = new System.Drawing.Size(36, 20);
            this.tbxPreviousType.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Previous schedule type";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(144, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Desired schedule type";
            // 
            // frmAskSwap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 259);
            this.ControlBox = false;
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbxPreviousType);
            this.Controls.Add(this.tbxNewType);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rbnSunday);
            this.Controls.Add(this.rbnSaturday);
            this.Controls.Add(this.rbnFriday);
            this.Controls.Add(this.rbnThursday);
            this.Controls.Add(this.rbnWednesday);
            this.Controls.Add(this.rbnTuesday);
            this.Controls.Add(this.rbnMonday);
            this.Controls.Add(this.tbxReason);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnAsk);
            this.Name = "frmAskSwap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jester\'s Menagerie-Swap Shifts";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAsk;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox tbxReason;
        private System.Windows.Forms.RadioButton rbnMonday;
        private System.Windows.Forms.RadioButton rbnTuesday;
        private System.Windows.Forms.RadioButton rbnWednesday;
        private System.Windows.Forms.RadioButton rbnThursday;
        private System.Windows.Forms.RadioButton rbnFriday;
        private System.Windows.Forms.RadioButton rbnSaturday;
        private System.Windows.Forms.RadioButton rbnSunday;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbxNewType;
        private System.Windows.Forms.TextBox tbxPreviousType;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}