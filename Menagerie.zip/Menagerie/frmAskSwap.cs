﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SP21_Final_Project
{
    public partial class frmAskSwap : Form
    {
        string strUserName;
        string strDaySelected;
        public frmAskSwap(string username)
        {
            //Initializes all necessary values
            InitializeComponent();

            rbnMonday.Checked = true;
            rbnTuesday.Checked = false;
            rbnWednesday.Checked = false;
            rbnThursday.Checked = false;
            rbnFriday.Checked = false;
            rbnSaturday.Checked = false;
            rbnSunday.Checked = false;

            strDaySelected = "Monday";

            strUserName = username;

            //read in info from db where username matches-start at monday
            CheckEachDay();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        //-----------------------------Checks the previous schedule type for each day
        //----------------------------STARTS AT MONDAY THROUGH TO SUNDAY
        private void rbnMonday_CheckedChanged(object sender, EventArgs e)
        {
            if(rbnMonday.Checked == true)
            {
                rbnMonday.Checked = true;
                rbnTuesday.Checked = false;
                rbnWednesday.Checked = false;
                rbnThursday.Checked = false;
                rbnFriday.Checked = false;
                rbnSaturday.Checked = false;
                rbnSunday.Checked = false;

               strDaySelected = "Monday";
            }
            CheckEachDay();
        }

        private void rbnTuesday_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnTuesday.Checked == true)
            {
                rbnMonday.Checked = false;
                rbnTuesday.Checked = true;
                rbnWednesday.Checked = false;
                rbnThursday.Checked = false;
                rbnFriday.Checked = false;
                rbnSaturday.Checked = false;
                rbnSunday.Checked = false;

                strDaySelected = "Tuesday";
            }
            CheckEachDay();
        }

        private void rbnWednesday_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnWednesday.Checked == true)
            {
                rbnMonday.Checked = false;
                rbnTuesday.Checked = false;
                rbnWednesday.Checked = true;
                rbnThursday.Checked = false;
                rbnFriday.Checked = false;
                rbnSaturday.Checked = false;
                rbnSunday.Checked = false;

                strDaySelected = "Wednesday";
            }
            CheckEachDay();
        }

        private void rbnThursday_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnThursday.Checked == true)
            {
                rbnMonday.Checked = false;
                rbnTuesday.Checked = false;
                rbnWednesday.Checked = false;
                rbnThursday.Checked = true;
                rbnFriday.Checked = false;
                rbnSaturday.Checked = false;
                rbnSunday.Checked = false;

                strDaySelected = "Thursday";
            }
            CheckEachDay();
        }

        private void rbnFriday_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnFriday.Checked == true)
            {
                rbnMonday.Checked = false;
                rbnTuesday.Checked = false;
                rbnWednesday.Checked = false;
                rbnThursday.Checked = false;
                rbnFriday.Checked = true;
                rbnSaturday.Checked = false;
                rbnSunday.Checked = false;

                strDaySelected = "Friday";
            }
            CheckEachDay();
        }

        private void rbnSaturday_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnSaturday.Checked == true)
            {
                rbnMonday.Checked = false;
                rbnTuesday.Checked = false;
                rbnWednesday.Checked = false;
                rbnThursday.Checked = false;
                rbnFriday.Checked = false;
                rbnSaturday.Checked = true;
                rbnSunday.Checked = false;

                strDaySelected = "Saturday";
            }
            CheckEachDay();
        }

        private void rbnSunday_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnSunday.Checked == true)
            {
                rbnMonday.Checked = false;
                rbnTuesday.Checked = false;
                rbnWednesday.Checked = false;
                rbnThursday.Checked = false;
                rbnFriday.Checked = false;
                rbnSaturday.Checked = false;
                rbnSunday.Checked = true;

                strDaySelected = "Sunday";
            }
            CheckEachDay();
        }

        void CheckEachDay()
        {
            //runs progops to check previous schedule types
            ProgOps.DatabaseCommandScheduleSwapPrev(strDaySelected, strUserName, tbxPreviousType);
        }

        private void btnAsk_Click(object sender, EventArgs e)
        {//Insert information into the database for reading by the manager

            var varHasNumber = new Regex(@"[0-3]+");
            var blnIsValidated = varHasNumber.IsMatch(tbxNewType.Text);

            //insert a swap date(day of the week) in order to change shift types
            if (tbxReason.Text != "" && blnIsValidated == true && tbxNewType.Text.Count() == 1)
            {
                try
                {
                    ProgOps.DatabaseCommandInsertShiftSwap(strUserName, tbxReason.Text.Replace("'", "''"), tbxPreviousType, tbxNewType, strDaySelected);

                    MessageBox.Show("Your shift request for " + strDaySelected + " has been processed!");
                    this.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "There has been an error processing your request", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Soorry it looks like there is an issue with your selected shift type! Please pick 1, 2 or 3 shift type!", "Error Placing Shift Request", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tbxNewType_KeyPress(object sender, KeyPressEventArgs e)
        {//ensures only numbers are placed in the new schedule type textbox

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
