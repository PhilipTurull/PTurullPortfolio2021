﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SP21_Final_Project
{
    public partial class frmCardView : Form
    {
        public string strTitle;
        frmMain mainScreen;
        public frmCardView(frmMain MainScreen)
        {
            InitializeComponent();
            mainScreen = MainScreen;
        }

        private void btnClose_Click(object sender, EventArgs e)
          {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {//Adds a copy of the item to the cart

            double dblCardPrice = 0;
            double dblPercentage = 0;
            int intMaximumPurchasable = 0;



            double.TryParse(lblCardPrice.Text, out dblCardPrice);
            int.TryParse(lblAmountInStock.Text, out intMaximumPurchasable);
            try
            {
            
                string strPercentage = lblPercentOff.Text.Remove(lblPercentOff.Text.IndexOf("%"), lblPercentOff.Text.Length - lblPercentOff.Text.IndexOf("%"));
                double.TryParse(strPercentage, out dblPercentage);

                if (lblOnSale.Text == "Yes")
                {
                    dblCardPrice -= dblCardPrice * (dblPercentage);
                }
            }catch(Exception)
            {
                MessageBox.Show("Error adding sale, please contact an employee", "Sales Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            mainScreen.AddToCart(lblCardName.Text, dblCardPrice, intMaximumPurchasable);
        }

        private void frmCardView_Shown(object sender, EventArgs e)
        {//sets the title of the form to the name of the card
            this.Text = lblCardName.Text;
            lblCardName.Visible = false;
        }

        private void lblDesc_Click(object sender, EventArgs e)
        {
            try { 
            HtmlReports.PrintShowDetailHelp(HtmlReports.ShowDetailHelp(lblDesc, lblType));
            }
            catch (Exception)
            {
                MessageBox.Show("Error adding sale, please contact an employee", "Sales Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
