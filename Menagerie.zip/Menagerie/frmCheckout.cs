﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SP21_Final_Project
{
    public partial class frmCheckout : Form
    {
        frmMain MainScreen;
        List<string> strCardContents = new List<string>();
        public frmCheckout(frmMain mainScreen)
        {
            InitializeComponent();

            MainScreen = mainScreen;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            MainScreen.strDupe.Clear();
            MainScreen.intCardCount.Clear();
            MainScreen.dblCardPrices.Clear();
            this.Close();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {//Removes items from the listbox and then the strCart in frmMain
            if (lbxCart.SelectedIndex == -1)
                MessageBox.Show("Please select an Item first!", "Erroor Deleting Item", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else 
            {

                if (lbxCart.Items.Count == 0)
                {
                    MessageBox.Show("Sorry, it looks like you don't have any items in your cart! Add some goodies and feel free to come check out here!", "No More Items!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                try
                {
                    if (lbxCart.Items.Count > 0)
                    {
                        string strCardName = lbxCart.SelectedItem.ToString().Substring(lbxCart.SelectedItem.ToString().IndexOf(" ") + 1, lbxCart.SelectedItem.ToString().Length - (lbxCart.SelectedItem.ToString().Length - lbxCart.SelectedItem.ToString().LastIndexOf("$") + 3));

                        MainScreen.dblCardPrices.Clear();

                        MainScreen.strDupe.Clear();

                        MainScreen.intCardCount.Clear();
                        while (MainScreen.strCart.Contains(strCardName))
                        {
                            for (int i = 0; i < MainScreen.strCart.Count; i++)
                            {
                                MainScreen.dblPrice.RemoveAt(MainScreen.strCart.IndexOf(strCardName));
                                MainScreen.intCardCount.RemoveAt(MainScreen.strCart.IndexOf(strCardName));
                                MainScreen.strCart.Remove(strCardName);
                            }
                        }

                        lbxCart.Items.RemoveAt(lbxCart.SelectedIndex);
                    }
                }catch(Exception)
                {
                    MessageBox.Show("There has been an error removing the item in question-We have had to reset your cart", "Sorry for the Inconveinence", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    MainScreen.strCart.Clear();
                    MainScreen.dblPrice.Clear();
                    MainScreen.strDupe.Clear();
                    MainScreen.dblCardPrices.Clear();
                    MainScreen.intCardCount.Clear();
                }
                
            }
        }
        

        private void btnCheckout_Click(object sender, EventArgs e)
        {//Seperates the string in the listbox and sends it to the databse to be ordered

            if (lbxCart.Items.Count == 0)
            {
                MessageBox.Show("Sorry, it looks like you don't have any items in your cart! Add some goodies and feel free to come check out here!");
                return;
            }

            List<string> Cardname = new List<string>();
            List<int> Quantities = new List<int>();
            List<double> CardPrice = new List<double>();
            int intQuantity = 0;
            double dblPrice = 0;
            double dblTotalPrice = 0;
            double dblTotalPriceAfterTax = 0;


            try
            {
                for (int i = 0; i < lbxCart.Items.Count; i++)
                {
                    string placeholder = lbxCart.Items[i].ToString();

                    string cardName = placeholder.Substring(placeholder.IndexOf(" ") + 1, placeholder.Length - ((placeholder.Length - placeholder.LastIndexOf("$")) + 3));

                    string cardQuantity = placeholder.Substring(0, placeholder.IndexOf(" "));

                    string strCardPrice = placeholder.Substring(placeholder.LastIndexOf("$") + 1, placeholder.Length - (placeholder.LastIndexOf("$") + 1));

                    Cardname.Add(cardName);
                    int.TryParse(cardQuantity, out intQuantity);
                    Quantities.Add(intQuantity);
                    double.TryParse(strCardPrice, out dblPrice);
                    CardPrice.Add(dblPrice);
                }

                for (int i = 0; i < CardPrice.Count; i++)
                {
                    dblTotalPrice += CardPrice[i];
                }

                for (int i = 0; i < Cardname.Count; i++)
                {
                    Cardname[i].Replace("'", "''");
                }

                for (int i = 0; i < Cardname.Count; i++)
                {
                    strCardContents.Add(Cardname[i]);
                }
                bool blnWorked = false;

                dblTotalPriceAfterTax = dblTotalPrice + (dblTotalPrice * 0.0825);


                if (MessageBox.Show($"Your total comes to {dblTotalPriceAfterTax.ToString("C2")} is this okay?", "Total Price of Order", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == System.Windows.Forms.DialogResult.Yes)
                {
                    blnWorked = ProgOps.DatabaseCommandMakeOrder(Cardname, Quantities, dblTotalPriceAfterTax, MainScreen.strUsername);

                    if (blnWorked)
                    {
                        MessageBox.Show("Thank you for your patronage " + MainScreen.strUsername + "! \nPlease come again soon!");
                        try { 
                        HtmlReports.PrintReceiept(HtmlReports.GenerateReceipt(Cardname, Quantities, CardPrice, dblTotalPrice, dblTotalPriceAfterTax));
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                        ProgOps.DatabaseCommandProd(MainScreen.dgvCards, MainScreen.strDefaultQuery);
                        MainScreen.blnLoggedin = false;
                        MainScreen.intSecurityLevel = 0;
                        MainScreen.strUsername = "";
                        MainScreen.strPassword = "";
                        MainScreen.grantRemoveAccess();

                        if (MainScreen.strCart.Count() > 0)
                        {
                            MainScreen.strCart.Clear();
                            MainScreen.dblPrice.Clear();
                            MainScreen.strDupe.Clear();
                            MainScreen.dblCardPrices.Clear();
                            MainScreen.intCardCount.Clear();
                        }
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Okay! Remove whatever items from your cart and come on back to complete your order!", "Transaction suspended", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }catch(Exception)
            {
                MessageBox.Show("There has been an error completing your order-We have had to reset your cart", "Sorry for the Inconveinence", MessageBoxButtons.OK, MessageBoxIcon.Error);

                MainScreen.strCart.Clear();
                MainScreen.dblPrice.Clear();
                MainScreen.strDupe.Clear();
                MainScreen.dblCardPrices.Clear();
            }
        }

    }
}
