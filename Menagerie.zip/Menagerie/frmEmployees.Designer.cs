﻿
namespace SP21_Final_Project
{
    partial class frmEmployees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.tbxName = new System.Windows.Forms.TextBox();
            this.tbxUsername = new System.Windows.Forms.TextBox();
            this.tbxPassword = new System.Windows.Forms.TextBox();
            this.tbxReenter = new System.Windows.Forms.TextBox();
            this.tbxQuestion = new System.Windows.Forms.TextBox();
            this.tbxResponse = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dgvEmployees = new System.Windows.Forms.DataGridView();
            this.btnHire = new System.Windows.Forms.Button();
            this.btnFire = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.tbxSecLevel = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuHireEmployeeHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFireEmployeeHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.whatAreScheduleTAgainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbxMon = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbxTues = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbxWed = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbxThur = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tbxFri = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbxSat = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tbxSun = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tbxPosition = new System.Windows.Forms.TextBox();
            this.btnAlterEmployee = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployees)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(851, 314);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // tbxName
            // 
            this.tbxName.Location = new System.Drawing.Point(131, 64);
            this.tbxName.Name = "tbxName";
            this.tbxName.Size = new System.Drawing.Size(185, 20);
            this.tbxName.TabIndex = 1;
            // 
            // tbxUsername
            // 
            this.tbxUsername.Location = new System.Drawing.Point(322, 64);
            this.tbxUsername.Name = "tbxUsername";
            this.tbxUsername.Size = new System.Drawing.Size(185, 20);
            this.tbxUsername.TabIndex = 2;
            // 
            // tbxPassword
            // 
            this.tbxPassword.Location = new System.Drawing.Point(131, 127);
            this.tbxPassword.Name = "tbxPassword";
            this.tbxPassword.Size = new System.Drawing.Size(185, 20);
            this.tbxPassword.TabIndex = 3;
            // 
            // tbxReenter
            // 
            this.tbxReenter.Location = new System.Drawing.Point(322, 127);
            this.tbxReenter.Name = "tbxReenter";
            this.tbxReenter.Size = new System.Drawing.Size(185, 20);
            this.tbxReenter.TabIndex = 4;
            // 
            // tbxQuestion
            // 
            this.tbxQuestion.Location = new System.Drawing.Point(131, 213);
            this.tbxQuestion.Name = "tbxQuestion";
            this.tbxQuestion.Size = new System.Drawing.Size(377, 20);
            this.tbxQuestion.TabIndex = 5;
            // 
            // tbxResponse
            // 
            this.tbxResponse.Location = new System.Drawing.Point(131, 274);
            this.tbxResponse.Name = "tbxResponse";
            this.tbxResponse.Size = new System.Drawing.Size(185, 20);
            this.tbxResponse.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(126, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(319, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Username";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(127, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(319, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Re-Enter Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(126, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Security Question";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(120, 258);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Security Response";
            // 
            // dgvEmployees
            // 
            this.dgvEmployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmployees.Location = new System.Drawing.Point(516, 44);
            this.dgvEmployees.Name = "dgvEmployees";
            this.dgvEmployees.Size = new System.Drawing.Size(329, 284);
            this.dgvEmployees.TabIndex = 15;
            this.dgvEmployees.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEmployees_CellClick);
            // 
            // btnHire
            // 
            this.btnHire.Location = new System.Drawing.Point(364, 239);
            this.btnHire.Name = "btnHire";
            this.btnHire.Size = new System.Drawing.Size(126, 23);
            this.btnHire.TabIndex = 16;
            this.btnHire.Text = "&Hire New Employee";
            this.btnHire.UseVisualStyleBackColor = true;
            this.btnHire.Click += new System.EventHandler(this.btnHire_Click);
            // 
            // btnFire
            // 
            this.btnFire.Location = new System.Drawing.Point(364, 311);
            this.btnFire.Name = "btnFire";
            this.btnFire.Size = new System.Drawing.Size(126, 23);
            this.btnFire.TabIndex = 17;
            this.btnFire.Text = "&Fire Selected Employee";
            this.btnFire.UseVisualStyleBackColor = true;
            this.btnFire.Click += new System.EventHandler(this.btnFire_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(128, 156);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "Security Level";
            // 
            // tbxSecLevel
            // 
            this.tbxSecLevel.Location = new System.Drawing.Point(131, 172);
            this.tbxSecLevel.Name = "tbxSecLevel";
            this.tbxSecLevel.Size = new System.Drawing.Size(71, 20);
            this.tbxSecLevel.TabIndex = 19;
            this.tbxSecLevel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxSecLevel_KeyPress);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuHireEmployeeHelp,
            this.mnuFireEmployeeHelp,
            this.whatAreScheduleTAgainToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(959, 24);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnuHireEmployeeHelp
            // 
            this.mnuHireEmployeeHelp.Name = "mnuHireEmployeeHelp";
            this.mnuHireEmployeeHelp.Size = new System.Drawing.Size(164, 20);
            this.mnuHireEmployeeHelp.Text = "How Do I &Hire an Employee";
            this.mnuHireEmployeeHelp.Click += new System.EventHandler(this.mnuHireEmployeeHelp_Click);
            // 
            // mnuFireEmployeeHelp
            // 
            this.mnuFireEmployeeHelp.Name = "mnuFireEmployeeHelp";
            this.mnuFireEmployeeHelp.Size = new System.Drawing.Size(157, 20);
            this.mnuFireEmployeeHelp.Text = "How to I &Fire an Employee";
            this.mnuFireEmployeeHelp.Click += new System.EventHandler(this.mnuFireEmployeeHelp_Click);
            // 
            // whatAreScheduleTAgainToolStripMenuItem
            // 
            this.whatAreScheduleTAgainToolStripMenuItem.Name = "whatAreScheduleTAgainToolStripMenuItem";
            this.whatAreScheduleTAgainToolStripMenuItem.Size = new System.Drawing.Size(186, 20);
            this.whatAreScheduleTAgainToolStripMenuItem.Text = "What are Schedule &Types again?";
            this.whatAreScheduleTAgainToolStripMenuItem.Click += new System.EventHandler(this.whatAreScheduleTAgainToolStripMenuItem_Click);
            // 
            // tbxMon
            // 
            this.tbxMon.Location = new System.Drawing.Point(26, 64);
            this.tbxMon.Name = "tbxMon";
            this.tbxMon.Size = new System.Drawing.Size(71, 20);
            this.tbxMon.TabIndex = 22;
            this.tbxMon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxMon_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 44);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "Monday Shift Type";
            // 
            // tbxTues
            // 
            this.tbxTues.Location = new System.Drawing.Point(26, 105);
            this.tbxTues.Name = "tbxTues";
            this.tbxTues.Size = new System.Drawing.Size(71, 20);
            this.tbxTues.TabIndex = 24;
            this.tbxTues.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxMon_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 89);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Tuesday Shift Type";
            // 
            // tbxWed
            // 
            this.tbxWed.Location = new System.Drawing.Point(26, 154);
            this.tbxWed.Name = "tbxWed";
            this.tbxWed.Size = new System.Drawing.Size(71, 20);
            this.tbxWed.TabIndex = 26;
            this.tbxWed.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxMon_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 140);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(115, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "Wednesday Shift Type";
            // 
            // tbxThur
            // 
            this.tbxThur.Location = new System.Drawing.Point(26, 193);
            this.tbxThur.Name = "tbxThur";
            this.tbxThur.Size = new System.Drawing.Size(71, 20);
            this.tbxThur.TabIndex = 28;
            this.tbxThur.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxMon_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 179);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 13);
            this.label11.TabIndex = 27;
            this.label11.Text = "Thursday Shift Type";
            // 
            // tbxFri
            // 
            this.tbxFri.Location = new System.Drawing.Point(26, 232);
            this.tbxFri.Name = "tbxFri";
            this.tbxFri.Size = new System.Drawing.Size(71, 20);
            this.tbxFri.TabIndex = 30;
            this.tbxFri.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxMon_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(18, 218);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 13);
            this.label12.TabIndex = 29;
            this.label12.Text = "Friday Shift Type";
            // 
            // tbxSat
            // 
            this.tbxSat.Location = new System.Drawing.Point(26, 272);
            this.tbxSat.Name = "tbxSat";
            this.tbxSat.Size = new System.Drawing.Size(71, 20);
            this.tbxSat.TabIndex = 32;
            this.tbxSat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxMon_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 258);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 13);
            this.label13.TabIndex = 31;
            this.label13.Text = "Saturday Shift Type";
            // 
            // tbxSun
            // 
            this.tbxSun.Location = new System.Drawing.Point(26, 313);
            this.tbxSun.Name = "tbxSun";
            this.tbxSun.Size = new System.Drawing.Size(71, 20);
            this.tbxSun.TabIndex = 34;
            this.tbxSun.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxMon_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 299);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(94, 13);
            this.label14.TabIndex = 33;
            this.label14.Text = "Sunday Shift Type";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(319, 156);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 13);
            this.label15.TabIndex = 36;
            this.label15.Text = "Position";
            // 
            // tbxPosition
            // 
            this.tbxPosition.Location = new System.Drawing.Point(322, 172);
            this.tbxPosition.Name = "tbxPosition";
            this.tbxPosition.Size = new System.Drawing.Size(126, 20);
            this.tbxPosition.TabIndex = 35;
            // 
            // btnAlterEmployee
            // 
            this.btnAlterEmployee.Location = new System.Drawing.Point(364, 274);
            this.btnAlterEmployee.Name = "btnAlterEmployee";
            this.btnAlterEmployee.Size = new System.Drawing.Size(126, 23);
            this.btnAlterEmployee.TabIndex = 37;
            this.btnAlterEmployee.Text = "&Alter Employee";
            this.btnAlterEmployee.UseVisualStyleBackColor = true;
            this.btnAlterEmployee.Click += new System.EventHandler(this.btnAlterEmployee_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(131, 313);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 38;
            this.btnClear.Text = "C&lear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frmEmployees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 349);
            this.ControlBox = false;
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnAlterEmployee);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.tbxPosition);
            this.Controls.Add(this.tbxSun);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.tbxSat);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.tbxFri);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.tbxThur);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.tbxWed);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.tbxTues);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tbxMon);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tbxSecLevel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnFire);
            this.Controls.Add(this.btnHire);
            this.Controls.Add(this.dgvEmployees);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbxResponse);
            this.Controls.Add(this.tbxQuestion);
            this.Controls.Add(this.tbxReenter);
            this.Controls.Add(this.tbxPassword);
            this.Controls.Add(this.tbxUsername);
            this.Controls.Add(this.tbxName);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmEmployees";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jester\'s Menagerie-Manage Hires";
            this.Load += new System.EventHandler(this.frmEmployees_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployees)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox tbxName;
        private System.Windows.Forms.TextBox tbxUsername;
        private System.Windows.Forms.TextBox tbxPassword;
        private System.Windows.Forms.TextBox tbxReenter;
        private System.Windows.Forms.TextBox tbxQuestion;
        private System.Windows.Forms.TextBox tbxResponse;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgvEmployees;
        private System.Windows.Forms.Button btnHire;
        private System.Windows.Forms.Button btnFire;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbxSecLevel;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuHireEmployeeHelp;
        private System.Windows.Forms.ToolStripMenuItem mnuFireEmployeeHelp;
        private System.Windows.Forms.TextBox tbxMon;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbxTues;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbxWed;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbxThur;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbxFri;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbxSat;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbxSun;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbxPosition;
        private System.Windows.Forms.Button btnAlterEmployee;
        private System.Windows.Forms.ToolStripMenuItem whatAreScheduleTAgainToolStripMenuItem;
        private System.Windows.Forms.Button btnClear;
    }
}