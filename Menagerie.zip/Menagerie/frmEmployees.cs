﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SP21_Final_Project
{
    public partial class frmEmployees : Form
    {
        public frmEmployees()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnHire_Click(object sender, EventArgs e)
        {//Adds a new employee to the database

            var varHasNumber = new Regex(@"[0-9]+");
            var varHasUpperChar = new Regex(@"[A-Z]+");
            var varHasMinimum8Chars = new Regex(@".{8,}");

            var blnIsValidated = varHasNumber.IsMatch(tbxPassword.Text) && varHasUpperChar.IsMatch(tbxPassword.Text) && varHasMinimum8Chars.IsMatch(tbxPassword.Text);

            int intSecLevel = 2;
            int intMonType, intTuesType, intWedType, intThurType, intFriType, intSatType, intSunType;

            int.TryParse(tbxSecLevel.Text, out intSecLevel);
            int.TryParse(tbxMon.Text, out intMonType);
            int.TryParse(tbxTues.Text, out intTuesType);
            int.TryParse(tbxWed.Text, out intWedType);
            int.TryParse(tbxThur.Text, out intThurType);
            int.TryParse(tbxFri.Text, out intFriType);
            int.TryParse(tbxSat.Text, out intSatType);
            int.TryParse(tbxSun.Text, out intSunType);

            if (tbxPassword.Text != "" && tbxPassword.Text == tbxReenter.Text && blnIsValidated == true && (intSecLevel == 2 || intSecLevel == 3) && 
                (intMonType == 0 || intMonType == 1|| intMonType == 2 || intMonType == 3) 
                && (intTuesType == 0 || intTuesType == 1 || intTuesType == 2 || intTuesType == 3)
                && (intWedType == 0 || intWedType == 1 || intWedType == 2 || intWedType == 3) 
                && (intThurType == 0 || intThurType == 1 || intThurType == 2 || intThurType == 3)
                &&(intFriType == 0 || intFriType == 1 || intFriType == 2 || intFriType == 3) 
                && (intSatType == 0 || intSatType == 1 || intSatType == 2 || intSatType == 3)
                && (intSunType == 0 || intSunType == 1 || intSunType == 2 || intSunType == 3))
            {
                ProgOps.DatabaseCommandCommitEmployee(tbxName.Text.Replace("'", "''"), tbxUsername.Text.Replace("'", "''"), tbxPassword.Text.Replace("'", "''"), tbxQuestion.Text.Replace("'", "''"), tbxResponse.Text.Replace("'", "''"), intSecLevel, intMonType, intTuesType, intWedType, intThurType, intFriType, intSatType, intSunType);
                MessageBox.Show("They are now in our system! Hope they're as excited as we are!!", "New Hire", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ProgOps.DatabaseCommandEmp(dgvEmployees);
            }
            else
            {
                MessageBox.Show("Double check their information! Their password must be 8 characters or longer, and must contain an upper and lower case character!(as well as a number!)\nOnly the values 0-3 are allowed as Schedule Types!", "Whoops", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnFire_Click(object sender, EventArgs e)
        {//Removes employee from the database
            
            ProgOps.DatabaseCommandFireEmployee(dgvEmployees.CurrentRow.Cells[1].Value.ToString());
            MessageBox.Show("This employee has been removed from the database, hopefully they find new and beteter things!", "Employee Removed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            ProgOps.DatabaseCommandEmp(dgvEmployees);
            
        }

        private void frmEmployees_Load(object sender, EventArgs e)
        {
            ProgOps.DatabaseCommandEmp(dgvEmployees);
        }

        private void tbxSecLevel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar == '2' || e.KeyChar == '3'))
            {
                e.Handled = true;
            }
        }

        //This affects all keypress events for the schedule type boxes
        private void tbxMon_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar == '0' || e.KeyChar == '1' || e.KeyChar == '2' || e.KeyChar == '3'))
            {
                e.Handled = true;
            }
        }

        private void dgvEmployees_CellClick(object sender, DataGridViewCellEventArgs e)
        {
                ProgOps.DatabaseCommandLoadEmployees(dgvEmployees.CurrentRow.Cells[0].Value.ToString(), tbxName, tbxUsername, tbxPosition, tbxPassword,
                tbxQuestion, tbxResponse, tbxSecLevel, tbxMon, tbxTues, tbxWed, tbxThur, tbxFri, tbxSat, tbxSun);

            tbxReenter.Clear();
            
        }

        private void btnAlterEmployee_Click(object sender, EventArgs e)
        {
            try
            {
                var varHasNumber = new Regex(@"[0-9]+");
                var varHasUpperChar = new Regex(@"[A-Z]+");
                var varHasMinimum8Chars = new Regex(@".{8,}");

                var blnIsValidated = varHasNumber.IsMatch(tbxPassword.Text) && varHasUpperChar.IsMatch(tbxPassword.Text) && varHasMinimum8Chars.IsMatch(tbxPassword.Text);

                int intSecLevel = 2;
                int intMonType, intTuesType, intWedType, intThurType, intFriType, intSatType, intSunType;

                int.TryParse(tbxSecLevel.Text, out intSecLevel);
                int.TryParse(tbxMon.Text, out intMonType);
                int.TryParse(tbxTues.Text, out intTuesType);
                int.TryParse(tbxWed.Text, out intWedType);
                int.TryParse(tbxThur.Text, out intThurType);
                int.TryParse(tbxFri.Text, out intFriType);
                int.TryParse(tbxSat.Text, out intSatType);
                int.TryParse(tbxSun.Text, out intSunType);

                if (tbxPassword.Text != "" && tbxPassword.Text == tbxReenter.Text && blnIsValidated == true && (intSecLevel == 2 || intSecLevel == 3) &&
                (intMonType == 0 || intMonType == 1 || intMonType == 2 || intMonType == 3)
                && (intTuesType == 0 || intTuesType == 1 || intTuesType == 2 || intTuesType == 3)
                && (intWedType == 0 || intWedType == 1 || intWedType == 2 || intWedType == 3)
                && (intThurType == 0 || intThurType == 1 || intThurType == 2 || intThurType == 3)
                && (intFriType == 0 || intFriType == 1 || intFriType == 2 || intFriType == 3)
                && (intSatType == 0 || intSatType == 1 || intSatType == 2 || intSatType == 3)
                && (intSunType == 0 || intSunType == 1 || intSunType == 2 || intSunType == 3))
                {
                    ProgOps.DatabaseCommandUpdateEmployees(dgvEmployees.CurrentRow.Cells[0].Value.ToString(), tbxName.Text.Replace("'", "''"), tbxUsername.Text.Replace("'", "''"), tbxPosition.Text, tbxPassword.Text.Replace("'", "''"),
                tbxQuestion.Text.Replace("'", "''"), tbxResponse.Text.Replace("'", "''"), tbxSecLevel.Text, tbxMon.Text, tbxTues.Text, tbxWed.Text, tbxThur.Text, tbxFri.Text, tbxSat.Text, tbxSun.Text);

                }
                else
                {
                    MessageBox.Show("Double check their information! Their password must be 8 characters or longer, and must contain an upper and lower case character!(as well as a number!)\nSchedule type values must also be within a range of 0-3", "Whoops", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }catch(Exception)
            {
                MessageBox.Show("There has been an error changing the Employee's information, please double check your values.", "Error saving changes", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
         }

        private void whatAreScheduleTAgainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try { 
            HtmlReports.PrintScheduleTypeHelp(HtmlReports.ScheduleTypeHelp());
            }
            catch (Exception)
            {
                MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {

            tbxName.Clear();
            tbxUsername.Clear();
            tbxPassword.Clear();
            tbxPosition.Clear();
            tbxReenter.Clear();
            tbxQuestion.Clear();
            tbxResponse.Clear();
            tbxSecLevel.Clear();

            tbxMon.Clear();
            tbxTues.Clear();
            tbxWed.Clear();
            tbxThur.Clear();
            tbxFri.Clear();
            tbxSat.Clear();
            tbxSun.Clear();
        }

        private void mnuFireEmployeeHelp_Click(object sender, EventArgs e)
        {
            try { 
            HtmlReports.PrintFireEmployeeHelp(HtmlReports.FireEmployeeHelp());
            }
            catch (Exception)
            {
                MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void mnuHireEmployeeHelp_Click(object sender, EventArgs e)
        {
            try { 
            HtmlReports.PrintHireEmployeeHelp(HtmlReports.HireEmployeeHelp());
            }
            catch (Exception)
            {
                MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
