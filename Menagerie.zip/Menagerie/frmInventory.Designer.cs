﻿
namespace SP21_Final_Project
{
    partial class frmInventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInventory));
            this.tbxQuantity = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnOrderQuantity = new System.Windows.Forms.Button();
            this.dgvInventory = new System.Windows.Forms.DataGridView();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.tbcAlter = new System.Windows.Forms.TabControl();
            this.tabAlterRemove = new System.Windows.Forms.TabPage();
            this.tbxSale = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnSale = new System.Windows.Forms.Button();
            this.tbxDevotion = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.tabCreate = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.tbxInsertQuantity = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbxDesc = new System.Windows.Forms.TextBox();
            this.tbxType = new System.Windows.Forms.TextBox();
            this.tbxPrice = new System.Windows.Forms.TextBox();
            this.tbxCost = new System.Windows.Forms.TextBox();
            this.pbxInsertedImage = new System.Windows.Forms.PictureBox();
            this.tbxName = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.devotionOnSaleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.howDoIAddNewItemsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).BeginInit();
            this.tbcAlter.SuspendLayout();
            this.tabAlterRemove.SuspendLayout();
            this.tabCreate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxInsertedImage)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbxQuantity
            // 
            this.tbxQuantity.Location = new System.Drawing.Point(378, 34);
            this.tbxQuantity.Name = "tbxQuantity";
            this.tbxQuantity.Size = new System.Drawing.Size(100, 20);
            this.tbxQuantity.TabIndex = 0;
            this.tbxQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxQuantity_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(385, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Amount to Order:";
            // 
            // btnOrderQuantity
            // 
            this.btnOrderQuantity.Location = new System.Drawing.Point(356, 60);
            this.btnOrderQuantity.Name = "btnOrderQuantity";
            this.btnOrderQuantity.Size = new System.Drawing.Size(144, 23);
            this.btnOrderQuantity.TabIndex = 2;
            this.btnOrderQuantity.Text = "Order &More";
            this.btnOrderQuantity.UseVisualStyleBackColor = true;
            this.btnOrderQuantity.Click += new System.EventHandler(this.btnQuantity_Click);
            // 
            // dgvInventory
            // 
            this.dgvInventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInventory.Location = new System.Drawing.Point(6, 18);
            this.dgvInventory.Name = "dgvInventory";
            this.dgvInventory.Size = new System.Drawing.Size(344, 327);
            this.dgvInventory.TabIndex = 3;
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(356, 107);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(144, 23);
            this.btnRemove.TabIndex = 4;
            this.btnRemove.Text = "&Remove Item";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(356, 304);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(144, 23);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "C&lose";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // tbcAlter
            // 
            this.tbcAlter.Controls.Add(this.tabAlterRemove);
            this.tbcAlter.Controls.Add(this.tabCreate);
            this.tbcAlter.Location = new System.Drawing.Point(12, 47);
            this.tbcAlter.Name = "tbcAlter";
            this.tbcAlter.SelectedIndex = 0;
            this.tbcAlter.Size = new System.Drawing.Size(518, 389);
            this.tbcAlter.TabIndex = 6;
            // 
            // tabAlterRemove
            // 
            this.tabAlterRemove.Controls.Add(this.tbxSale);
            this.tabAlterRemove.Controls.Add(this.label10);
            this.tabAlterRemove.Controls.Add(this.btnSale);
            this.tabAlterRemove.Controls.Add(this.tbxDevotion);
            this.tabAlterRemove.Controls.Add(this.label9);
            this.tabAlterRemove.Controls.Add(this.btnPrint);
            this.tabAlterRemove.Controls.Add(this.dgvInventory);
            this.tabAlterRemove.Controls.Add(this.btnClose);
            this.tabAlterRemove.Controls.Add(this.tbxQuantity);
            this.tabAlterRemove.Controls.Add(this.btnRemove);
            this.tabAlterRemove.Controls.Add(this.label1);
            this.tabAlterRemove.Controls.Add(this.btnOrderQuantity);
            this.tabAlterRemove.Location = new System.Drawing.Point(4, 22);
            this.tabAlterRemove.Name = "tabAlterRemove";
            this.tabAlterRemove.Padding = new System.Windows.Forms.Padding(3);
            this.tabAlterRemove.Size = new System.Drawing.Size(510, 363);
            this.tabAlterRemove.TabIndex = 0;
            this.tabAlterRemove.Text = "Alter or Remove Merchandise";
            this.tabAlterRemove.UseVisualStyleBackColor = true;
            // 
            // tbxSale
            // 
            this.tbxSale.Location = new System.Drawing.Point(463, 190);
            this.tbxSale.Name = "tbxSale";
            this.tbxSale.Size = new System.Drawing.Size(23, 20);
            this.tbxSale.TabIndex = 11;
            this.tbxSale.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxSale_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(356, 193);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Percentage of Sale:";
            // 
            // btnSale
            // 
            this.btnSale.Location = new System.Drawing.Point(378, 226);
            this.btnSale.Name = "btnSale";
            this.btnSale.Size = new System.Drawing.Size(100, 23);
            this.btnSale.TabIndex = 9;
            this.btnSale.Text = "Save &Sale";
            this.btnSale.UseVisualStyleBackColor = true;
            this.btnSale.Click += new System.EventHandler(this.btnSale_Click);
            // 
            // tbxDevotion
            // 
            this.tbxDevotion.Location = new System.Drawing.Point(455, 160);
            this.tbxDevotion.Name = "tbxDevotion";
            this.tbxDevotion.Size = new System.Drawing.Size(23, 20);
            this.tbxDevotion.TabIndex = 8;
            this.tbxDevotion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxDevotion_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(356, 167);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Devotion on Sale:";
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(356, 275);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(144, 23);
            this.btnPrint.TabIndex = 6;
            this.btnPrint.Text = "&Print Inventory";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // tabCreate
            // 
            this.tabCreate.Controls.Add(this.label8);
            this.tabCreate.Controls.Add(this.tbxInsertQuantity);
            this.tabCreate.Controls.Add(this.btnSave);
            this.tabCreate.Controls.Add(this.btnAdd);
            this.tabCreate.Controls.Add(this.label7);
            this.tabCreate.Controls.Add(this.label6);
            this.tabCreate.Controls.Add(this.label5);
            this.tabCreate.Controls.Add(this.label4);
            this.tabCreate.Controls.Add(this.label3);
            this.tabCreate.Controls.Add(this.label2);
            this.tabCreate.Controls.Add(this.tbxDesc);
            this.tabCreate.Controls.Add(this.tbxType);
            this.tabCreate.Controls.Add(this.tbxPrice);
            this.tabCreate.Controls.Add(this.tbxCost);
            this.tabCreate.Controls.Add(this.pbxInsertedImage);
            this.tabCreate.Controls.Add(this.tbxName);
            this.tabCreate.Location = new System.Drawing.Point(4, 22);
            this.tabCreate.Name = "tabCreate";
            this.tabCreate.Padding = new System.Windows.Forms.Padding(3);
            this.tabCreate.Size = new System.Drawing.Size(510, 363);
            this.tabCreate.TabIndex = 1;
            this.tabCreate.Text = "Add New Merchandise";
            this.tabCreate.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(304, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Quantity";
            // 
            // tbxInsertQuantity
            // 
            this.tbxInsertQuantity.Location = new System.Drawing.Point(304, 72);
            this.tbxInsertQuantity.Name = "tbxInsertQuantity";
            this.tbxInsertQuantity.Size = new System.Drawing.Size(46, 20);
            this.tbxInsertQuantity.TabIndex = 15;
            this.tbxInsertQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxInsertQuantity_KeyPress);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(295, 326);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(112, 23);
            this.btnSave.TabIndex = 14;
            this.btnSave.Text = "Save &New Card";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(42, 326);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(140, 23);
            this.btnAdd.TabIndex = 12;
            this.btnAdd.Text = "&Add New Card Image";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Card Image Index: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(246, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Card Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(353, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Card Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(243, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Card Cost";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(246, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Card Type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(246, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Card Details";
            // 
            // tbxDesc
            // 
            this.tbxDesc.Location = new System.Drawing.Point(246, 156);
            this.tbxDesc.Multiline = true;
            this.tbxDesc.Name = "tbxDesc";
            this.tbxDesc.Size = new System.Drawing.Size(161, 164);
            this.tbxDesc.TabIndex = 5;
            // 
            // tbxType
            // 
            this.tbxType.Location = new System.Drawing.Point(246, 116);
            this.tbxType.Name = "tbxType";
            this.tbxType.Size = new System.Drawing.Size(161, 20);
            this.tbxType.TabIndex = 4;
            // 
            // tbxPrice
            // 
            this.tbxPrice.Location = new System.Drawing.Point(356, 73);
            this.tbxPrice.Name = "tbxPrice";
            this.tbxPrice.Size = new System.Drawing.Size(51, 20);
            this.tbxPrice.TabIndex = 3;
            this.tbxPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxPrice_KeyPress);
            // 
            // tbxCost
            // 
            this.tbxCost.Location = new System.Drawing.Point(246, 73);
            this.tbxCost.Name = "tbxCost";
            this.tbxCost.Size = new System.Drawing.Size(51, 20);
            this.tbxCost.TabIndex = 2;
            this.tbxCost.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxCost_KeyPress);
            // 
            // pbxInsertedImage
            // 
            this.pbxInsertedImage.Location = new System.Drawing.Point(6, 24);
            this.pbxInsertedImage.Name = "pbxInsertedImage";
            this.pbxInsertedImage.Size = new System.Drawing.Size(220, 296);
            this.pbxInsertedImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxInsertedImage.TabIndex = 1;
            this.pbxInsertedImage.TabStop = false;
            // 
            // tbxName
            // 
            this.tbxName.Location = new System.Drawing.Point(246, 24);
            this.tbxName.Name = "tbxName";
            this.tbxName.Size = new System.Drawing.Size(161, 20);
            this.tbxName.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.devotionOnSaleToolStripMenuItem,
            this.howDoIAddNewItemsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(549, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // devotionOnSaleToolStripMenuItem
            // 
            this.devotionOnSaleToolStripMenuItem.Name = "devotionOnSaleToolStripMenuItem";
            this.devotionOnSaleToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.devotionOnSaleToolStripMenuItem.Text = "&Devotion on Sale?";
            this.devotionOnSaleToolStripMenuItem.Click += new System.EventHandler(this.devotionOnSaleToolStripMenuItem_Click);
            // 
            // howDoIAddNewItemsToolStripMenuItem
            // 
            this.howDoIAddNewItemsToolStripMenuItem.Name = "howDoIAddNewItemsToolStripMenuItem";
            this.howDoIAddNewItemsToolStripMenuItem.Size = new System.Drawing.Size(152, 20);
            this.howDoIAddNewItemsToolStripMenuItem.Text = "&How do I add new items?";
            this.howDoIAddNewItemsToolStripMenuItem.Click += new System.EventHandler(this.howDoIAddNewItemsToolStripMenuItem_Click);
            // 
            // frmInventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 445);
            this.ControlBox = false;
            this.Controls.Add(this.tbcAlter);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmInventory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jester\'s Menagerie-Inventory Manipulation";
            this.Load += new System.EventHandler(this.frmInventory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).EndInit();
            this.tbcAlter.ResumeLayout(false);
            this.tabAlterRemove.ResumeLayout(false);
            this.tabAlterRemove.PerformLayout();
            this.tabCreate.ResumeLayout(false);
            this.tabCreate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxInsertedImage)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxQuantity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnOrderQuantity;
        private System.Windows.Forms.DataGridView dgvInventory;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TabControl tbcAlter;
        private System.Windows.Forms.TabPage tabAlterRemove;
        private System.Windows.Forms.TabPage tabCreate;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbxDesc;
        private System.Windows.Forms.TextBox tbxType;
        private System.Windows.Forms.TextBox tbxPrice;
        private System.Windows.Forms.TextBox tbxCost;
        private System.Windows.Forms.PictureBox pbxInsertedImage;
        private System.Windows.Forms.TextBox tbxName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbxInsertQuantity;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.TextBox tbxDevotion;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnSale;
        private System.Windows.Forms.TextBox tbxSale;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem devotionOnSaleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem howDoIAddNewItemsToolStripMenuItem;
    }
}