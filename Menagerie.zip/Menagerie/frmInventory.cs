﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SP21_Final_Project
{
    public partial class frmInventory : Form
    {
        public frmInventory()
        {
            InitializeComponent();
            ProgOps.DatabaseCommandFillInv(dgvInventory);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnQuantity_Click(object sender, EventArgs e)
        {//This alters the quantity of the selected card in the table

            int intQuantity, intQuantityFromDB;

            int.TryParse(tbxQuantity.Text, out intQuantity);

            int.TryParse(dgvInventory.CurrentRow.Cells[1].Value.ToString(), out intQuantityFromDB);
            try
            {
                 
                    double dblPrice;

                    string strPricePlaceHolder = dgvInventory.CurrentRow.Cells[2].Value.ToString();

                    strPricePlaceHolder = strPricePlaceHolder.Substring(1, strPricePlaceHolder.Length - 1);

                    double.TryParse(strPricePlaceHolder, out dblPrice);

                    dblPrice *= intQuantity;
                try
                {
                    HtmlReports.PrintInventoryReceipt(HtmlReports.GenerateInventoryReceipt(dblPrice, dgvInventory.CurrentRow.Cells[0].Value.ToString(), intQuantity), dgvInventory.CurrentRow.Cells[0].Value.ToString());
                }catch(Exception)
                {
                    MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                

                ProgOps.DatabaseCommandReduceORIncreaseInv(intQuantity + intQuantityFromDB, dgvInventory.CurrentRow.Cells[0].Value.ToString());

                ProgOps.DatabaseCommandFillInv(dgvInventory);

                tbxQuantity.Text = "";

            }catch(Exception)
            {
                MessageBox.Show("Error ordering new cards", "Error making order", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tbxQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {//Controls the textbox so only numbers can be applied
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && !e.KeyChar.Equals(45))
            {
                e.Handled = true;
            }
        }

        private void frmInventory_Load(object sender, EventArgs e)
        {
            ProgOps.DatabaseCommandFillInv(dgvInventory);
            btnSave.Enabled = false;
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            ProgOps.DatabaseCommandRemoveInv(dgvInventory.CurrentRow.Cells[0].Value.ToString());

            ProgOps.DatabaseCommandFillInv(dgvInventory);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.ValidateNames = true;
            fileDialog.AddExtension = false;
            fileDialog.Filter = "Image File|*.png|Image File|*.jpg";
            fileDialog.Title = "Card Image to Upload";

            if(fileDialog.ShowDialog() == DialogResult.OK)
            { try
                {
                    byte[] image = File.ReadAllBytes(fileDialog.FileName);

                    double dblPrice = 0.0f;
                    double.TryParse(tbxPrice.Text, out dblPrice);
                    ProgOps.DatabaseCommandUploadCard(image);
                    ProgOps.LoadInventoryImage(image, pbxInsertedImage);

                    btnSave.Enabled = true;
                    btnAdd.Enabled = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error with the loaded image", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
           
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            double dblPrice = 0.0f;
            double.TryParse(tbxPrice.Text, out dblPrice);
            try
            {
                ProgOps.DatabaseCommandInsertCardInformation(tbxName.Text.Replace("'", "''"), tbxCost.Text, tbxType.Text.Replace("'", "''"), tbxDesc.Text.Replace("'", "''"), dblPrice, tbxInsertQuantity.Text);

                ProgOps.DatabaseCommandFillInv(dgvInventory);
            }catch(Exception Ex)
            {
                MessageBox.Show("There has been an error saving the new information. Please check your values", "Error Saving", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            btnSave.Enabled = false;
            btnAdd.Enabled = true;
        }

        private void tbxInsertQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {//Controls the textbox so only numbers can be applied
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && !e.KeyChar.Equals(45))
            {
                e.Handled = true;
            }

        }

        private void tbxPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Controls the textbox so only numbers can be applied
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && !e.KeyChar.Equals(45) && !e.KeyChar.Equals('.'))
            {
                e.Handled = true;
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try { 
            HtmlReports.PrintInventory(HtmlReports.GenerateInventory(ProgOps._sqlInventoryCommand));
                    }catch(Exception)
                {
                    MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
        }

        private void tbxDevotion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnSale_Click(object sender, EventArgs e)
        {
            double salePercent = 0;

            double.TryParse(tbxSale.Text, out salePercent);


            if(tbxDevotion.Text == "B" || tbxDevotion.Text == "G" || tbxDevotion.Text == "W"|| tbxDevotion.Text == "R"|| tbxDevotion.Text == "U")
            {
                if (salePercent <= 99)
                {
                    ProgOps.DatabaseCommandUpdateSales(tbxDevotion.Text, salePercent);
                    MessageBox.Show("A sale has been placed for all " + tbxDevotion.Text + " Cards.", "Sale Placed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    tbxDevotion.Clear();
                    tbxSale.Clear();
                }
                else {
                    MessageBox.Show("Sales amounts must be less than 100", "Amount for Sales", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Devotion saales can only be attributed to the colors B, G, W, U, and R", "Colors for Sales", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void tbxSale_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbxCost_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != 66 && e.KeyChar != 87 && e.KeyChar != 85 && e.KeyChar != 71 && e.KeyChar != 82)
            {
                e.Handled = true;
            }
        }

        private void howDoIAddNewItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try { 
            HtmlReports.PrintSaveNewCardHelp(HtmlReports.SaveNewCardHelp());
            }
            catch (Exception)
            {
                MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void devotionOnSaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try { 
            HtmlReports.PrintDevotionSaleHelp(HtmlReports.DevotionSaleHelp());
            }
            catch (Exception)
            {
                MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
