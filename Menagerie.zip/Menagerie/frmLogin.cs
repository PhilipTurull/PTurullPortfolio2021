﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SP21_Final_Project
{
    public partial class frmLogin : Form
    {


        


        public bool blnLoggedin = false;
        public bool blnSignUp = false, blnRecover = false, blnLoginSuccessful = false;
        public string strRecoveryTable;
        frmMain MainScreen;
        public frmLogin(frmMain main)
        {
            InitializeComponent();
            MainScreen = main;
        }

        private void btnTryLogin_Click(object sender, EventArgs e)
        {//check the login credentials against the customers then the employees table
            if (tbxUser.Text == string.Empty)
            {
                tbxUser.Focus();
                MessageBox.Show("Please enter a Username!");
            }
            if (tbxPassword.Text == string.Empty)
            {
                tbxPassword.Focus();
                MessageBox.Show("Please enter a Password!");
            }

            if (tbxUser.Text != string.Empty && tbxPassword.Text != string.Empty)
            {
                ProgOps.DatabaseCommandLogginCustomers(tbxUser, tbxPassword, MainScreen, this);
            }
            //check to see if sign up is necessary
            if(blnSignUp == true)
            {
                frmSignUp signingUp = new frmSignUp(MainScreen);
                signingUp.Show();
                this.Hide();
            }

            if(blnRecover == true)
            {
                try
                {
                    frmRecover recover = new frmRecover(tbxUser.Text, strRecoveryTable);
                    recover.Show();
                    this.Hide();

                }catch(Exception)
                {
                    MessageBox.Show("Error recovering user info please try again.", "Error accessing info", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }


        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRecover_Click(object sender, EventArgs e)
        {//Recover Password
            if(tbxUser.Text == ProgOps.DatabaseCommandRecoverCustUser(tbxUser, MainScreen))
            {
                frmRecover recover = new frmRecover(tbxUser.Text, "Cust");
                recover.Show();
            }
            else if(tbxUser.Text == ProgOps.DatabaseCommandRecoverEmployees(tbxUser, MainScreen))
            {
                frmRecover recover = new frmRecover(tbxUser.Text, "Emp");
                recover.Show();
            }
        }

       

        private void btnSignup_Click(object sender, EventArgs e)
        {
            frmSignUp signingUp = new frmSignUp(MainScreen);
            signingUp.Show();
            this.Hide();
        }
    }
}
