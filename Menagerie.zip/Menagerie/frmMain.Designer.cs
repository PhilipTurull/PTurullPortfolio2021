﻿
namespace SP21_Final_Project
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuLogin = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuLogout = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOrders = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuChkOrders = new System.Windows.Forms.ToolStripMenuItem();
            this.tournamentInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.upcomingTourneysToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpPageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuViewDetailsHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFilterHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCardCostHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAddItemHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.whatDoesOnSaleMeanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEmp = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSchedule = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAlterInformation = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAlter = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuManMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSearch = new System.Windows.Forms.Button();
            this.tbxSearchBar = new System.Windows.Forms.TextBox();
            this.gbxFilter = new System.Windows.Forms.GroupBox();
            this.rbnExclusive = new System.Windows.Forms.RadioButton();
            this.rbnInclusive = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbxLand = new System.Windows.Forms.CheckBox();
            this.cbxEnchantment = new System.Windows.Forms.CheckBox();
            this.cbxArtifact = new System.Windows.Forms.CheckBox();
            this.cbxInstant = new System.Windows.Forms.CheckBox();
            this.cbxSorcery = new System.Windows.Forms.CheckBox();
            this.cbxCreature = new System.Windows.Forms.CheckBox();
            this.cbxGreen = new System.Windows.Forms.CheckBox();
            this.cbxWhite = new System.Windows.Forms.CheckBox();
            this.cbxRed = new System.Windows.Forms.CheckBox();
            this.cbxBlue = new System.Windows.Forms.CheckBox();
            this.cbxBlack = new System.Windows.Forms.CheckBox();
            this.dgvCards = new System.Windows.Forms.DataGridView();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnCheckout = new System.Windows.Forms.Button();
            this.lblOrderID = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.gbxFilter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCards)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.mnuOrders,
            this.tournamentInfoToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.mnuEmp});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1051, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuLogin,
            this.mnuLogout,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // mnuLogin
            // 
            this.mnuLogin.Name = "mnuLogin";
            this.mnuLogin.Size = new System.Drawing.Size(115, 22);
            this.mnuLogin.Text = "Login";
            this.mnuLogin.Click += new System.EventHandler(this.loginToolStripMenuItem_Click);
            // 
            // mnuLogout
            // 
            this.mnuLogout.Enabled = false;
            this.mnuLogout.Name = "mnuLogout";
            this.mnuLogout.Size = new System.Drawing.Size(115, 22);
            this.mnuLogout.Text = "Log out";
            this.mnuLogout.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // mnuOrders
            // 
            this.mnuOrders.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuChkOrders});
            this.mnuOrders.Enabled = false;
            this.mnuOrders.Name = "mnuOrders";
            this.mnuOrders.Size = new System.Drawing.Size(54, 20);
            this.mnuOrders.Text = "&Orders";
            // 
            // mnuChkOrders
            // 
            this.mnuChkOrders.Name = "mnuChkOrders";
            this.mnuChkOrders.Size = new System.Drawing.Size(145, 22);
            this.mnuChkOrders.Text = "Check O&rders";
            this.mnuChkOrders.Click += new System.EventHandler(this.checkOrdersToolStripMenuItem_Click);
            // 
            // tournamentInfoToolStripMenuItem
            // 
            this.tournamentInfoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.upcomingTourneysToolStripMenuItem});
            this.tournamentInfoToolStripMenuItem.Name = "tournamentInfoToolStripMenuItem";
            this.tournamentInfoToolStripMenuItem.Size = new System.Drawing.Size(107, 20);
            this.tournamentInfoToolStripMenuItem.Text = "&Tournament Info";
            // 
            // upcomingTourneysToolStripMenuItem
            // 
            this.upcomingTourneysToolStripMenuItem.Name = "upcomingTourneysToolStripMenuItem";
            this.upcomingTourneysToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.upcomingTourneysToolStripMenuItem.Text = "&Upcoming Tourneys";
            this.upcomingTourneysToolStripMenuItem.Click += new System.EventHandler(this.upcomingTourneysToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpPageToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // helpPageToolStripMenuItem
            // 
            this.helpPageToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuViewDetailsHelp,
            this.mnuFilterHelp,
            this.mnuCardCostHelp,
            this.mnuAddItemHelp,
            this.whatDoesOnSaleMeanToolStripMenuItem});
            this.helpPageToolStripMenuItem.Name = "helpPageToolStripMenuItem";
            this.helpPageToolStripMenuItem.Size = new System.Drawing.Size(99, 22);
            this.helpPageToolStripMenuItem.Text = "H&elp";
            // 
            // mnuViewDetailsHelp
            // 
            this.mnuViewDetailsHelp.Name = "mnuViewDetailsHelp";
            this.mnuViewDetailsHelp.Size = new System.Drawing.Size(272, 22);
            this.mnuViewDetailsHelp.Text = "How do I view the &details for an item?";
            this.mnuViewDetailsHelp.Click += new System.EventHandler(this.mnuViewDetailsHelp_Click);
            // 
            // mnuFilterHelp
            // 
            this.mnuFilterHelp.Name = "mnuFilterHelp";
            this.mnuFilterHelp.Size = new System.Drawing.Size(272, 22);
            this.mnuFilterHelp.Text = "What are the &filters for?";
            this.mnuFilterHelp.Click += new System.EventHandler(this.mnuFilterHelp_Click);
            // 
            // mnuCardCostHelp
            // 
            this.mnuCardCostHelp.Name = "mnuCardCostHelp";
            this.mnuCardCostHelp.Size = new System.Drawing.Size(272, 22);
            this.mnuCardCostHelp.Text = "Card &Cost vs Card Price";
            this.mnuCardCostHelp.Click += new System.EventHandler(this.mnuCardCostHelp_Click);
            // 
            // mnuAddItemHelp
            // 
            this.mnuAddItemHelp.Name = "mnuAddItemHelp";
            this.mnuAddItemHelp.Size = new System.Drawing.Size(272, 22);
            this.mnuAddItemHelp.Text = "How do I &add an item to my cart?";
            this.mnuAddItemHelp.Click += new System.EventHandler(this.mnuAddItemHelp_Click);
            // 
            // whatDoesOnSaleMeanToolStripMenuItem
            // 
            this.whatDoesOnSaleMeanToolStripMenuItem.Name = "whatDoesOnSaleMeanToolStripMenuItem";
            this.whatDoesOnSaleMeanToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.whatDoesOnSaleMeanToolStripMenuItem.Text = "What does On Sale mean?";
            this.whatDoesOnSaleMeanToolStripMenuItem.Click += new System.EventHandler(this.whatDoesOnSaleMeanToolStripMenuItem_Click);
            // 
            // mnuEmp
            // 
            this.mnuEmp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuSchedule,
            this.mnuAlterInformation,
            this.mnuAlter,
            this.mnuManMenu});
            this.mnuEmp.Enabled = false;
            this.mnuEmp.Name = "mnuEmp";
            this.mnuEmp.Size = new System.Drawing.Size(76, 20);
            this.mnuEmp.Text = "&Employees";
            // 
            // mnuSchedule
            // 
            this.mnuSchedule.Name = "mnuSchedule";
            this.mnuSchedule.Size = new System.Drawing.Size(165, 22);
            this.mnuSchedule.Text = "My &Schedule";
            this.mnuSchedule.Click += new System.EventHandler(this.myScheduleToolStripMenuItem_Click);
            // 
            // mnuAlterInformation
            // 
            this.mnuAlterInformation.Name = "mnuAlterInformation";
            this.mnuAlterInformation.Size = new System.Drawing.Size(165, 22);
            this.mnuAlterInformation.Text = "Al&ter Information";
            this.mnuAlterInformation.Click += new System.EventHandler(this.mnuAlterInformation_Click);
            // 
            // mnuAlter
            // 
            this.mnuAlter.Enabled = false;
            this.mnuAlter.Name = "mnuAlter";
            this.mnuAlter.Size = new System.Drawing.Size(165, 22);
            this.mnuAlter.Text = "&Alter Schedule";
            this.mnuAlter.Click += new System.EventHandler(this.alterScheduleToolStripMenuItem_Click);
            // 
            // mnuManMenu
            // 
            this.mnuManMenu.Enabled = false;
            this.mnuManMenu.Name = "mnuManMenu";
            this.mnuManMenu.Size = new System.Drawing.Size(165, 22);
            this.mnuManMenu.Text = "&Managers\' Menu";
            this.mnuManMenu.Click += new System.EventHandler(this.btnManMenu_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(864, 85);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 13;
            this.btnSearch.Text = "&Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // tbxSearchBar
            // 
            this.tbxSearchBar.Location = new System.Drawing.Point(798, 59);
            this.tbxSearchBar.Name = "tbxSearchBar";
            this.tbxSearchBar.Size = new System.Drawing.Size(196, 20);
            this.tbxSearchBar.TabIndex = 16;
            // 
            // gbxFilter
            // 
            this.gbxFilter.Controls.Add(this.rbnExclusive);
            this.gbxFilter.Controls.Add(this.rbnInclusive);
            this.gbxFilter.Controls.Add(this.label2);
            this.gbxFilter.Controls.Add(this.label1);
            this.gbxFilter.Controls.Add(this.cbxLand);
            this.gbxFilter.Controls.Add(this.cbxEnchantment);
            this.gbxFilter.Controls.Add(this.cbxArtifact);
            this.gbxFilter.Controls.Add(this.cbxInstant);
            this.gbxFilter.Controls.Add(this.cbxSorcery);
            this.gbxFilter.Controls.Add(this.cbxCreature);
            this.gbxFilter.Controls.Add(this.cbxGreen);
            this.gbxFilter.Controls.Add(this.cbxWhite);
            this.gbxFilter.Controls.Add(this.cbxRed);
            this.gbxFilter.Controls.Add(this.cbxBlue);
            this.gbxFilter.Controls.Add(this.cbxBlack);
            this.gbxFilter.Location = new System.Drawing.Point(808, 155);
            this.gbxFilter.Name = "gbxFilter";
            this.gbxFilter.Size = new System.Drawing.Size(200, 238);
            this.gbxFilter.TabIndex = 17;
            this.gbxFilter.TabStop = false;
            this.gbxFilter.Text = "Tag Filters:";
            // 
            // rbnExclusive
            // 
            this.rbnExclusive.AutoSize = true;
            this.rbnExclusive.Location = new System.Drawing.Point(92, 215);
            this.rbnExclusive.Name = "rbnExclusive";
            this.rbnExclusive.Size = new System.Drawing.Size(70, 17);
            this.rbnExclusive.TabIndex = 14;
            this.rbnExclusive.TabStop = true;
            this.rbnExclusive.Text = "Exclusive";
            this.rbnExclusive.UseVisualStyleBackColor = true;
            this.rbnExclusive.CheckedChanged += new System.EventHandler(this.rbnExclusive_CheckedChanged);
            // 
            // rbnInclusive
            // 
            this.rbnInclusive.AutoSize = true;
            this.rbnInclusive.Location = new System.Drawing.Point(6, 215);
            this.rbnInclusive.Name = "rbnInclusive";
            this.rbnInclusive.Size = new System.Drawing.Size(67, 17);
            this.rbnInclusive.TabIndex = 13;
            this.rbnInclusive.TabStop = true;
            this.rbnInclusive.Text = "Inclusive";
            this.rbnInclusive.UseVisualStyleBackColor = true;
            this.rbnInclusive.CheckedChanged += new System.EventHandler(this.rbnInclusive_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(92, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Card Types:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Colors:";
            // 
            // cbxLand
            // 
            this.cbxLand.AutoSize = true;
            this.cbxLand.Location = new System.Drawing.Point(92, 173);
            this.cbxLand.Name = "cbxLand";
            this.cbxLand.Size = new System.Drawing.Size(55, 17);
            this.cbxLand.TabIndex = 10;
            this.cbxLand.Text = "Lands";
            this.cbxLand.UseVisualStyleBackColor = true;
            this.cbxLand.CheckedChanged += new System.EventHandler(this.cbxLand_CheckedChanged);
            // 
            // cbxEnchantment
            // 
            this.cbxEnchantment.AutoSize = true;
            this.cbxEnchantment.Location = new System.Drawing.Point(92, 150);
            this.cbxEnchantment.Name = "cbxEnchantment";
            this.cbxEnchantment.Size = new System.Drawing.Size(94, 17);
            this.cbxEnchantment.TabIndex = 9;
            this.cbxEnchantment.Text = "Enchantments";
            this.cbxEnchantment.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cbxEnchantment.UseVisualStyleBackColor = true;
            this.cbxEnchantment.CheckedChanged += new System.EventHandler(this.cbxEnchantment_CheckedChanged);
            // 
            // cbxArtifact
            // 
            this.cbxArtifact.AutoSize = true;
            this.cbxArtifact.Location = new System.Drawing.Point(92, 127);
            this.cbxArtifact.Name = "cbxArtifact";
            this.cbxArtifact.Size = new System.Drawing.Size(64, 17);
            this.cbxArtifact.TabIndex = 8;
            this.cbxArtifact.Text = "Artifacts";
            this.cbxArtifact.UseVisualStyleBackColor = true;
            this.cbxArtifact.CheckedChanged += new System.EventHandler(this.cbxArtifact_CheckedChanged);
            // 
            // cbxInstant
            // 
            this.cbxInstant.AutoSize = true;
            this.cbxInstant.Location = new System.Drawing.Point(92, 106);
            this.cbxInstant.Name = "cbxInstant";
            this.cbxInstant.Size = new System.Drawing.Size(63, 17);
            this.cbxInstant.TabIndex = 7;
            this.cbxInstant.Text = "Instants";
            this.cbxInstant.UseVisualStyleBackColor = true;
            this.cbxInstant.CheckedChanged += new System.EventHandler(this.cbxInstant_CheckedChanged);
            // 
            // cbxSorcery
            // 
            this.cbxSorcery.AutoSize = true;
            this.cbxSorcery.Location = new System.Drawing.Point(92, 83);
            this.cbxSorcery.Name = "cbxSorcery";
            this.cbxSorcery.Size = new System.Drawing.Size(62, 17);
            this.cbxSorcery.TabIndex = 6;
            this.cbxSorcery.Text = "Sorcery";
            this.cbxSorcery.UseVisualStyleBackColor = true;
            this.cbxSorcery.CheckedChanged += new System.EventHandler(this.cbxSorcery_CheckedChanged);
            // 
            // cbxCreature
            // 
            this.cbxCreature.AutoSize = true;
            this.cbxCreature.Location = new System.Drawing.Point(92, 60);
            this.cbxCreature.Name = "cbxCreature";
            this.cbxCreature.Size = new System.Drawing.Size(71, 17);
            this.cbxCreature.TabIndex = 5;
            this.cbxCreature.Text = "Creatures";
            this.cbxCreature.UseVisualStyleBackColor = true;
            this.cbxCreature.CheckedChanged += new System.EventHandler(this.cbxCreature_CheckedChanged);
            // 
            // cbxGreen
            // 
            this.cbxGreen.AutoSize = true;
            this.cbxGreen.Location = new System.Drawing.Point(6, 127);
            this.cbxGreen.Name = "cbxGreen";
            this.cbxGreen.Size = new System.Drawing.Size(55, 17);
            this.cbxGreen.TabIndex = 4;
            this.cbxGreen.Text = "Green";
            this.cbxGreen.UseVisualStyleBackColor = true;
            this.cbxGreen.CheckedChanged += new System.EventHandler(this.cbxGreen_CheckedChanged);
            // 
            // cbxWhite
            // 
            this.cbxWhite.AutoSize = true;
            this.cbxWhite.Location = new System.Drawing.Point(6, 106);
            this.cbxWhite.Name = "cbxWhite";
            this.cbxWhite.Size = new System.Drawing.Size(54, 17);
            this.cbxWhite.TabIndex = 3;
            this.cbxWhite.Text = "White";
            this.cbxWhite.UseVisualStyleBackColor = true;
            this.cbxWhite.CheckedChanged += new System.EventHandler(this.cbxWhite_CheckedChanged);
            // 
            // cbxRed
            // 
            this.cbxRed.AutoSize = true;
            this.cbxRed.Location = new System.Drawing.Point(6, 83);
            this.cbxRed.Name = "cbxRed";
            this.cbxRed.Size = new System.Drawing.Size(46, 17);
            this.cbxRed.TabIndex = 2;
            this.cbxRed.Text = "Red";
            this.cbxRed.UseVisualStyleBackColor = true;
            this.cbxRed.CheckedChanged += new System.EventHandler(this.cbxRed_CheckedChanged);
            // 
            // cbxBlue
            // 
            this.cbxBlue.AutoSize = true;
            this.cbxBlue.Location = new System.Drawing.Point(6, 60);
            this.cbxBlue.Name = "cbxBlue";
            this.cbxBlue.Size = new System.Drawing.Size(47, 17);
            this.cbxBlue.TabIndex = 1;
            this.cbxBlue.Text = "Blue";
            this.cbxBlue.UseVisualStyleBackColor = true;
            this.cbxBlue.CheckedChanged += new System.EventHandler(this.cbxBlue_CheckedChanged);
            // 
            // cbxBlack
            // 
            this.cbxBlack.AutoSize = true;
            this.cbxBlack.Location = new System.Drawing.Point(6, 37);
            this.cbxBlack.Name = "cbxBlack";
            this.cbxBlack.Size = new System.Drawing.Size(53, 17);
            this.cbxBlack.TabIndex = 0;
            this.cbxBlack.Text = "Black";
            this.cbxBlack.UseVisualStyleBackColor = true;
            this.cbxBlack.CheckedChanged += new System.EventHandler(this.cbxBlack_CheckedChanged);
            // 
            // dgvCards
            // 
            this.dgvCards.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvCards.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCards.Location = new System.Drawing.Point(13, 39);
            this.dgvCards.Name = "dgvCards";
            this.dgvCards.ReadOnly = true;
            this.dgvCards.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCards.Size = new System.Drawing.Size(779, 399);
            this.dgvCards.TabIndex = 20;
            this.dgvCards.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvCards_CellMouseDoubleClick);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(933, 403);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 21;
            this.btnClear.Text = "C&lear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnCheckout
            // 
            this.btnCheckout.Location = new System.Drawing.Point(808, 403);
            this.btnCheckout.Name = "btnCheckout";
            this.btnCheckout.Size = new System.Drawing.Size(75, 23);
            this.btnCheckout.TabIndex = 22;
            this.btnCheckout.Text = "&Check Out";
            this.btnCheckout.UseVisualStyleBackColor = true;
            this.btnCheckout.Click += new System.EventHandler(this.btnCheckout_Click);
            // 
            // lblOrderID
            // 
            this.lblOrderID.AutoSize = true;
            this.lblOrderID.Location = new System.Drawing.Point(958, 136);
            this.lblOrderID.Name = "lblOrderID";
            this.lblOrderID.Size = new System.Drawing.Size(0, 13);
            this.lblOrderID.TabIndex = 23;
            this.lblOrderID.Visible = false;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1051, 453);
            this.Controls.Add(this.lblOrderID);
            this.Controls.Add(this.btnCheckout);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.dgvCards);
            this.Controls.Add(this.gbxFilter);
            this.Controls.Add(this.tbxSearchBar);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Jester\'s Menagerie";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.gbxFilter.ResumeLayout(false);
            this.gbxFilter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCards)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpPageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuChkOrders;
        private System.Windows.Forms.ToolStripMenuItem mnuSchedule;
        private System.Windows.Forms.ToolStripMenuItem mnuAlter;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox tbxSearchBar;
        private System.Windows.Forms.GroupBox gbxFilter;
        private System.Windows.Forms.CheckBox cbxLand;
        private System.Windows.Forms.CheckBox cbxEnchantment;
        private System.Windows.Forms.CheckBox cbxArtifact;
        private System.Windows.Forms.CheckBox cbxInstant;
        private System.Windows.Forms.CheckBox cbxSorcery;
        private System.Windows.Forms.CheckBox cbxCreature;
        private System.Windows.Forms.CheckBox cbxGreen;
        private System.Windows.Forms.CheckBox cbxWhite;
        private System.Windows.Forms.CheckBox cbxRed;
        private System.Windows.Forms.CheckBox cbxBlue;
        private System.Windows.Forms.CheckBox cbxBlack;
        private System.Windows.Forms.ToolStripMenuItem tournamentInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem upcomingTourneysToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbnExclusive;
        private System.Windows.Forms.RadioButton rbnInclusive;
        private System.Windows.Forms.Button btnClear;
        public System.Windows.Forms.MenuStrip menuStrip1;
        public System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem mnuLogin;
        public System.Windows.Forms.ToolStripMenuItem mnuLogout;
        public System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem mnuOrders;
        public System.Windows.Forms.ToolStripMenuItem mnuEmp;
        public System.Windows.Forms.ToolStripMenuItem mnuManMenu;
        private System.Windows.Forms.Button btnCheckout;
        private System.Windows.Forms.ToolStripMenuItem mnuAlterInformation;
        private System.Windows.Forms.Label lblOrderID;
        private System.Windows.Forms.ToolStripMenuItem mnuFilterHelp;
        private System.Windows.Forms.ToolStripMenuItem mnuCardCostHelp;
        private System.Windows.Forms.ToolStripMenuItem mnuAddItemHelp;
        private System.Windows.Forms.ToolStripMenuItem mnuViewDetailsHelp;
        public System.Windows.Forms.DataGridView dgvCards;
        private System.Windows.Forms.ToolStripMenuItem whatDoesOnSaleMeanToolStripMenuItem;
    }
}

