﻿//Programmer: Philip Turull
//Course: INEW-2332-10Z1
//Program Purpose: Showcase my abilities as a programmer

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/*okay so I want to figure out howw to put all the images into the dattabase
decide on how I want the items to be dispayed. I want to hide the log off button
Establist states of existence for the program
tag system is a goood way too restrict the viewed options for cards
checked list? or changing pages with picture boxes. Checkered list sseems better
maybe allow for selected items to show up in their oown form?
JM-Browse
JM-Employee View
JM-Manager View
*/
namespace SP21_Final_Project
{
  

    public partial class frmMain : Form
    {
        //Cart and Card information----------
        public List<string> strCart = new List<string>();
        public List<double> dblPrice = new List<double>();
        public List<int> intCardCount = new List<int>();
        public List<string> strDupe = new List<string>();
        public List<double> dblCardPrices = new List<double>();
        public List<int> intMaximumPurchasable = new List<int>();
        //----------------------------------



        //Filter information ---------------
        public string strQuery = "", strDefaultQuery= "", strFirstFilter = "";
        bool blnFiltered = false;
        //----------------------------------


        //Sign in and signed up information--
        public int intUserID = 0;
        public string strUsername = "", strPassword = "";
        public int intSecurityLevel = 0;
        public int intOrderID = 0; 
        public bool blnLoggedin = false;
        //-------------------------------------------------



        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

            strQuery = "SELECT CardName As 'Card Name', CardCost As 'Devotion', CardType As 'Type', Format(CardPrice, 'C') As 'Price', Quantity as 'Current Stock', OnSale as 'On Sale', PercentOff as '% Off' FROM TurullPsp212332.ProductInfo";

            strDefaultQuery = strQuery;

            ProgOps.OpenDatabase();

            ProgOps.DatabaseCommandProd(dgvCards, strQuery);

            rbnExclusive.Checked = true;

            grantRemoveAccess();

            CheckFirstFilter();

        }

        private void upcomingTourneysToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTourneys tourney = new frmTourneys(this);
            tourney.Show();
        }


        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            if(strCart.Count() > 0)
            {
                strCart.Clear();
            }

            ProgOps.CloseDatabaseDispose();
            Application.Exit();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if(tbxSearchBar.Text != "")
            {
                ClearSearch();

                strFirstFilter = "SearchBar";
                strQuery += $" where CardName like '%{tbxSearchBar.Text.Replace("'", "''")}%'";
                ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                btnClear.Enabled = true;
            }
        }

        private void myScheduleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSchedule schedule = new frmSchedule(this, "Own");
            schedule.ShowDialog();
        }

        private void alterScheduleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (intSecurityLevel < 3)
            {
                frmAskSwap swap = new frmAskSwap(strUsername);
                swap.ShowDialog();
            }
            if(intSecurityLevel == 3)
            {
                frmSchAdjust adjust = new frmSchAdjust();
                adjust.Show();
            }

        }


        //----------------------------------------BLACK FILTER
        private void cbxBlack_CheckedChanged(object sender, EventArgs e)
        {
            //sets blnFiltered to false if there is no other checkboces checked
            //if all other boxes are false
            CheckFirstFilter();

            //checks to see if the first filter is the Black card color checkbox if not then we add to the where clause
            //checks for things that contain black
            if (rbnExclusive.Checked == true)
            {
                if (cbxBlack.Checked == true && strFirstFilter == "Black")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardCost like '%B%'");

                }
                else if (cbxBlack.Checked == true && strFirstFilter != "Black")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " or CardCost like '%B%'");
                    blnFiltered = true;
                }
                else if (cbxBlack.Checked == false && strFirstFilter != "Black")
                {
                    if (strQuery.Contains(" or CardCost like '%B%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%B%") - 20, 23);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardCost like '%B%' or"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%B%") - 22, 29);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
            else 
            {
                //checks for things that contain black as well as other colors
                if (cbxBlack.Checked == true && strFirstFilter == "Black")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardCost like '%B%'");

                }
                else if (cbxBlack.Checked == true && strFirstFilter != "Black")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " and CardCost like '%B%'");
                    blnFiltered = true;
                }
                else if (cbxBlack.Checked == false && strFirstFilter != "Black")
                {
                    if (strQuery.Contains(" and CardCost like '%B%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%B%") - 20, 23);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardCost like '%B%' and"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%B%") - 21, 29);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }

        }


        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmLogin loggingin = new frmLogin(this);
            loggingin.ShowDialog();
            
            if (strUsername != "")
            {
                mnuLogin.Enabled = false;

            }
        }
        //-----------------------------------------BLUE FILTER
        private void cbxBlue_CheckedChanged(object sender, EventArgs e)
        {
            CheckFirstFilter();

            if (rbnExclusive.Checked == true)
            {
                //checks to see if the first filter is the Blue card color checkbox if not then we add to the where clause
                //Checks to see if card cost contains Blue
                if (cbxBlue.Checked == true && strFirstFilter == "Blue")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardCost like '%U%'");

                }
                else if (cbxBlue.Checked == true && strFirstFilter != "Blue")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " or CardCost like '%U%'");
                    blnFiltered = true;
                }
                else if (cbxBlue.Checked == false && strFirstFilter != "Blue")
                {
                    if (strQuery.Contains(" or CardCost like '%U%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%U%") - 20, 23);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardCost like '%U%' or"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%U%") - 21, 28);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }else
            {
                //Checks if a cost includes blue as well as any other selections
                if (cbxBlue.Checked == true && strFirstFilter == "Blue")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardCost like '%U%'");

                }
                else if (cbxBlue.Checked == true && strFirstFilter != "Blue")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " and CardCost like '%U%'");
                    blnFiltered = true;
                }
                else if (cbxBlue.Checked == false && strFirstFilter != "Blue")
                {
                    if (strQuery.Contains(" and CardCost like '%U%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%U%") - 21, 24);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardCost like '%U%' and"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%U%") - 21, 29);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
        }


        //------------------------------------------RED FILTER
        private void cbxRed_CheckedChanged(object sender, EventArgs e)
        {
            CheckFirstFilter();

            if (rbnExclusive.Checked == true)
            {
                //checks to see if the first filter is the Red card color checkbox if not then we add to the where clause
                //Chhecks to see if card cost contains Red
                if (cbxRed.Checked == true && strFirstFilter == "Red")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardCost like '%R%'");

                }
                else if (cbxRed.Checked == true && strFirstFilter != "Red")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " or CardCost like '%R%'");
                }
                else if (cbxRed.Checked == false && strFirstFilter != "Red")
                {
                    if (strQuery.Contains(" or CardCost like '%R%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%R%") - 19, 23);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardCost like '%R%' or"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%R%") - 21, 28);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
            else
            {
                //Checks to see if card cost contains Red as well as any other selections
                if (cbxRed.Checked == true && strFirstFilter == "Red")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardCost like '%R%'");

                }
                else if (cbxRed.Checked == true && strFirstFilter != "Red")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " and CardCost like '%R%'");
                }
                else if (cbxRed.Checked == false && strFirstFilter != "Red")
                {
                    if (strQuery.Contains(" and CardCost like '%R%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%R%") - 21, 24);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardCost like '%R%' and"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%R%") - 21, 29);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you for your patronage " + strUsername + "!", "See you soon!", MessageBoxButtons.OK);

            blnLoggedin = false;
            intSecurityLevel = 0;
            strUsername = "";
            strPassword = "";
            grantRemoveAccess();
            mnuLogin.Enabled = true;

            if(strCart.Count() > 0)
            {
                strCart.Clear();
            }
        }

        public void grantRemoveAccess()
        {
            if(strUsername == "")
            {
                mnuLogin.Enabled = true;
            }

            if (intSecurityLevel == 0)
            {
                mnuEmp.Enabled = false;
                mnuLogout.Enabled = false;
                mnuOrders.Enabled = false;
                mnuManMenu.Enabled = false;
                mnuAlter.Enabled = false;
                btnCheckout.Enabled = false;
            }
            if(intSecurityLevel >= 1)
            {
                mnuLogout.Enabled = true;
                mnuOrders.Enabled = true;
                btnCheckout.Enabled = true;

            }
            if(intSecurityLevel >= 2)
            {
                mnuEmp.Enabled = true;
                mnuAlter.Enabled = true;
            }
            if(intSecurityLevel >= 3)
            {
                mnuManMenu.Enabled = true;

            }
        }

        private void checkOrdersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmOrders orders = new frmOrders(this);
            orders.ShowDialog();
        }

        private void btnManMenu_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu(this);
            menu.ShowDialog();
        }

        //*************************WHITE FILTER
        private void cbxWhite_CheckedChanged(object sender, EventArgs e)
        {
            CheckFirstFilter();

            if (rbnExclusive.Checked == true)
            {
                //checks to see if the first filter is the White card color checkbox if not then we add to the where clause
                if (cbxWhite.Checked == true && strFirstFilter == "White")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardCost like '%W%'");

                }
                else if (cbxWhite.Checked == true && strFirstFilter != "White")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " or CardCost like '%W%'");
                }
                else if (cbxWhite.Checked == false && strFirstFilter != "White")
                {
                    if (strQuery.Contains(" or CardCost like '%W%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%W%") - 20, 23);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardCost like '%W%' or"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%W%") - 21, 28);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
            else
            {

                //checks to see if the first filter is the Black card color checkbox if not then we add to the where clause
                if (cbxWhite.Checked == true && strFirstFilter == "White")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardCost like '%W%'");

                }
                else if (cbxWhite.Checked == true && strFirstFilter != "White")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " and CardCost like '%W%'");
                }
                else if (cbxWhite.Checked == false && strFirstFilter != "White")
                {
                    if (strQuery.Contains(" and CardCost like '%W%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%W%") - 21, 24);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardCost like '%W%' and"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("%W%") - 21, 29);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
        }

        //************************GREEN FILTER
        private void cbxGreen_CheckedChanged(object sender, EventArgs e)
        {
            CheckFirstFilter();

            if (rbnExclusive.Checked == true)
            {
                //checks to see if the first filter is the Green card color checkbox if not then we add to the where clause
                if (cbxGreen.Checked == true && strFirstFilter == "Green")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardCost like '%G%'");

                }
                else if (cbxGreen.Checked == true && strFirstFilter != "Green")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " or CardCost like '%G%'");
                }
                else if (cbxGreen.Checked == false && strFirstFilter != "Green")
                {
                    if (strQuery.Contains(" or CardCost like '%G%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("G") - 21, 23);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardCost like '%G%' or"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("G") - 22, 28);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
            else
            {
                if (cbxGreen.Checked == true && strFirstFilter == "Green")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardCost like '%G%'");

                }
                else if (cbxGreen.Checked == true && strFirstFilter != "Green")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " and CardCost like '%G%'");
                }
                else if (cbxGreen.Checked == false && strFirstFilter != "Green")
                {
                    if (strQuery.Contains(" and CardCost like '%G%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("G") - 22, 24);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardCost like '%G%' and"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("G") - 22, 29);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
        }

        //************************CREATURE FILTER
        private void cbxCreature_CheckedChanged(object sender, EventArgs e)
        {
            CheckFirstFilter();
            if (rbnExclusive.Checked == true)
            {
                if (cbxCreature.Checked == true && strFirstFilter == "Creature")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardType like '%Creature%'");

                }
                else if (cbxCreature.Checked == true && strFirstFilter != "Creature")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " or CardType like '%Creature%'");
                }
                else if (cbxCreature.Checked == false && strFirstFilter != "Creature")
                {
                    if (strQuery.Contains(" or CardType like '%Creature%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Creature") - 20, 30);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardType like '%Creature%' or"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Creature") - 22, 35);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
            else
            {
                if (cbxCreature.Checked == true && strFirstFilter == "Creature")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardType like '%Creature%'");

                }
                else if (cbxCreature.Checked == true && strFirstFilter != "Creature")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " and CardType like '%Creature%'");
                }
                else if (cbxCreature.Checked == false && strFirstFilter != "Creature")
                {
                    if (strQuery.Contains(" and CardType like '%Creature%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Creature") - 21, 31);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardType like '%Creature%' and"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Creature") - 22, 36);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
        }

        //**************************SORCERY FILTER
        private void cbxSorcery_CheckedChanged(object sender, EventArgs e)
        {
            CheckFirstFilter();

            if (rbnExclusive.Checked == true)
            {
                if (cbxSorcery.Checked == true && strFirstFilter == "Sorcery")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardType like '%Sorcery%'");

                }
                else if (cbxSorcery.Checked == true && strFirstFilter != "Sorcery")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " or CardType like '%Sorcery%'");
                }
                else if (cbxSorcery.Checked == false && strFirstFilter != "Sorcery")
                {
                    if (strQuery.Contains(" or CardType like '%Sorcery%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Sorcery") - 20, 29);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardType like '%Sorcery%' or"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Sorcery") - 22, 34);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
            else
            {
                if (cbxSorcery.Checked == true && strFirstFilter == "Sorcery")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardType like '%Sorcery%'");

                }
                else if (cbxSorcery.Checked == true && strFirstFilter != "Sorcery")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " and CardType like '%Sorcery%'");
                }
                else if (cbxSorcery.Checked == false && strFirstFilter != "Sorcery")
                {
                    if (strQuery.Contains(" and CardType like '%Sorcery%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Sorcery") - 21, 30);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardType like '%Sorcery%' and"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Sorcery") - 22, 35);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
        }

        //**************************INSTANT FILTER
        private void cbxInstant_CheckedChanged(object sender, EventArgs e)
        {
            CheckFirstFilter();

            if (rbnExclusive.Checked == true)
            {
                if (cbxInstant.Checked == true && strFirstFilter == "Instant")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardType like '%Instant%'");

                }
                else if (cbxInstant.Checked == true && strFirstFilter != "Instant")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " or CardType like '%Instant%'");
                }
                else if (cbxInstant.Checked == false && strFirstFilter != "Instant")
                {
                    if (strQuery.Contains(" or CardType like '%Instant%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Instant") - 20, 29);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardType like '%Instant%' or"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Instant") - 22, 34);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
            else
            {
                if (cbxInstant.Checked == true && strFirstFilter == "Instant")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardType like '%Instant%'");

                }
                else if (cbxInstant.Checked == true && strFirstFilter != "Instant")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " and CardType like '%Instant%'");
                }
                else if (cbxInstant.Checked == false && strFirstFilter != "Instant")
                {
                    if (strQuery.Contains(" and CardType like '%Instant%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Instant") - 21, 30);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardType like '%Instant%' and"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Instant") - 22, 35);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
        }

        //****************************ARTIFACT FILTER
        private void cbxArtifact_CheckedChanged(object sender, EventArgs e)
        {
            CheckFirstFilter();
            if (rbnExclusive.Checked == true)
            {
                if (cbxArtifact.Checked == true && strFirstFilter == "Artifact")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardType like '%Artifact%'");

                }
                else if (cbxArtifact.Checked == true && strFirstFilter != "Artifact")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " or CardType like '%Artifact%'");
                }
                else if (cbxArtifact.Checked == false && strFirstFilter != "Artifact")
                {
                    if (strQuery.Contains(" or CardType like '%Artifact%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Artifact") - 20, 30);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardType like '%Artifact%' or"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Artifact") - 22, 35);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
            else
            {
                if (cbxArtifact.Checked == true && strFirstFilter == "Artifact")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardType like '%Artifact%'");

                }
                else if (cbxArtifact.Checked == true && strFirstFilter != "Artifact")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " and CardType like '%Artifact%'");
                }
                else if (cbxArtifact.Checked == false && strFirstFilter != "Artifact")
                {
                    if (strQuery.Contains(" and CardType like '%Artifact%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Artifact") - 21, 31);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardType like '%Artifact%' and"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Artifact") - 22, 36);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
        }

        //*****************************ENCHANTMENT FILTER
        private void cbxEnchantment_CheckedChanged(object sender, EventArgs e)
        {
            CheckFirstFilter();

            if (rbnExclusive.Checked == true)
            {
                if (cbxEnchantment.Checked == true && strFirstFilter == "Enchantment")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardType like '%Enchantment%'");

                }
                else if (cbxEnchantment.Checked == true && strFirstFilter != "Enchantment")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " or CardType like '%Enchantment%'");
                }
                else if (cbxEnchantment.Checked == false && strFirstFilter != "Enchantment")
                {

                    if (strQuery.Contains(" or CardType like '%Enchantment%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Enchantment") - 20, 33);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardType like '%Enchantment%' or"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Enchantment") - 22, 38);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
            else
            {
                if (cbxEnchantment.Checked == true && strFirstFilter == "Enchantment")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardType like '%Enchantment%'");

                }
                else if (cbxEnchantment.Checked == true && strFirstFilter != "Enchantment")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " and CardType like '%Enchantment%'");
                }
                else if (cbxEnchantment.Checked == false && strFirstFilter != "Enchantment")
                {

                    if (strQuery.Contains(" and CardType like '%Enchantment%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Enchantment") - 21, 34);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardType like '%Enchantment%' and"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Enchantment") - 22, 39);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
        }


        //*****************************LAND FILTER
        private void cbxLand_CheckedChanged(object sender, EventArgs e)
        {
            CheckFirstFilter();

            if (rbnExclusive.Checked == true)
            {
                if (cbxLand.Checked == true && strFirstFilter == "Land")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardType like '%Land%'");

                }
                else if (cbxLand.Checked == true && strFirstFilter != "Land")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " or CardType like '%Land%'");
                }
                else if (cbxLand.Checked == false && strFirstFilter != "Land")
                {
                    if (strQuery.Contains(" or CardType like '%Land%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Land") - 20, 26);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardType like '%Land%' or"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Land") - 22, 31);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
            else
            {
                if (cbxLand.Checked == true && strFirstFilter == "Land")
                {
                    strQuery = strDefaultQuery;
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " where CardType like '%Land%'");

                }
                else if (cbxLand.Checked == true && strFirstFilter != "Land")
                {
                    ProgOps.DatabaseCommandProd(dgvCards, strQuery += " and CardType like '%Land%'");
                }
                else if (cbxLand.Checked == false && strFirstFilter != "Land")
                {
                    if (strQuery.Contains(" and CardType like '%Land%'"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Land") - 21, 27);
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                    else if (strQuery.Contains("where CardType like '%Land%' and"))
                    {
                        strQuery = strQuery.Remove(strQuery.LastIndexOf("Land") - 22, 32);
                        strQuery = strQuery.Insert(strDefaultQuery.Count(), " where ");
                        ProgOps.DatabaseCommandProd(dgvCards, strQuery);
                    }
                }
            }
        }

        
        private void rbnExclusive_CheckedChanged(object sender, EventArgs e)
        {//changes to an exlusive search (it can have one or the other)
            rbnInclusive.Checked = false;
        }

        private void rbnInclusive_CheckedChanged(object sender, EventArgs e)
        { //changes to an inclusive search(both attributes must be present)
            rbnExclusive.Checked = false;
        }

        //**************************CARD SELECTION
        private void dgvCards_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {//This opens up the frmCard with the data of the selected item
            int cardIndex;

            cardIndex = e.RowIndex;

            frmCardView card = new frmCardView(this);

            int intRowIndex = dgvCards.CurrentRow.Index;

            string SelectedCard = dgvCards.CurrentRow.Cells[0].Value.ToString().Replace("'", "''");

            ProgOps.DatabaseCommandCardView(card.lblCardName, card.lblCost, card.lblType, card.lblDesc, card.pbxCardSlot, SelectedCard, card.lblCardPrice, card.lblOnSale, card.lblPercentOff, card.lblAmountInStock);

            card.Show();

            ProgOps.lstImageHolder.Clear();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {//Calls the clear filter function for the dgvCards
            ClearSearch();
        }

       void ClearSearch()
       {//the clear filter function for the dgvCards

            cbxArtifact.Checked = false;
            cbxBlack.Checked = false;
            cbxBlue.Checked = false;
            cbxCreature.Checked = false;
            cbxEnchantment.Checked = false;
            cbxGreen.Checked = false;
            cbxInstant.Checked = false;
            cbxLand.Checked = false;
            cbxRed.Checked = false;
            cbxSorcery.Checked = false;
            cbxWhite.Checked = false;

            strQuery = strDefaultQuery;
            ProgOps.DatabaseCommandProd(dgvCards, strQuery);
            strFirstFilter = "";
       }


        private void btnCheckout_Click(object sender, EventArgs e)
        {//Send all items to checkout and tally up the total

            if (strCart.Count == 0)
            {
                MessageBox.Show("Sorry, it looks like you don't have any items in your cart! Add some goodies and feel free to come check out here!", "Empty Cart", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            frmCheckout checkout = new frmCheckout(this);
            int Count = 0;
            try
            {
                for (int i = 0; i < strCart.Count; i++)
                {
                    if (strDupe.Contains(strCart[i]))
                    {
                        intCardCount[strDupe.IndexOf(strCart[i])]++;
                    }
                    if (!strDupe.Contains(strCart[i]))
                    {
                        intCardCount.Add(Count + 1);
                        strDupe.Add(strCart[i]);
                        dblCardPrices.Add(dblPrice[i]);
                    }
                }

                for (int i = 0; i < strDupe.Count; i++)
                { 
                    dblCardPrices[i] = dblPrice[strCart.IndexOf(strDupe[i])] * intCardCount[i];
                }

                for (int i = 0; i < strDupe.Count(); i++)
                {
                    checkout.lbxCart.Items.Add(intCardCount[i].ToString() + " " + strDupe[i] + " $" + dblCardPrices[i].ToString("0.##"));
                }


                checkout.Show();


            }
            catch (Exception)
            {
                MessageBox.Show("There has been an error processing the items in your cart, so your cart had to be emptied \nWe apologize for the inconvenience", "Error Processing Cart", MessageBoxButtons.OK, MessageBoxIcon.Error);
                strCart.Clear();
                dblCardPrices.Clear();
                dblPrice.Clear();
                strDupe.Clear();
            }
        }

        private void mnuAlterInformation_Click(object sender, EventArgs e)
        {//Allows for an employee to alter their information
            frmUpdateEmployee Update = new frmUpdateEmployee(this);
            Update.Show();
        }

        private void mnuFilterHelp_Click(object sender, EventArgs e)
        {
            HtmlReports.PrintFilterHelp(HtmlReports.FilterHelp());
        }

        private void mnuCardCostHelp_Click(object sender, EventArgs e)
        {
            HtmlReports.PrintCardCostHelp(HtmlReports.CardCostHelp());
        }

        private void mnuAddItemHelp_Click(object sender, EventArgs e)
        {
            HtmlReports.PrintAddCartHelp(HtmlReports.AddCartHelp());
        }

        private void mnuViewDetailsHelp_Click(object sender, EventArgs e)
        {

            HtmlReports.PrintAccessDetailHelp(HtmlReports.AccessDetailHelp());
        }

        private void whatDoesOnSaleMeanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HtmlReports.PrintSalesHelp(HtmlReports.SalesHelp());
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            //ProgOps.CloseDatabaseDispose();
        }

        void CheckFirstFilter()
        {//helps set filter values for the cbx checked events

            if (cbxBlack.Checked == true && cbxBlue.Checked == false && cbxCreature.Checked == false && cbxEnchantment.Checked == false && cbxGreen.Checked == false
                   && cbxInstant.Checked == false && cbxLand.Checked == false && cbxRed.Checked == false && cbxSorcery.Checked == false && cbxWhite.Checked == false && cbxArtifact.Checked == false)
            {
                blnFiltered = true;
                strFirstFilter = "Black";

            } else if (cbxBlack.Checked == false && cbxBlue.Checked == true && cbxCreature.Checked == false && cbxEnchantment.Checked == false && cbxGreen.Checked == false
                    && cbxInstant.Checked == false && cbxLand.Checked == false && cbxRed.Checked == false && cbxSorcery.Checked == false && cbxWhite.Checked == false && cbxArtifact.Checked == false)
            {
                blnFiltered = true;
                strFirstFilter = "Blue";
            }
            else if (cbxBlack.Checked == false && cbxBlue.Checked == false && cbxCreature.Checked == true && cbxEnchantment.Checked == false && cbxGreen.Checked == false
                  && cbxInstant.Checked == false && cbxLand.Checked == false && cbxRed.Checked == false && cbxSorcery.Checked == false && cbxWhite.Checked == false && cbxArtifact.Checked == false)
            {
                blnFiltered = true;
                strFirstFilter = "Creature";
            }
            else if (cbxBlack.Checked == false && cbxBlue.Checked == false && cbxCreature.Checked == false && cbxEnchantment.Checked == true && cbxGreen.Checked == false
                  && cbxInstant.Checked == false && cbxLand.Checked == false && cbxRed.Checked == false && cbxSorcery.Checked == false && cbxWhite.Checked == false && cbxArtifact.Checked == false)
            {
                blnFiltered = true;
                strFirstFilter = "Enchantment";
            }
            else if (cbxBlack.Checked == false && cbxBlue.Checked == false && cbxCreature.Checked == false && cbxEnchantment.Checked == false && cbxGreen.Checked == false
               && cbxInstant.Checked == false && cbxLand.Checked == false && cbxRed.Checked == false && cbxSorcery.Checked == false && cbxWhite.Checked == false && cbxArtifact.Checked == true)
            {
                blnFiltered = true;
                strFirstFilter = "Artifact";
            }
            else if (cbxBlack.Checked == false && cbxBlue.Checked == false && cbxCreature.Checked == false && cbxEnchantment.Checked == false && cbxGreen.Checked == true
                  && cbxInstant.Checked == false && cbxLand.Checked == false && cbxRed.Checked == false && cbxSorcery.Checked == false && cbxWhite.Checked == false && cbxArtifact.Checked == false)
            {
                blnFiltered = true;
                strFirstFilter = "Green";
            }
            else if (cbxBlack.Checked == false && cbxBlue.Checked == false && cbxCreature.Checked == false && cbxEnchantment.Checked == false && cbxGreen.Checked == false
                  && cbxInstant.Checked == true && cbxLand.Checked == false && cbxRed.Checked == false && cbxSorcery.Checked == false && cbxWhite.Checked == false && cbxArtifact.Checked == false)
            {
                blnFiltered = true;
                strFirstFilter = "Instant";
            }
            else if (cbxBlack.Checked == false && cbxBlue.Checked == false && cbxCreature.Checked == false && cbxEnchantment.Checked == false && cbxGreen.Checked == false
                  && cbxInstant.Checked == false && cbxLand.Checked == true && cbxRed.Checked == false && cbxSorcery.Checked == false && cbxWhite.Checked == false && cbxArtifact.Checked == false)
            {
                blnFiltered = true;
                strFirstFilter = "Land";
            }
            else if (cbxBlack.Checked == false && cbxBlue.Checked == false && cbxCreature.Checked == false && cbxEnchantment.Checked == false && cbxGreen.Checked == false
                  && cbxInstant.Checked == false && cbxLand.Checked == false && cbxRed.Checked == true && cbxSorcery.Checked == false && cbxWhite.Checked == false && cbxArtifact.Checked == false)
            {
                blnFiltered = true;
                strFirstFilter = "Red";
            }
            else if (cbxBlack.Checked == false && cbxBlue.Checked == false && cbxCreature.Checked == false && cbxEnchantment.Checked == false && cbxGreen.Checked == false
                  && cbxInstant.Checked == false && cbxLand.Checked == false && cbxRed.Checked == false && cbxSorcery.Checked == true && cbxWhite.Checked == false && cbxArtifact.Checked == false)
            {
                blnFiltered = true;
                strFirstFilter = "Sorcery";
            }
            else if (cbxBlack.Checked == false && cbxBlue.Checked == false && cbxCreature.Checked == false && cbxEnchantment.Checked == false && cbxGreen.Checked == false
                  && cbxInstant.Checked == false && cbxLand.Checked == false && cbxRed.Checked == false && cbxSorcery.Checked == false && cbxWhite.Checked == true && cbxArtifact.Checked == false)
            {
                blnFiltered = true;
                strFirstFilter = "White";
            }
            else if (cbxBlack.Checked == false && cbxBlue.Checked == false && cbxCreature.Checked == false && cbxEnchantment.Checked == false && cbxGreen.Checked == false
                    && cbxInstant.Checked == false && cbxLand.Checked == false && cbxRed.Checked == false && cbxSorcery.Checked == false && cbxWhite.Checked == false && cbxArtifact.Checked == false)
            {
                blnFiltered = false;
                strFirstFilter = "";
                ProgOps.DatabaseCommandProd(dgvCards, strQuery = strDefaultQuery);
            }
            if(strFirstFilter == "")
            {
                btnClear.Enabled = false;
            }
            else
            {
                btnClear.Enabled = true;
            }
        }

        public void AddToCart(string CardName, double CardPrice, int MaxPurchasable)
        {//Adds items to cart using information from frmCardView
            int itemCount = 0;
            try
            {
                for (int i = 0; i < strCart.Count; i++)
                {
                    if (strCart[i] == CardName)
                    {
                        itemCount++;
                        if (itemCount >= intMaximumPurchasable[strCart.IndexOf(CardName)])
                        {
                            MessageBox.Show("We Don't have any more of this item! Please select something else!", "Cannot add item", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                    }

                }

                strCart.Add(CardName);
                dblPrice.Add(CardPrice);
                intMaximumPurchasable.Add(MaxPurchasable);

                MessageBox.Show("1 copy of " + CardName + " added to your cart!");
            }catch(Exception)
            {
                MessageBox.Show("There has been an error adding this item to your cart, please try another", "Cannot add item", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
   
}
