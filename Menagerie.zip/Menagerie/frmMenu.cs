﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SP21_Final_Project
{
    public partial class frmMenu : Form
    {
        frmMain main;
        public frmMenu(frmMain frmMain)
        {
            main = frmMain;
            InitializeComponent();
        }

        private void btnAdjustSchedules_Click(object sender, EventArgs e)
        {//open schedule adjustments
            frmSchAdjust Adjust = new frmSchAdjust();
            Adjust.Show();
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {//open inventory
            frmInventory inventory = new frmInventory();
            inventory.Show();
        }

        private void btnAdjustEmp_Click(object sender, EventArgs e)
        {//open up employee adjustments
            frmEmployees Employees = new frmEmployees();
            Employees.Show();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnViewSchedules_Click(object sender, EventArgs e)
        {
            frmSchedule schedule = new frmSchedule(main, "Alter");
            schedule.Show();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            frmReports reports = new frmReports();
            reports.Show();
        }

        private void frmMenu_FormClosing(object sender, FormClosingEventArgs e)
        {

            ProgOps.DatabaseCommandProd(main.dgvCards, main.strQuery);
        }
    }
}
