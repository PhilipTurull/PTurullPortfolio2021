﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SP21_Final_Project
{
    public partial class frmOrders : Form
    {
        frmMain mainScreen;
        public frmOrders(frmMain MainScreen)
        {
            InitializeComponent();
            mainScreen = MainScreen;
        }

        private void frmOrders_Load(object sender, EventArgs e)
        {
            if(mainScreen.intSecurityLevel>1)
            {
                ProgOps.DatabaseCommandOrd("", dgvOrders);
            }
            else
            {
                ProgOps.DatabaseCommandOrd($"and CustomerUsername = '{mainScreen.strUsername}' ", dgvOrders);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try 
            {             
                HtmlReports.PrintOrder(HtmlReports.GenerateOrder(ProgOps._sqlOrdersCommand));
            }
            catch (Exception)
            {
                MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
