﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SP21_Final_Project
{
    public partial class frmRecover : Form
    {

        //string strRecoverQ1 = "What's your mother's maiden name?", strRecoverQ2 = "What was the city you were born in?", strRecoverQ3 = "What was your first pet's name?";
        
        string strUsername;

        string strInsertedTable;

        public frmRecover(string Username, string CustOrEmp)
        {
            InitializeComponent();
            strUsername = Username;

            if(CustOrEmp == "Cust")
            {
                strInsertedTable = "Customers";
            }
            else if(CustOrEmp == "Emp")
            {
                strInsertedTable = "Employees";
            } 
            lblQuestion.Text = ProgOps.LoadRecoveryQuestions(strInsertedTable, strUsername);
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnValidate_Click(object sender, EventArgs e)
        { 
            bool blnValidated = ProgOps.ValidateRecovery(strInsertedTable, strUsername.Replace("'", "''"), tbxResponse);

            if(blnValidated == true)
            {
                this.Height = 300;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var varHasNumber = new Regex(@"[0-9]+");
            var varHasUpperChar = new Regex(@"[A-Z]+");
            var varHasMinimum8Chars = new Regex(@".{8,}");

            var blnIsValidated = varHasNumber.IsMatch(tbxPassword.Text) && varHasUpperChar.IsMatch(tbxPassword.Text) && varHasMinimum8Chars.IsMatch(tbxPassword.Text);



            if (tbxPassword.Text != "" && tbxPassword.Text == tbxReinput.Text && blnIsValidated == true)
            {
                ProgOps.DatabaseCommandSavePassword(strInsertedTable, strUsername, tbxPassword);
                MessageBox.Show("Your password has been reset! Don't forget it again now!!", "Password Chaanged", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("Double check your information! your password must be 8 characters or longer, and must contain an upper and lower case character!(as well as a number!)", "Password Requirements", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }
    }
}
