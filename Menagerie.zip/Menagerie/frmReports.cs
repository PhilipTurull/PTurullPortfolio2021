﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SP21_Final_Project
{
    public partial class frmReports : Form
    {
        public frmReports()
        {
            InitializeComponent();
        }

        private void btnDaily_Click(object sender, EventArgs e)
        {
            try { 
            ProgOps.DatabaseCommandLoadDailySales();
            HtmlReports.PrintDailySales(HtmlReports.GenerateDailySales(ProgOps._sqlDailySales));
            }
            catch (Exception)
            {
                MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnWeekly_Click(object sender, EventArgs e)
        {
            try { 
            ProgOps.DatabaseCommandLoadWeeklySales();
            HtmlReports.PrintWeeklySales(HtmlReports.GenerateWeeklySales(ProgOps._sqlWeeklySales));
            }
            catch (Exception)
            {
                MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnMonthly_Click(object sender, EventArgs e)
        {
            try { 
            ProgOps.DatabaseCommandLoadMonthlySales();
            HtmlReports.PrintMonthlySales(HtmlReports.GenerateMonthlySales(ProgOps._sqlMonthlySales));
            }
            catch (Exception)
            {
                MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
