﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SP21_Final_Project
{
    public partial class frmSchAdjust : Form
    {
        public frmSchAdjust()
        {
            InitializeComponent();
        }

        private void frmSchAdjust_Load(object sender, EventArgs e)
        {
            ProgOps.DatabaseCommandFillSwap(dgvScheduleSwap);
        }

        private void dgvScheduleSwap_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int intRowIndex = dgvScheduleSwap.CurrentRow.Index;

            DialogResult dlgResult;


            string strSelectedEmployee = dgvScheduleSwap.CurrentRow.Cells[0].Value.ToString();
            string SelectedSuggestion = dgvScheduleSwap.CurrentRow.Cells[4].Value.ToString();

            dlgResult = MessageBox.Show($"Do you wish to approve this Shift Swap?\nReason for change: {SelectedSuggestion}", $"Accept or Deny { strSelectedEmployee}'s shift swap?", MessageBoxButtons.YesNo);

            if (dlgResult == System.Windows.Forms.DialogResult.Yes)
            {
                ProgOps.DatabaseCommandCommitSwap(dgvScheduleSwap.CurrentRow.Cells[1].Value.ToString(), dgvScheduleSwap.CurrentRow.Cells[3].Value.ToString(), dgvScheduleSwap.CurrentRow.Cells[0].Value.ToString());
            }
            else
            {
                ProgOps.DatabaseCommandRemoveSwap(dgvScheduleSwap.CurrentRow.Cells[0].Value.ToString(), dgvScheduleSwap.CurrentRow.Cells[1].Value.ToString());
            }
            ProgOps.DatabaseCommandFillSwap(dgvScheduleSwap);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
