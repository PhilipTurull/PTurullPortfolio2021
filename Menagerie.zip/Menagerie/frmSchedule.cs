﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SP21_Final_Project
{
    public partial class frmSchedule : Form
    {
        frmMain mainScreen;
        string strAllorOwn;
        public frmSchedule(frmMain MainScreen, string strAlterOrOwn)
        {//loads in the proper schedule(s)
            InitializeComponent();
            mainScreen = MainScreen;

            strAllorOwn = strAlterOrOwn;

            if(strAlterOrOwn == "Own")
            {
                ProgOps.DatabaseCommandSch($" and username like '{mainScreen.strUsername}' ", dgvSchedules);
            }
            else if (strAlterOrOwn == "Alter")
            {
                ProgOps.DatabaseCommandSch("", dgvSchedules);
                dgvSchedules.ReadOnly = false;
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSwap_Click(object sender, EventArgs e)
        {//ask for a swap in the weekly schedule
            frmAskSwap Ask = new frmAskSwap(mainScreen.strUsername);
            Ask.Show();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (strAllorOwn == "Own")
                try { 
                    HtmlReports.PrintSchedule(HtmlReports.GenerateSchedule(ProgOps._sqlEmployeeScheduleCommand));
                }
                catch (Exception)
                {
                    MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            else
                try { 
                HtmlReports.PrintSchedules(HtmlReports.GenerateAllSchedules(ProgOps._sqlEmployeeScheduleCommand));
                }
                catch (Exception)
                {
                    MessageBox.Show("There has been an error generating the report", "Error with the Report", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
        }

        private void frmSchedule_Load(object sender, EventArgs e)
        {
           if(strAllorOwn != "Own")
            {
                btnSwap.Hide();
            }
        }
    }
}
