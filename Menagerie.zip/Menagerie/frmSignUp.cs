﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SP21_Final_Project
{
    public partial class frmSignUp : Form
    {
        frmMain MainScreen;
        public frmSignUp(frmMain main)
        {
            MainScreen = main;
            InitializeComponent();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {//Signs up a customer for use in the rest of the program

            var varHasNumber = new Regex(@"[0-9]+");
            var varHasUpperChar = new Regex(@"[A-Z]+");
            var varHasMinimum8Chars = new Regex(@".{8,}");

            var blnIsValidated = varHasNumber.IsMatch(tbxPassword.Text) && varHasUpperChar.IsMatch(tbxPassword.Text) && varHasMinimum8Chars.IsMatch(tbxPassword.Text);



            if (tbxPassword.Text != "" && tbxPassword.Text == tbxReinput.Text && blnIsValidated == true)
            {
                ProgOps.DatabaseCommandCommitInsert(tbxName.Text.Replace("'","''"),tbxUsername.Text.Replace("'", "''"), tbxPassword.Text.Replace("'", "''"), tbxQuestion.Text.Replace("'", "''"), tbxResponse.Text.Replace("'", "''"), MainScreen);
                MessageBox.Show("You are now in our system! Log in and build your deck!");
                this.Close();
            }
            else
            {
                MessageBox.Show("Double check your information! your password must be 8 characters or longer, and must contain an upper and lower case character!(as well as a number!)", "Password Requirements", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
