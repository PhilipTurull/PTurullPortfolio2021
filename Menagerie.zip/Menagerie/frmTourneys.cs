﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SP21_Final_Project
{
    public partial class frmTourneys : Form
    {
        frmMain MainScreen;
        public frmTourneys(frmMain main)
        {
            InitializeComponent();

            MainScreen = main;
        }

        private void frmTourneys_Load(object sender, EventArgs e)
        {
            ProgOps.DatabaseCommandTourney(dgvTourney);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

            //frmNewTourney newTourney = new frmNewTourney();
            //newTourney.Show();
        
    }
}
