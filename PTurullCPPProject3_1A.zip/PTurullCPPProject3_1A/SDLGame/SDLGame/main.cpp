#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#include <SDL_ttf.h>

#include <stdio.h>
#include <iostream>
#include <string>
#include<vector>

#include "enemy.h"

#include "Bullet.h"

vector<Enemy> enemyList;

vector<Bullet> bulletList;

Mix_Chunk* lazer;
Mix_Chunk* explosion;
Mix_Music* bgMusic;

using namespace std;

bool quit = false;

float deltaTime = 0.0;
int thisTime = 0, lastTime = 0;

float pos_X, pos_Y;

int playerScore, oldScore, playerLives, oldLives;

TTF_Font* font;

SDL_Color colorP1 = { 225, 0, 225, 255 };

SDL_Surface* scoreSurface, * livesSurface;

SDL_Texture* scoreTexture, * livesTexture;

SDL_Rect playerPos, scorePos, livesPos;

string tempScore, tempLives;

void UpdateScore(SDL_Renderer* renderer)
{

	tempScore = "Player Score: " + std::to_string(playerScore);

	scoreSurface = TTF_RenderText_Solid(font, tempScore.c_str(), colorP1);

	scoreTexture = SDL_CreateTextureFromSurface(renderer, scoreSurface);

	SDL_QueryTexture(scoreTexture, NULL, NULL, &scorePos.w, &scorePos.h);

	SDL_FreeSurface(scoreSurface);

	oldScore = playerScore;
}

void UpdateLives(SDL_Renderer* renderer)
{

	tempLives = "Player Score: " + std::to_string(playerLives);

	livesSurface = TTF_RenderText_Solid(font, tempLives.c_str(), colorP1);

	livesTexture = SDL_CreateTextureFromSurface(renderer, livesSurface);

	SDL_QueryTexture(livesTexture, NULL, NULL, &livesPos.w, &livesPos.h);

	SDL_FreeSurface(livesSurface);

	oldLives = playerLives;
}

void CreateBullet()
{
	for (int i = 0; i < bulletList.size(); i++)
	{
		if (bulletList[i].active == false)
		{
			Mix_PlayChannel(-1, lazer, 0);

			bulletList[i].active = true;

			bulletList[i].posRect.y = (pos_Y + (playerPos.h / 2));

			bulletList[i].posRect.x = playerPos.x + playerPos.w;

			bulletList[i].posRect.x = (bulletList[i].posRect.x + (bulletList[i].posRect.w / 2));

			bulletList[i].posRect.y = playerPos.y + (playerPos.h/2);

			bulletList[i].pos_X = bulletList[i].posRect.x;

			bulletList[i].pos_Y = bulletList[i].posRect.y;

			break;
		}

	}
}



int main(int argc, char* argv[])
{
	SDL_Window* window;

	SDL_Renderer* renderer = NULL;

	SDL_Init(SDL_INIT_EVERYTHING);

	window = SDL_CreateWindow(
		"Space Game",					//window title
		SDL_WINDOWPOS_UNDEFINED,		//initial x
		SDL_WINDOWPOS_UNDEFINED,		//initial y
		1024,							//x size
		768,							//ysize
		SDL_WINDOW_OPENGL
	);

	//error code to see if creation failed
	if (window == NULL)
	{
		printf("Could not create window: %s\n", SDL_GetError());
		return 0;
	}

	//create renderer
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

	//bgimage
	SDL_Surface* surface = IMG_Load("./Assets/BG2.PNG");

	SDL_Texture* bg;

	bg = SDL_CreateTextureFromSurface(renderer, surface);

	SDL_FreeSurface(surface);

	SDL_Rect bgPos;

	bgPos.x = 0;
	bgPos.y = 0;
	bgPos.w = 1024;
	bgPos.h = 768;

	//player image
	surface = IMG_Load("./Assets/Player.PNG");

	SDL_Texture* player;

	player = SDL_CreateTextureFromSurface(renderer, surface);

	SDL_FreeSurface(surface);


	playerPos.x = 50;
	playerPos.y = 80;
	playerPos.w = 72;
	playerPos.h = 79;

	float playerSpeed = 500.0f;

	float yDir;

	enum GameState {GAME, WIN, LOSE };

	GameState gameState = GAME;

	bool game, win, lose;

	SDL_Event event;

	enemyList.clear();

	for (int i = 0; i < 8; i++)
	{
		Enemy tempEnemy(renderer);

		enemyList.push_back(tempEnemy);
	}

	for (int i = 0; i < 10; i++)
	{
		Bullet tempBullet(renderer, playerPos.x + playerPos.w, playerPos.y + (playerPos.h/2));

		bulletList.push_back(tempBullet);
	}

	Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);

	lazer = Mix_LoadWAV("./Assets/lazer.wav");
	explosion = Mix_LoadWAV("./Assets/Explosion.wav");

	bgMusic = Mix_LoadMUS("./Assets/bgMusic.wav");

	if (!Mix_PlayingMusic())
	{
		Mix_PlayMusic(bgMusic, -1);
	}


	playerLives = 3;
	oldLives = 0;


	playerScore = 0;
	oldScore = 0;

	TTF_Init();
	font = TTF_OpenFont("./Assets/type.ttf", 20);

	scorePos.x = scorePos.y = 10;
	UpdateScore(renderer);
	livesPos.x = 10;
	livesPos.y = 40;
	UpdateLives(renderer);


	while (!quit)
	{
		switch (gameState)
		{
		case GAME:
		{
			game = true;

			cout << "The game state is GAME" << endl;

			surface = IMG_Load("./Assets/BG2.PNG");
			bg = SDL_CreateTextureFromSurface(renderer, surface);
			SDL_FreeSurface(surface);

			enemyList.clear();

			for (int i = 0; i < 8; i++)
			{
				Enemy tempEnemy(renderer);

				enemyList.push_back(tempEnemy);
			}

			playerLives = 3;
			oldLives = 0;


			playerScore = 0;
			oldScore = 0;



			while (game)
			{
				thisTime = SDL_GetTicks();
				deltaTime = (float)(thisTime - lastTime) / 1000;
				lastTime = thisTime;

				if (SDL_PollEvent(&event))
				{
					if (event.type == SDL_QUIT)
					{
						quit = true;
						game = false;
						break;
					}

					switch (event.type)
					{

					case SDL_KEYUP:
						switch (event.key.keysym.sym)
						{
						case SDLK_SPACE:
							CreateBullet();
							break;
						default:
							break;
						}

					}

				}

				const Uint8* currentKeyStatus = SDL_GetKeyboardState(NULL);

				if (currentKeyStatus[SDL_SCANCODE_UP])
				{
					yDir = -1;
				}
				else if (currentKeyStatus[SDL_SCANCODE_DOWN])
				{
					yDir = 1;
				}
				else
				{
					yDir = 0;
				}


				pos_Y += (playerSpeed * yDir) * deltaTime;

				playerPos.y = (int)(pos_Y + 0.5f);

				if (playerPos.y < 0)
				{
					playerPos.y = 0;
					pos_Y = 0;
				}

				if (playerPos.y > 768 - playerPos.h)
				{
					playerPos.y = 768 - playerPos.h;
					pos_Y = 768 - playerPos.h;
				}

				for (int i = 0; i < 8; i++)
				{
					enemyList[i].Update(deltaTime);
				}

				for (int i = 0; i < bulletList.size(); i++)
				{
					if (bulletList[i].active == true)
					{
						bulletList[i].Update(deltaTime);
					}
				}

				for (int i = 0; i < enemyList.size(); i++)
				{
					if (SDL_HasIntersection(&playerPos, &enemyList[i].posRect))
					{
						Mix_PlayChannel(-1, explosion, 0);
						playerLives--;
						enemyList[i].Reset();
						if (playerLives <= 0)
						{
							game = false;
							gameState = LOSE;
						}
					}
				}

				for (int i = 0; i < bulletList.size(); i++)
				{
					if (bulletList[i].active == true)
					{
						for (int j = 0; j < enemyList.size(); j++)
						{


							if (SDL_HasIntersection(&bulletList[i].posRect, &enemyList[j].posRect))
							{
								enemyList[j].Reset();
								bulletList[i].Reset();
								playerScore += 10;

								if (playerScore >= 500)
								{
									game = false;
									gameState = WIN;
								}

								Mix_PlayChannel(-1, explosion, 0);
							}
						}
					}
				}


				if (playerScore != oldScore)
				{
					UpdateScore(renderer);
				}

				if (playerLives != oldLives)
				{
					UpdateLives(renderer);
				}

				//draw
				SDL_RenderClear(renderer);

				SDL_RenderCopy(renderer, bg, NULL, &bgPos);


				SDL_RenderCopy(renderer, player, NULL, &playerPos);

				for (int i = 0; i < 8; i++)
				{
					enemyList[i].Draw(renderer);
				}

				for (int i = 0; i < bulletList.size(); i++)
				{
					if (bulletList[i].active == true)
					{
						bulletList[i].Draw(renderer);
					}
				}

				SDL_RenderCopy(renderer, scoreTexture, NULL, &scorePos);
				SDL_RenderCopy(renderer, livesTexture, NULL, &livesPos);

				SDL_RenderPresent(renderer);

			}
		}
			break;

			case LOSE:
				lose = true;

				cout << "The game state is LOSE" << endl
					<< "Press the R key to play the game" << endl
					<< "Press the Q key to quit the game" << endl;

				surface = IMG_Load("./Assets/LoseScreen.PNG");
				bg = SDL_CreateTextureFromSurface(renderer, surface);

				SDL_FreeSurface(surface);


				while (lose)
				{
					thisTime = SDL_GetTicks();
					deltaTime = (float)(thisTime - lastTime) / 1000;
					lastTime = thisTime;

					if (SDL_PollEvent(&event))
					{

						if (event.type == SDL_QUIT)
						{
							quit = true;
							lose = false;
							break;
						}

						switch (event.type)
						{
						case SDL_KEYUP:
							switch (event.key.keysym.sym)
							{
							case SDLK_r:
								lose = false;
								gameState = GAME;
								break;

							case SDLK_q:
								lose = false;
								quit = true;
								break;

							default:
								break;
							}
						}
					}

					SDL_RenderClear(renderer);

					SDL_RenderCopy(renderer, bg, NULL, &bgPos);

					SDL_RenderPresent(renderer);
				}

				break;

			case WIN:
				win = true;

				cout << "The game state is WIN" << endl
					<< "Press the R key to play the game" << endl
					<< "Press the Q key to quit the game" << endl;

				surface = IMG_Load("./Assets/WinScreen.PNG");
				bg = SDL_CreateTextureFromSurface(renderer, surface);

				SDL_FreeSurface(surface);


				while (win)
				{
					thisTime = SDL_GetTicks();
					deltaTime = (float)(thisTime - lastTime) / 1000;
					lastTime = thisTime;

					if (SDL_PollEvent(&event))
					{

						if (event.type == SDL_QUIT)
						{
							quit = true;
							win = false;
							break;
						}

						switch (event.type)
						{
						case SDL_KEYUP:
							switch (event.key.keysym.sym)
							{
							case SDLK_r:
								win = false;
								gameState = GAME;
								break;

							case SDLK_q:
								win = false;
								quit = true;
								break;

							default:
								break;
							}
						}
					}

					SDL_RenderClear(renderer);

					SDL_RenderCopy(renderer, bg, NULL, &bgPos);

					SDL_RenderPresent(renderer);
				}

				break;
		}

	}

	SDL_DestroyWindow(window);
	SDL_Quit();

	return 0;
}