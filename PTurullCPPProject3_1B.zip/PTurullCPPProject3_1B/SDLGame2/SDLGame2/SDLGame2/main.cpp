#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>

#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <time.h>

using namespace std;

#include "Bullet.h"
#include "largeRock.h"
#include "smallRock.h"

Mix_Chunk* lazer;
Mix_Chunk* explosion;
Mix_Music* bgMusic;

using namespace std;

bool quit = false;

float deltaTime;
int thisTime = 0, lastTime = 0;

float x, y, playerAngle, oldAngle;

float xDir, yDir, xDirOld, yDirOld;

float playerSpeed = 400.0f;

float pos_X, pos_Y;

int playerScore, oldScore, playerLives, oldLives;

TTF_Font* font;

SDL_Color colorP1 = { 225, 0, 225, 255 };

SDL_Surface* scoreSurface, * livesSurface;

SDL_Texture* scoreTexture, * livesTexture;

SDL_Rect playerPos, scorePos, livesPos;

string tempScore, tempLives;

SDL_Point center;

vector<Bullet> bulletList;

vector<LargeRock> lRockList;
vector<SmallRock> sRockList;

void CreateBullet()
{
	for (int i = 0; i < bulletList.size(); i++)
	{
		if (bulletList[i].active == false)
		{
			Mix_PlayChannel(-1, lazer, 0);

			bulletList[i].active = true;

			bulletList[i].posRect.x = pos_X;

			bulletList[i].posRect.y = pos_Y;

			bulletList[i].pos_X = pos_X;

			bulletList[i].pos_Y = pos_Y;

			bulletList[i].xDir = xDirOld;

			bulletList[i].yDir = yDirOld;

			bulletList[i].Reposition();

			break;
		}

	}
}

int main(int argc, char* argv[])
{
	srand(time(NULL));

	SDL_Window* window;

	SDL_Renderer* renderer = NULL;

	SDL_Init(SDL_INIT_EVERYTHING);

	window = SDL_CreateWindow(
		"Space Rocks",					//window title
		SDL_WINDOWPOS_UNDEFINED,		//initial x
		SDL_WINDOWPOS_UNDEFINED,		//initial y
		1024,							//x size
		768,							//ysize
		SDL_WINDOW_OPENGL
	);

	//error code to see if creation failed
	if (window == NULL)
	{
		printf("Could not create window: %s\n", SDL_GetError());
		return 0;
	}

	//create renderer
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

	//bgimage
	SDL_Surface* surface = IMG_Load("./Assets/BG1.PNG");

	SDL_Texture* bg;

	bg = SDL_CreateTextureFromSurface(renderer, surface);

	SDL_FreeSurface(surface);

	SDL_Rect bgPos;

	bgPos.x = 0;
	bgPos.y = 0;
	bgPos.w = 1024;
	bgPos.h = 768;

	//player image
	surface = IMG_Load("./Assets/Player.PNG");

	SDL_Texture* player;

	player = SDL_CreateTextureFromSurface(renderer, surface);

	SDL_FreeSurface(surface);



	playerPos.x = 512;
	playerPos.y = 336;
	playerPos.w = 72;
	playerPos.h = 79;

	center.x = playerPos.w / 2;
	center.y = playerPos.h / 2;

	pos_X = playerPos.x;
	pos_Y = playerPos.y;

	xDir = 0;
	yDir = 1;

	xDirOld = 0;
	yDirOld = -1;

	playerAngle = 0;

	float playerSpeed = 500.0f;

	int numberOfLargeRocks = 1;
	int numberOfSmallRocks = 2;

	int numberOfRocks = numberOfLargeRocks + numberOfSmallRocks;

	int totalRocksDestroyed = 0;

	float yDir;

	enum GameState { GAME, WIN, LOSE };

	GameState gameState = GAME;

	bool game, win, lose;

	SDL_Event event;

	for (int i = 0; i < 10; i++)
	{
		Bullet tempBullet(renderer, -1000.0f, -1000.0f);

		bulletList.push_back(tempBullet);
	}

	for (int i = 0; i < numberOfLargeRocks; i++)
	{
		
		LargeRock tempRock(renderer, -1000.0f, -1000.0f);

		lRockList.push_back(tempRock);
	}

	for (int i = 0; i < numberOfSmallRocks; i++)
	{

		SmallRock tempRock(renderer, -1000.0f, -1000.0f);

		sRockList.push_back(tempRock);
	}

	Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);

	lazer = Mix_LoadWAV("./Assets/lazer.wav");
	explosion = Mix_LoadWAV("./Assets/Explosion.wav");

	bgMusic = Mix_LoadMUS("./Assets/bgMusic.wav");

	if (!Mix_PlayingMusic())
	{
		Mix_PlayMusic(bgMusic, -1);
	}
	
	for (int i = 0; i < numberOfLargeRocks; i++)
		{
			lRockList[i].Reposition();
		}

	playerScore = 0;

	cout << "You are on LEVEL " << numberOfLargeRocks <<endl;
	cout << "SCORE: " << playerScore << endl;

	while (!quit)
	{

		thisTime = SDL_GetTicks();
		deltaTime = (float)(thisTime - lastTime) / 1000;
		lastTime = thisTime;

		if (SDL_PollEvent(&event))
		{
			if (event.type == SDL_QUIT)
			{
				quit = true;
				game = false;
				break;
			}

			switch (event.type)
			{

			case SDL_KEYUP:
				switch (event.key.keysym.sym)
				{
				case SDLK_SPACE:
					CreateBullet();
					break;

				/*case SDLK_z:
					lRockList[0].Reposition();
					break;
				case SDLK_x:
					for (int i = 0; i < 2; i++)
					{
						sRockList[i].Reposition(lRockList[0].posRect.x, lRockList[0].posRect.y);
					}
					lRockList.clear();
					break;

				case SDLK_c:
					lRockList.clear();
					sRockList.clear();

					for (int i = 0; i < 3; i++)
					{

						LargeRock tempRock(renderer, -1000.0f, -1000.0f);

						lRockList.push_back(tempRock);
					}

					for (int i = 0; i < 2; i++)
					{

						SmallRock tempRock(renderer, -1000.0f, -1000.0f);

						sRockList.push_back(tempRock);
					}

					break; */
				default:
					break;
				}

			}

		}

		const Uint8* currentKeyStatus = SDL_GetKeyboardState(NULL);

		if (currentKeyStatus[SDL_SCANCODE_LEFT])
		{
			xDir = -1.0f;
		}
		else if (currentKeyStatus[SDL_SCANCODE_RIGHT])
		{
			xDir = 1.0f;
		}
		else
		{
			xDir = 0;
		}

		if (currentKeyStatus[SDL_SCANCODE_UP])
		{
			yDir = -1.0f;
		}
		else if (currentKeyStatus[SDL_SCANCODE_DOWN])
		{
			yDir = 1.0f;
		}
		else 
		{
			yDir = 0;
		}

		if (xDir != 0 || yDir != 0)
		{
			x = playerPos.x - xDir;
			y = playerPos.y - yDir;
			
			playerAngle = atan2(yDir, xDir) * 180 / 3.14;

			oldAngle = playerAngle;

			yDirOld = yDir;
			xDirOld = xDir;
		}
		else {
			oldAngle = playerAngle;
		}

		pos_Y += (playerSpeed * yDir) * deltaTime;

		playerPos.y = (int)(pos_Y + 0.5f);


		pos_X += (playerSpeed * xDir) * deltaTime;

		playerPos.x = (int)(pos_X + 0.5f);

		if (playerPos.x < 0 - playerPos.w)
		{
			playerPos.x = 1024;
			pos_X = playerPos.x;
		}
		if (playerPos.x > 1024)
		{
			playerPos.x = 0 - playerPos.w;
			pos_X = playerPos.x;
		}
		if (playerPos.y < 0 - playerPos.w)
		{
			playerPos.y = 768;
			pos_Y = playerPos.y;
		}
		if (playerPos.y > 768)
		{
			playerPos.y = (0 - playerPos.w);
			pos_Y = playerPos.y;
		}

		for (int i = 0; i < bulletList.size(); i++)
		{
			if (bulletList[i].active == true)
			{
				bulletList[i].Update(deltaTime);
			}
		}

		for (int i = 0; i < lRockList.size(); i++)
		{
			if (lRockList[i].active == true)
			{
				lRockList[i].Update(deltaTime);
			}
		}

		for (int i = 0; i < sRockList.size(); i++)
		{
			if (sRockList[i].active == true)
			{
				sRockList[i].Update(deltaTime);
			}
		}


		for (int i = 0; i < bulletList.size(); i++)
		{
			if (bulletList[i].active == true)
			{
				for (int j = 0; j < lRockList.size(); j++)
				{
					if (SDL_HasIntersection(&bulletList[i].posRect, &lRockList[j].posRect))
					{
						Mix_PlayChannel(-1, explosion, 0);

						int smallRockCounter = 0;

						for (int r = 0; r < sRockList.size(); r++)
						{
							if (sRockList[r].active == false)
							{
								sRockList[r].Reposition(lRockList[j].posRect.x, lRockList[j].posRect.y);
							
								smallRockCounter++;
							
							}

							if (smallRockCounter == 2)
							{
								break;
							}
						}
						lRockList[j].Deactivate();
						bulletList[i].Deactivate();

						playerScore += 50;

						cout << "SCORE: " << playerScore <<endl;


						totalRocksDestroyed++;
					}
				}
			}
		}

		for (int i = 0; i < bulletList.size(); i++)
		{
			if (bulletList[i].active == true)
			{
				for (int j = 0; j < sRockList.size(); j++)
				{
					if (SDL_HasIntersection(&bulletList[i].posRect, &sRockList[j].posRect))
					{
						Mix_PlayChannel(-1, explosion, 0);

						sRockList[j].Deactivate();
						bulletList[i].Deactivate();

						playerScore += 100;
						cout << "SCORE: " << playerScore << endl;

						totalRocksDestroyed++;

						if (totalRocksDestroyed >= numberOfRocks)
						{
							totalRocksDestroyed = 0;

							numberOfLargeRocks++;
							numberOfSmallRocks += 2;

							numberOfRocks = numberOfLargeRocks + numberOfSmallRocks;

							lRockList.clear();
							sRockList.clear();

							for (int i = 0; i < numberOfLargeRocks; i++)
							{

								LargeRock tempRock(renderer, -1000.0f, -1000.0f);

								lRockList.push_back(tempRock);
							}

							for (int i = 0; i < numberOfSmallRocks; i++)
							{

								SmallRock tempRock(renderer, -1000.0f, -1000.0f);

								sRockList.push_back(tempRock);
							}

							for (int i = 0; i < numberOfLargeRocks; i++)
							{
								cout << "You are on LEVEL " << numberOfLargeRocks;
								cout << "SCORE: " << playerScore;

								lRockList[i].Reposition();
							}

						}
					}
				}
			}
		}


		//draw
		SDL_RenderClear(renderer);

		SDL_RenderCopy(renderer, bg, NULL, &bgPos);

		for (int i = 0; i < bulletList.size(); i++)
		{
			if (bulletList[i].active == true)
			{
				bulletList[i].Draw(renderer);
			}
		}
		SDL_RenderCopyEx(renderer, player, NULL, &playerPos, playerAngle, &center, SDL_FLIP_NONE);

		for (int i = 0; i < lRockList.size(); i++)
		{
			if (lRockList[i].active == true)
			{
				lRockList[i].Draw(renderer);
			}
		}
		
		for (int i = 0; i < sRockList.size(); i++)
		{
			if (sRockList[i].active == true)
			{
				sRockList[i].Draw(renderer);
			}
		}
		

		SDL_RenderCopy(renderer, scoreTexture, NULL, &scorePos);
		SDL_RenderCopy(renderer, livesTexture, NULL, &livesPos);

		SDL_RenderPresent(renderer);
	}


	SDL_DestroyWindow(window);
	SDL_Quit();


	return 0;
}