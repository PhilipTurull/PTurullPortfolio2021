#include <SDL.h>
#include <SDL_image.h>

class SmallRock {
public:

	bool active;

	SDL_Texture* texture;

	SDL_Rect posRect;

	float speed, xDir, yDir, pos_X, pos_Y;

	float rockAngle;

	SDL_Point rockCenter;

	SmallRock(SDL_Renderer* renderer, float x, float y);

	void Reposition(float x, float y);

	void Update(float deltaTime);

	void Draw(SDL_Renderer* renderer);

	void Deactivate();

	~SmallRock();
};