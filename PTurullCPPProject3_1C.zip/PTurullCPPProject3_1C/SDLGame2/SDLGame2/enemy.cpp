#include "enemy.h"

#include <string>

Enemy::Enemy(SDL_Renderer* renderer, int speed, int maxH, int maxV, string dir, string type, int startX, int startY)
{
	enemyMovement = speed;

	currentDir = dir;

	maxHorizontalMovement = maxH;

	maxVerticalMovement = maxV;

	verticalCounter = 0;
	horizontalCounter = 0;

	enemyType = type;

	SDL_Surface* surface = IMG_Load("./Assets/enemy.png");

	texture = SDL_CreateTextureFromSurface(renderer, surface);

	SDL_FreeSurface(surface);

	posRect.x = startX;
	posRect.y = startY;

	int w, h;

	SDL_QueryTexture(texture, NULL, NULL, &w, &h);

	posRect.w = w;
	posRect.h = h;


	lastTime = 0;
}

void Enemy::Update(float deltaTime)
{
	currentTime = SDL_GetTicks();

	if (currentTime > lastTime + 500)
	{
		if (currentDir == "left" && (horizontalCounter < maxHorizontalMovement))
		{
			posRect.x -= enemyMovement;

			horizontalCounter+=1;

			if (horizontalCounter >= maxHorizontalMovement)
			{
				horizontalCounter = 0;

				if (enemyType == "CW")
				{
					currentDir = "up";
				}
				else if (enemyType == "CCW")
				{
					currentDir = "down";
				}
			}
		}
		else if (currentDir == "right" && (horizontalCounter < maxHorizontalMovement))
		{
			posRect.x += enemyMovement;

			horizontalCounter+=1;

			if (horizontalCounter >= maxHorizontalMovement)
			{
				horizontalCounter = 0;

				if (enemyType == "CW")
				{
					currentDir = "down";
				}
				else if (enemyType == "CCW")
				{
					currentDir = "up";
				}
			}
			
		}
		else if (currentDir == "up" && (verticalCounter < maxVerticalMovement))
		{
			posRect.y -= enemyMovement;
			verticalCounter+=1;

			if (verticalCounter >= maxVerticalMovement)
			{
				verticalCounter = 0;

				if (enemyType == "CW")
				{
					currentDir = "right";
				}
				else if (enemyType == "CCW")
				{
					currentDir = "left";
				}
			}
		}
		else if (currentDir == "down" && (verticalCounter < maxVerticalMovement))
		{
			posRect.y += enemyMovement;
			verticalCounter+=1;

			if (verticalCounter >= maxVerticalMovement)
			{
				verticalCounter = 0;

				if (enemyType == "CW")
				{
					currentDir = "left";
				}
				else if (enemyType == "CCW")
				{
					currentDir = "right";
				}
			}
		}
		

		lastTime = currentTime;
	}
}

void Enemy::Draw(SDL_Renderer* renderer)
{
	SDL_RenderCopy(renderer, texture, NULL, &posRect);
}

Enemy::~Enemy(){
	//SDL_DestroyTexture(texture);
}