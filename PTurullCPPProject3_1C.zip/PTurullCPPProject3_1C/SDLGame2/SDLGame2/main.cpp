#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>

#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>
#include "enemy.h"
#include "pickup.h"
using namespace std;

bool quit = false;

float deltaTime = 0.0f;

int thisTime = 0, lastTime = 0;

int playerMovement = 71;

const int mazeWidth = 9;

const int mazeHeight = 5;

SDL_Rect playerPos;

int playerVertical = 4;
int playerHorizontal = 4;

vector<Enemy>enemyList;
vector<Coin>coinList;


int numberOfEnemies;
int numberOfCoins;

Mix_Chunk* pickup;
Mix_Chunk* wasted;


int main(int argc, char* argv[])
{
	SDL_Window* window;

	SDL_Renderer* renderer = NULL;

	SDL_Init(SDL_INIT_EVERYTHING);

	window = SDL_CreateWindow(
		"Dungeon Crawler",					//window title
		SDL_WINDOWPOS_UNDEFINED,		//initial x
		SDL_WINDOWPOS_UNDEFINED,		//initial y
		642,							//x size
		358,							//ysize
		SDL_WINDOW_OPENGL
	);

	//error code to see if creation failed
	if (window == NULL)
	{
		printf("Could not create window: %s\n", SDL_GetError());
		return 0;
	}

	//create renderer
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

	//bgimage
	SDL_Surface* surface = IMG_Load("./Assets/level.png");

	SDL_Texture* bg;

	bg = SDL_CreateTextureFromSurface(renderer, surface);

	SDL_FreeSurface(surface);

	SDL_Rect bgPos;

	bgPos.x = 0;
	bgPos.y = 0;
	bgPos.w = 642;
	bgPos.h = 358;

	//player image
	surface = IMG_Load("./Assets/player.PNG");

	SDL_Texture* player;

	player = SDL_CreateTextureFromSurface(renderer, surface);

	SDL_FreeSurface(surface);

	playerPos.x = 291;
	playerPos.y = 291;
	playerPos.w = 59;
	playerPos.h = 59;

	enum GameState { GAME, WIN, LOSE };

	GameState gameState = GAME;

	bool game, win, lose;

	SDL_Event event;

	Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);

	wasted = Mix_LoadWAV("./Assets/Wasted.wav");
	pickup = Mix_LoadWAV("./Assets/pickup.wav");

	//bgMusic = Mix_LoadMUS("./Assets/bgMusic.wav");

	//if (!Mix_PlayingMusic())
	//{
	//	Mix_PlayMusic(bgMusic, -1);
	//}
	
	string maze[mazeHeight][mazeWidth] = {
	{"O","O","O","O","O","O","O","O","O"},
	{"O","W","O","W","W","W","O","W","O"},
	{"O","O","O","O","W","O","O","O","O",},
	{"O","W","O","W","W","W","O","W","O"},
	{"O","O","O","O","P","O","O","O","O"},
	};

	enemyList.clear();

	numberOfEnemies = 4;

	Enemy tempEnemy(renderer, 71, 2, 2, "left", "CCW", 575, 7);

	Enemy tempEnemy2(renderer, 71, 2, 2, "right", "CW", 7, 7);

	Enemy tempEnemy3(renderer, 71, 2, 2, "right", "CW", 433, 149);

	Enemy tempEnemy4(renderer, 71, 2, 2, "up", "CCW", 149, 291);

	enemyList.push_back(tempEnemy);
	enemyList.push_back(tempEnemy2);
	enemyList.push_back(tempEnemy3);
	enemyList.push_back(tempEnemy4);

	coinList.clear();

	numberOfCoins = 4;

	int totalCoins = 0;

	Coin tempCoin(renderer, 18, 18);
	Coin tempCoin2(renderer, 18, 302);
	Coin tempCoin3(renderer, 586, 18);
	Coin tempCoin4(renderer, 586, 302);

	coinList.push_back(tempCoin);
	coinList.push_back(tempCoin2);
	coinList.push_back(tempCoin3);
	coinList.push_back(tempCoin4);

	while (!quit)
	{

		thisTime = SDL_GetTicks();
		deltaTime = (float)(thisTime - lastTime) / 1000;
		lastTime = thisTime;

		if (SDL_PollEvent(&event))
		{
			if (event.type == SDL_QUIT)
			{
				quit = true;
				game = false;
				break;
			}

			switch (event.type)
			{

			case SDL_KEYUP:
				switch (event.key.keysym.sym)
				{
				case SDLK_RIGHT:
					if ((playerHorizontal + 1) < mazeWidth)
					{
						if (maze[playerVertical][playerHorizontal + 1]  == "O")
						{
							maze[playerVertical][playerHorizontal] = "O";
							maze[playerVertical][playerHorizontal + 1] = "P";
							playerHorizontal++;
							playerPos.x += playerMovement;

							
						}
					}
					break;
				case SDLK_LEFT:
					if ((playerHorizontal - 1) >= 0)
					{
						if (maze[playerVertical][playerHorizontal - 1] == "O")
						{
							maze[playerVertical][playerHorizontal] = "O";
							maze[playerVertical][playerHorizontal - 1] = "P";
							playerHorizontal--;
							playerPos.x -= playerMovement;
						}
					}
					break;
				case SDLK_UP:
					if ((playerVertical - 1) >= 0)
					{
						if (maze[playerVertical - 1][playerHorizontal] == "O")
						{
							maze[playerVertical][playerHorizontal] = "O";
							maze[playerVertical-1][playerHorizontal] = "P";
							playerVertical--;
							playerPos.y -= playerMovement;
						}
					}
					break;
				case SDLK_DOWN:
					if ((playerVertical + 1) < mazeHeight)
					{
						if (maze[playerVertical + 1][playerHorizontal] == "O")
						{
							maze[playerVertical][playerHorizontal] = "O";
							maze[playerVertical+1][playerHorizontal] = "P";
							playerVertical++;
							playerPos.y += playerMovement;
						}
					}
					break;

				default:
					break;
				}

			}
			
		}

		//const Uint8* currentKeyStatus = SDL_GetKeyboardState(NULL);

		for (int i = 0; i < numberOfEnemies; i++)
		{
			enemyList[i].Update(deltaTime);
		}


		for (int i = 0; i < enemyList.size(); i++)
		{
			if (SDL_HasIntersection(&playerPos, &enemyList[i].posRect))
			{
				cout << "You have lost!" << endl;
				Mix_PlayChannel(-1, wasted, 0);
			}
		}

		for (int i = 0; i < coinList.size(); i++)
		{
			if (SDL_HasIntersection(&playerPos, &coinList[i].posRect))
			{
				totalCoins++;
				if (totalCoins == 4)
				{
					cout << "You have won!";
				}
				else {
					cout << "Player has " << totalCoins << " coins" << endl;

					coinList[i].RemoveFromScreen();


					Mix_PlayChannel(-1, pickup, 0);


				}
			}
			
		}


		//draw
		SDL_RenderClear(renderer);

		SDL_RenderCopy(renderer, bg, NULL, &bgPos);

		SDL_RenderCopy(renderer, player, NULL, &playerPos);

		for (int i = 0; i < numberOfCoins; i++)
		{
			coinList[i].Draw(renderer);
		}

		for (int i = 0; i < numberOfEnemies; i++)
		{
			enemyList[i].Draw(renderer);
		}
	
		SDL_RenderPresent(renderer);
	}


	SDL_DestroyWindow(window);
	SDL_Quit();


	return 0;
}