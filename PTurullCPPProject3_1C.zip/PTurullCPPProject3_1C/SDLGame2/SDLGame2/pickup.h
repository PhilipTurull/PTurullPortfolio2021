#include <SDL.h>
#include <SDL_image.h>


#include <iostream>
#include <string>
using namespace std;


class Coin {
public:
	bool active; 
	SDL_Texture* texture;

	SDL_Rect posRect;

	Coin(SDL_Renderer* renderer, int startX, int startY);

	void RemoveFromScreen();

	void Draw(SDL_Renderer* renderer);

	~Coin();

};